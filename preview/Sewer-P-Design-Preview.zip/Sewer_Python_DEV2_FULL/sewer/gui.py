from __future__ import annotations

import time
from pathlib import Path

from PySide6 import QtCore, QtGui, QtWidgets
import pyqtgraph as pg

from .config import clone_config
from .controller import SewerController
from .settings import SettingsDialog

BW = [
    ("1 Hz",1),("3 Hz",3),("10 Hz",10),("30 Hz",30),("100 Hz",100),("300 Hz",300),
    ("1 kHz",1e3),("3 kHz",3e3),("10 kHz",1e4),("30 kHz",3e4),("100 kHz",1e5),
    ("300 kHz",3e5),("1 MHz",1e6),("3 MHz",3e6),("10 MHz",1e7),
]


class ReverseWheelCombo(QtWidgets.QComboBox):
    def wheelEvent(self, event):
        if not self.isEnabled() or self.count() == 0:
            event.ignore(); return
        delta = event.angleDelta().y()
        if delta == 0:
            event.ignore(); return
        step = 1 if delta > 0 else -1
        self.setCurrentIndex(max(0, min(self.count()-1, self.currentIndex()+step)))
        event.accept()


class StatusBadge(QtWidgets.QFrame):
    TITLES = {"COM": "Источник питания", "FW": "Файл прошивки", "PRG": "Программатор", "RIG": "Rigol"}

    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.kind = title
        self.ok = None
        self.setFixedSize(46, 46)
        self.setAccessibleName(self.TITLES[title])

    def set_status(self, text: str, ok: bool | None):
        self.ok = ok
        state = "Готов" if ok else "Не готов"
        self.setToolTip(f"{self.TITLES[self.kind]}: {state} · {text}")
        self.setAccessibleDescription(self.toolTip())
        self.update()

    def paintEvent(self, event):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        p.scale(self.width()/46, self.height()/46)
        color = QtGui.QColor("#d3e1ef" if getattr(self,"monochrome",False) else "#73cfa6" if self.ok else "#eb8585")
        p.setPen(QtGui.QPen(QtGui.QColor("#343d46"), 1))
        p.setBrush(QtGui.QColor("#232b33"))
        if not getattr(self,"monochrome",False): p.drawRoundedRect(QtCore.QRectF(0.5, 0.5, 45, 45), 4, 4)
        p.setPen(QtGui.QPen(color, 1.7))
        p.setBrush(QtCore.Qt.NoBrush)
        if self.kind == "COM":
            p.drawRoundedRect(QtCore.QRectF(15, 16, 16, 12), 3, 3)
            p.drawLine(19, 11, 19, 16); p.drawLine(27, 11, 27, 16)
            p.drawLine(23, 28, 23, 35)
        elif self.kind == "FW":
            p.drawRoundedRect(QtCore.QRectF(16, 11, 15, 23), 2, 2)
            p.drawLine(20, 19, 27, 19); p.drawLine(20, 24, 27, 24)
            p.drawLine(20, 29, 25, 29)
        elif self.kind == "PRG":
            p.drawRoundedRect(QtCore.QRectF(15, 15, 16, 16), 2, 2)
            for n in (18, 23, 28):
                p.drawLine(n, 11, n, 15); p.drawLine(n, 31, n, 35)
                p.drawLine(11, n, 15, n); p.drawLine(31, n, 35, n)
        else:
            p.drawLine(12, 33, 34, 33)
            path = QtGui.QPainterPath(QtCore.QPointF(12, 28))
            for x, y in ((17,28),(21,14),(25,29),(29,23),(34,28)):
                path.lineTo(x, y)
            p.drawPath(path)
        p.end()


class ActionButton(QtWidgets.QPushButton):
    def __init__(self, label, shortcut, symbol, parent=None):
        super().__init__(parent)
        self.label, self.shortcut, self.symbol = label, shortcut, symbol
        self.setAccessibleName(f"{label}, {shortcut}")
        self.setToolTip(f"{label} · {shortcut}")
        self.setMinimumSize(205, 42)
        self.setCursor(QtCore.Qt.PointingHandCursor)

    def paintEvent(self, event):
        super().paintEvent(event)
        p = QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing)
        enabled = self.isEnabled()
        color = QtGui.QColor("#eef4f7" if enabled else "#81909f")
        p.setPen(QtGui.QPen(color, 2.4)); p.setBrush(QtCore.Qt.NoBrush)
        cy = self.height()/2
        if self.symbol == "▶":
            p.setPen(QtCore.Qt.NoPen); p.setBrush(color)
            p.drawPolygon(QtGui.QPolygonF([QtCore.QPointF(19,cy-10),QtCore.QPointF(19,cy+10),QtCore.QPointF(34,cy)]))
        elif self.symbol == "■":
            p.setPen(QtCore.Qt.NoPen); p.setBrush(QtGui.QColor("#f27979" if enabled else "#926a70"))
            p.drawRoundedRect(QtCore.QRectF(17,cy-10,20,20),2,2)
        elif self.symbol == "↻":
            p.drawArc(QtCore.QRectF(17,cy-11,22,22),40*16,285*16)
            p.drawLine(QtCore.QPointF(37,cy-12),QtCore.QPointF(37,cy-3))
            p.drawLine(QtCore.QPointF(37,cy-3),QtCore.QPointF(28,cy-3))
        else:
            p.drawLine(QtCore.QPointF(17,cy-11),QtCore.QPointF(17,cy+11))
            p.drawLine(QtCore.QPointF(17,cy-11),QtCore.QPointF(27,cy-11))
            p.drawLine(QtCore.QPointF(17,cy+11),QtCore.QPointF(27,cy+11))
            p.drawLine(QtCore.QPointF(24,cy),QtCore.QPointF(40,cy))
            p.drawLine(QtCore.QPointF(34,cy-6),QtCore.QPointF(40,cy))
            p.drawLine(QtCore.QPointF(34,cy+6),QtCore.QPointF(40,cy))
        p.setPen(color)
        font=self.font(); font.setPixelSize(17); font.setBold(True); p.setFont(font)
        p.drawText(QtCore.QRect(50,0,self.width()-108,self.height()),QtCore.Qt.AlignVCenter,self.label)
        font.setPixelSize(11); font.setBold(False); p.setFont(font)
        p.setPen(QtGui.QColor("#c0d0e0" if enabled else "#81909f"))
        p.drawText(QtCore.QRect(self.width()-58,0,48,self.height()),QtCore.Qt.AlignRight|QtCore.Qt.AlignVCenter,self.shortcut)
        p.end()


class PanelIcon(StatusBadge):
    def __init__(self, kind, parent=None):
        super().__init__(kind,parent)
        self.ok=True
        self.monochrome=True
        self.setStyleSheet("background:transparent;border:none;")
        self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents)


class MetricCard(QtWidgets.QFrame):
    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.setObjectName("InstrumentCard")
        self.setFixedHeight(158)
        self.grid=QtWidgets.QGridLayout(self)
        self.grid.setContentsMargins(12,12,12,12); self.grid.setSpacing(8)
        self.grid.setColumnStretch(0,1); self.grid.setColumnStretch(1,1)
        header_widget=QtWidgets.QWidget(); header_widget.setStyleSheet("background:transparent;"); header_widget.setFixedHeight(46)
        header=QtWidgets.QHBoxLayout(header_widget); header.setContentsMargins(0,0,0,0); header.setSpacing(9)
        kind={"Источник питания":"COM","Состояние выхода":"RIG","Программатор":"PRG","Rigol":"RIG"}[title]
        header.addWidget(PanelIcon(kind))
        labels=QtWidgets.QVBoxLayout(); labels.setSpacing(3)
        heading=QtWidgets.QLabel(title); heading.setStyleSheet("font-size:18px;font-weight:700;color:#e9f1f8;")
        self.status=QtWidgets.QLabel("—")
        labels.addWidget(heading); labels.addWidget(self.status); header.addLayout(labels,1)
        self.grid.addWidget(header_widget,0,0,1,2)
        self.rows={}
        self.is_measurement=title in ("Источник питания","Состояние выхода")

    def add_metric(self, row: int, label: str):
        if self.is_measurement:
            cell=QtWidgets.QFrame(); cell.setObjectName("MeasurementCell")
            layout=QtWidgets.QVBoxLayout(cell); layout.setContentsMargins(10,8,8,8); layout.setSpacing(5)
            caption=QtWidgets.QLabel(label); caption.setStyleSheet("color:#afbdcb;font-size:12px;")
            value=QtWidgets.QLabel("—"); value.setAlignment(QtCore.Qt.AlignLeft|QtCore.Qt.AlignVCenter)
            value.setStyleSheet("font-family:Consolas;font-size:34px;font-weight:700;color:#f3f7fc;")
            layout.addWidget(caption); layout.addWidget(value,1)
            self.grid.addWidget(cell,1,row-1,2,1)
        else:
            caption=QtWidgets.QLabel(label); caption.setStyleSheet("color:#afbdcb;font-size:14px;")
            value=QtWidgets.QLabel("—"); value.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignVCenter)
            value.setStyleSheet("font-family:Consolas;font-size:22px;font-weight:600;color:#eef4f7;")
            self.grid.addWidget(caption,row,0); self.grid.addWidget(value,row,1)
        self.rows[label]=value
        return value

    def set_status(self, text: str, ok: bool | None):
        self.status.setText("●  "+text)
        color="#73cfa6" if ok is True else "#eb8585" if ok is False else "#d9bb79"
        self.status.setStyleSheet(f"font-size:13px;font-weight:600;color:{color};")


class RigolControlDialog(QtWidgets.QDialog):
    def __init__(self, controller: SewerController, parent=None):
        super().__init__(parent)
        self.controller=controller; self.rigol=controller.rigol
        self.setWindowTitle("Rigol — управление")
        self.resize(1260,780)
        self.setModal(False)
        self.live_timer=QtCore.QTimer(self)
        self.live_timer.setInterval(int(controller.config.get("Rigol",{}).get("LiveIntervalMs",300)))
        self.live_timer.timeout.connect(self.refresh_live)
        self._build()

    def _build(self):
        root=QtWidgets.QVBoxLayout(self)
        top=QtWidgets.QHBoxLayout(); root.addLayout(top)
        self.resource=QtWidgets.QLineEdit(self.controller.config.get("Rigol",{}).get("Resource","")); top.addWidget(self.resource,1)
        b=QtWidgets.QPushButton("Подключить"); b.clicked.connect(self.connect_rigol); top.addWidget(b)
        self.mode=QtWidgets.QComboBox(); self.mode.addItems(["GPSA","RTSA"]); top.addWidget(self.mode)
        bm=QtWidgets.QPushButton("Режим"); bm.clicked.connect(self.apply_mode); top.addWidget(bm)
        self.status=QtWidgets.QLabel("Не подключен"); top.addWidget(self.status)

        body=QtWidgets.QHBoxLayout(); root.addLayout(body,1)
        left=QtWidgets.QVBoxLayout(); body.addLayout(left,0)

        self.center=self._dspin(0,6500,1,0," MHz")
        self.span=self._dspin(0,6500,1,0," MHz")
        left.addWidget(self._group("Frequency",[("Center",self.center,self.apply_center),("Span",self.span,self.apply_span)]))

        self.ref=self._dspin(-99,99,1,1," dBm")
        self.off=self._dspin(-300,300,1,1," dB")
        self.scale=QtWidgets.QSpinBox(); self.scale.setButtonSymbols(QtWidgets.QAbstractSpinBox.NoButtons); self.scale.setRange(1,20); self.scale.setSingleStep(1); self.scale.setSuffix(" dB/div"); self.scale.setKeyboardTracking(False)
        self.att=self._dspin(0,70,1,0," dB")
        left.addWidget(self._group("Amplitude",[("Ref Level",self.ref,self.apply_ref),("Ref Offset",self.off,self.apply_off),("Scale/Div",self.scale,self.apply_scale),("Attenuation",self.att,self.apply_att)]))

        gbw=QtWidgets.QGroupBox("BW"); gl=QtWidgets.QGridLayout(gbw)
        self.rbw=ReverseWheelCombo(); self.vbw=ReverseWheelCombo()
        for n,v in BW: self.rbw.addItem(n,v); self.vbw.addItem(n,v)
        self.rbwa=QtWidgets.QCheckBox("Auto"); self.vbwa=QtWidgets.QCheckBox("Auto")
        gl.addWidget(QtWidgets.QLabel("RBW"),0,0); gl.addWidget(self.rbw,0,1); gl.addWidget(self.rbwa,0,2)
        gl.addWidget(QtWidgets.QLabel("VBW"),1,0); gl.addWidget(self.vbw,1,1); gl.addWidget(self.vbwa,1,2)
        br=QtWidgets.QPushButton("Применить BW"); br.clicked.connect(self.apply_bw); gl.addWidget(br,2,0,1,3)
        left.addWidget(gbw)

        gs=QtWidgets.QGroupBox("Sweep"); sl=QtWidgets.QGridLayout(gs)
        self.sweept=self._dspin(1,4000000,1,0," ms"); self.sweepa=QtWidgets.QCheckBox("Auto")
        self.points=QtWidgets.QSpinBox(); self.points.setButtonSymbols(QtWidgets.QAbstractSpinBox.NoButtons); self.points.setRange(101,10001); self.points.setSingleStep(1)
        bc=QtWidgets.QPushButton("Continuous"); bc.clicked.connect(lambda:self._safe(lambda:self.rigol.continuous(True)))
        bs=QtWidgets.QPushButton("Single"); bs.clicked.connect(lambda:self._safe(self.rigol.single))
        sl.addWidget(bc,0,0); sl.addWidget(bs,0,1)
        sl.addWidget(QtWidgets.QLabel("Sweep Time"),1,0); sl.addWidget(self.sweept,1,1); sl.addWidget(self.sweepa,1,2)
        sl.addWidget(QtWidgets.QLabel("Points"),2,0); sl.addWidget(self.points,2,1)
        ba=QtWidgets.QPushButton("Применить Sweep"); ba.clicked.connect(self.apply_sweep); sl.addWidget(ba,3,0,1,3)
        left.addWidget(gs)

        gt=QtWidgets.QGroupBox("Trace"); tl=QtWidgets.QGridLayout(gt)
        self.tr=QtWidgets.QComboBox(); self.tr.addItems([str(i) for i in range(1,7)])
        tl.addWidget(QtWidgets.QLabel("Trace"),0,0); tl.addWidget(self.tr,0,1)
        for i,(txt,typ) in enumerate([("Clear/Write","WRITe"),("Max Hold","MAXHold"),("Average","AVERage"),("Min Hold","MINHold")]):
            b=QtWidgets.QPushButton(txt); b.clicked.connect(lambda _,t=typ:self.set_trace(t)); tl.addWidget(b,1+i//2,i%2)
        self.live=QtWidgets.QCheckBox(f"Live {self.live_timer.interval()} ms")
        self.live.toggled.connect(lambda on:self.live_timer.start() if on else self.live_timer.stop())
        tl.addWidget(self.live,3,0,1,2); left.addWidget(gt); left.addStretch()

        self.plot=pg.PlotWidget(); body.addWidget(self.plot,1)
        self.curve=self.plot.plot(); self.plot.showGrid(x=True,y=True)
        self.plot.setLabel("bottom","Frequency","MHz"); self.plot.setLabel("left","Level","dBm")

    def _dspin(self,a,b,step,dec,suffix):
        x=QtWidgets.QDoubleSpinBox(); x.setButtonSymbols(QtWidgets.QAbstractSpinBox.NoButtons); x.setRange(a,b); x.setSingleStep(step); x.setDecimals(dec); x.setSuffix(suffix); x.setKeyboardTracking(False); return x

    def _group(self,title,rows):
        g=QtWidgets.QGroupBox(title); l=QtWidgets.QGridLayout(g)
        for r,(name,w,fn) in enumerate(rows):
            l.addWidget(QtWidgets.QLabel(name),r,0); l.addWidget(w,r,1)
            b=QtWidgets.QPushButton("Set"); b.clicked.connect(fn); l.addWidget(b,r,2)
            if hasattr(w,"editingFinished"): w.editingFinished.connect(fn)
        return g

    def _safe(self, fn):
        try: fn(); self.status.setText("OK")
        except Exception as e: self.status.setText(str(e))

    def connect_rigol(self):
        def f():
            self.rigol.reconfigure(self.resource.text().strip(), int(self.controller.config.get("Rigol",{}).get("TimeoutMs",2500)))
            idn=self.rigol.connect(); self.controller.rigol_connected=True; self.controller.rigol_mode=self.rigol.mode(); self.status.setText(idn); self.refresh_all(); self.controller.updated.emit()
        self._safe(f)

    def refresh_all(self):
        self.mode.setCurrentText(self.rigol.mode())
        self.center.setValue(self.rigol.center_hz()/1e6); self.span.setValue(self.rigol.span_hz()/1e6)
        self.ref.setValue(self.rigol.ref_level()); self.off.setValue(self.rigol.ref_offset())
        self.scale.setValue(int(round(self.rigol.scale_div()))); self.att.setValue(self.rigol.attenuation())
        self.sweept.setValue(self.rigol.sweep_time()*1000); self.points.setValue(self.rigol.sweep_points())
        for combo,val in ((self.rbw,self.rigol.rbw()),(self.vbw,self.rigol.vbw())):
            idx=min(range(combo.count()), key=lambda i:abs(combo.itemData(i)-val)); combo.setCurrentIndex(idx)

    def apply_mode(self): self._safe(lambda:self.rigol.set_mode(self.mode.currentText()))
    def apply_center(self): self._safe(lambda:self.rigol.set_center_hz(self.center.value()*1e6))
    def apply_span(self): self._safe(lambda:self.rigol.set_span_hz(self.span.value()*1e6))
    def apply_ref(self): self._safe(lambda:self.rigol.set_ref_level(self.ref.value()))
    def apply_off(self): self._safe(lambda:self.rigol.set_ref_offset(self.off.value()))
    def apply_scale(self): self._safe(lambda:self.rigol.set_scale_div(self.scale.value()))
    def apply_att(self): self._safe(lambda:self.rigol.set_attenuation(self.att.value()))
    def apply_bw(self):
        def f():
            self.rigol.set_rbw_auto(self.rbwa.isChecked()); self.rigol.set_vbw_auto(self.vbwa.isChecked())
            if not self.rbwa.isChecked(): self.rigol.set_rbw(self.rbw.currentData())
            if not self.vbwa.isChecked(): self.rigol.set_vbw(self.vbw.currentData())
        self._safe(f)
    def apply_sweep(self):
        def f():
            self.rigol.set_sweep_time_auto(self.sweepa.isChecked())
            if not self.sweepa.isChecked(): self.rigol.set_sweep_time(self.sweept.value()/1000)
            self.rigol.set_sweep_points(self.points.value())
        self._safe(f)
    def set_trace(self,t): self._safe(lambda:self.rigol.set_trace_type(int(self.tr.currentText()),t))

    def refresh_live(self):
        if not self.rigol.connected: return
        try:
            y=self.rigol.trace_ascii(int(self.tr.currentText()))
            if y.size<2: return
            c=self.rigol.center_hz()/1e6; s=self.rigol.span_hz()/1e6
            x=[c-s/2+i*s/(len(y)-1) for i in range(len(y))]
            self.curve.setData(x,y); self.status.setText(f"Live: {len(y)} точек")
        except Exception as e: self.status.setText("Live error: "+str(e))

    def closeEvent(self,e):
        self.live_timer.stop(); super().closeEvent(e)


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, controller: SewerController):
        super().__init__(); self.c=controller; self.rigol_dialog=None
        self.setWindowTitle("Sewer-P")
        self.resize(1040,640); self.setMinimumSize(1040,640)
        icon=controller.root/"Resources/Hedgehog.png"
        if icon.exists(): self.setWindowIcon(QtGui.QIcon(str(icon)))
        self._style(); self._build(); self._shortcuts()
        controller.log_line.connect(self.append_log); controller.updated.connect(self.refresh)
        self.refresh()

    def _style(self):
        self.setStyleSheet('''
            QWidget{background:#171c24;color:#e5ebef;font-family:"Segoe UI";font-size:12px;}
            QMainWindow,QDialog{background:#171c24;}
            QFrame#InstrumentCard{background:#222a35;border:1px solid #3b4959;border-radius:5px;}
            QFrame#MeasurementCell{background:#19212b;border:1px solid #344253;border-radius:4px;}
            QGroupBox{background:#222a35;border:1px solid #343d46;border-radius:4px;margin-top:10px;padding-top:8px;font-weight:600;}
            QGroupBox::title{subcontrol-origin:margin;left:12px;padding:0 5px;color:#b9c6d0;}
            QLabel{background:transparent;}
            QTabWidget::pane{border:1px solid #343d46;border-radius:4px;}
            QTabBar::tab{background:#252e36;color:#aebdc8;border:1px solid #343d46;padding:8px 12px;}
            QTabBar::tab:selected{background:#243b54;color:#e5ebef;border-bottom:2px solid #399ce8;}
            QCheckBox{background:transparent;spacing:7px;}
            QPushButton{background:#2c353e;border:1px solid #414e59;border-radius:4px;padding:8px 10px;}
            QPushButton:hover{background:#36434e;border-color:#657b89;}
            QPushButton:pressed{background:#202a32;}
            QPushButton:focus{border-color:#399ce8;}
            QPushButton:disabled{color:#85909a;background:#252d34;border-color:#343d46;}
            QPushButton#StartButton{background:#1769b3;border-color:#348cd9;}
            QPushButton#StartButton:hover{background:#227dc9;}
            QPushButton#StartButton:disabled{background:#243447;border-color:#3a4c61;}
            QPushButton#StopButton{border-color:#785050;}
            QPushButton#StopButton:hover{background:#493236;}
            QLineEdit,QSpinBox,QDoubleSpinBox,QComboBox{background:#252e36;border:1px solid #46535f;border-radius:5px;padding:5px;selection-background-color:#1769b3;}
            QPlainTextEdit{background:#171d23;border:1px solid #303b45;border-radius:4px;padding:7px;font-family:Consolas;color:#c4d2dd;}
            QProgressBar{min-height:24px;border:1px solid #3c4954;border-radius:6px;background:#182128;text-align:center;color:#e5ebef;}
            QProgressBar::chunk{background:#1769b3;border-radius:5px;}
        ''')

    def _build(self):
        cw=QtWidgets.QWidget(); self.setCentralWidget(cw); root=QtWidgets.QVBoxLayout(cw); root.setContentsMargins(12,10,12,10); root.setSpacing(8)
        header=QtWidgets.QHBoxLayout(); root.addLayout(header)
        t=QtWidgets.QLabel("Sewer-P"); t.setStyleSheet("font-size:32px;font-weight:700;color:#f0f5f8;"); header.addWidget(t)
        header.addStretch(1)
        self.badge_com=StatusBadge("COM"); self.badge_fw=StatusBadge("FW"); self.badge_prg=StatusBadge("PRG"); self.badge_rig=StatusBadge("RIG")
        self.settings_btn=QtWidgets.QPushButton()
        self.settings_btn.setFixedSize(68,50)
        self.settings_btn.setIconSize(QtCore.QSize(60,44))
        self.settings_btn.setToolTip("Настройки")
        self.settings_btn.setAccessibleName("Настройки")
        self.settings_btn.setCursor(QtCore.Qt.PointingHandCursor)
        self.settings_btn.setStyleSheet("QPushButton{background:transparent;border:1px solid transparent;padding:2px;} QPushButton:hover{background:#293544;border-color:#465a70;} QPushButton:focus{border-color:#399ce8;}")
        mascot=self.c.root/"Resources/Hedgehog.png"
        if mascot.exists(): self.settings_btn.setIcon(QtGui.QIcon(str(mascot)))
        else: self.settings_btn.setText("Настройки")
        self.settings_btn.clicked.connect(self.open_settings)
        header.addWidget(self.settings_btn)

        body=QtWidgets.QHBoxLayout(); body.setSpacing(12); root.addLayout(body)
        cards=QtWidgets.QGridLayout(); cards.setSpacing(8); cards.setColumnStretch(0,1); cards.setColumnStretch(1,1); body.addLayout(cards,1)
        self.card_ps=MetricCard("Источник питания"); self.ps_v=self.card_ps.add_metric(1,"Огр. напряжения"); self.ps_i=self.card_ps.add_metric(2,"Огр. тока"); cards.addWidget(self.card_ps,0,0)
        self.card_out=MetricCard("Состояние выхода"); self.out_v=self.card_out.add_metric(1,"Напряжение"); self.out_i=self.card_out.add_metric(2,"Ток"); cards.addWidget(self.card_out,0,1)
        self.card_prg=MetricCard("Программатор"); self.card_prg.grid.setRowStretch(1,1); self.progress=QtWidgets.QProgressBar(); self.progress.setRange(0,100); self.progress.setStyleSheet("min-height:34px;max-height:34px;"); self.progress.setFixedHeight(36); self.card_prg.grid.addWidget(self.progress,2,0,1,2); cards.addWidget(self.card_prg,1,0)
        self.card_rig=MetricCard("Rigol"); self.rig_mode=self.card_rig.add_metric(1,"Режим"); rig_buttons=QtWidgets.QHBoxLayout(); rig_buttons.setSpacing(8); self.rig_mode_btn=QtWidgets.QPushButton("Режим"); self.rig_mode_btn.setFixedHeight(36); self.rig_mode_btn.setToolTip("GPSA ↔ RTSA · Alt+Пробел"); self.rig_mode_btn.clicked.connect(self.c.switch_rigol_mode); self.rig_control_btn=QtWidgets.QPushButton("Управление"); self.rig_control_btn.setFixedHeight(36); self.rig_control_btn.clicked.connect(self.open_rigol); rig_buttons.addWidget(self.rig_mode_btn); rig_buttons.addWidget(self.rig_control_btn); self.card_rig.grid.addLayout(rig_buttons,2,0,1,2); cards.addWidget(self.card_rig,1,1)

        bottom_widget=QtWidgets.QWidget(); bottom_widget.setFixedHeight(192); root.addWidget(bottom_widget)
        bottom=QtWidgets.QHBoxLayout(bottom_widget); bottom.setContentsMargins(0,0,0,0)
        logbox=QtWidgets.QFrame(); logbox.setObjectName("InstrumentCard"); ll=QtWidgets.QVBoxLayout(logbox); ll.setContentsMargins(12,12,12,12); ll.setSpacing(8); log_title=QtWidgets.QLabel("Журнал событий"); log_title.setStyleSheet("font-size:14px;font-weight:600;color:#cfdeeb;"); ll.addWidget(log_title); self.log=QtWidgets.QPlainTextEdit(); self.log.setReadOnly(True); self.log.document().setMaximumBlockCount(3000); ll.addWidget(self.log); bottom.addWidget(logbox,1)
        side=QtWidgets.QVBoxLayout(); side.setSpacing(8); bottom.setSpacing(8); bottom.addLayout(side)
        self.start_btn=ActionButton("Старт", "Enter", "▶"); self.start_btn.setObjectName("StartButton")
        self.repeat_btn=ActionButton("Повторить", "Пробел", "↻")
        self.stop_btn=ActionButton("Стоп", "Esc", "■"); self.stop_btn.setObjectName("StopButton")
        self.exit_btn=ActionButton("Выход", "Alt+X", "→")
        for b in (self.start_btn,self.repeat_btn,self.stop_btn,self.exit_btn): b.setFixedSize(235,42); side.addWidget(b)
        self.start_btn.clicked.connect(self.c.start_cycle); self.repeat_btn.clicked.connect(self.c.start_cycle); self.stop_btn.clicked.connect(self.c.stop_cycle); self.exit_btn.clicked.connect(self.close)
        footer_row=QtWidgets.QHBoxLayout(); footer_row.setSpacing(6); root.addLayout(footer_row)
        for badge in (self.badge_com,self.badge_fw,self.badge_prg,self.badge_rig):
            badge.setFixedSize(28,28); footer_row.addWidget(badge)
        footer_row.addSpacing(6)
        self.footer=QtWidgets.QLabel("Инициализация"); self.footer.setStyleSheet("color:#a6b5c1;padding-top:3px;"); footer_row.addWidget(self.footer,1)
        self.runtime=QtWidgets.QLabel("00:00:00"); self.runtime.setToolTip("Время работы Sewer-P"); footer_row.addWidget(self.runtime)
        footer_row.addSpacing(20); footer_row.addWidget(QtWidgets.QLabel("Успешных плат:"))
        self.success=QtWidgets.QLabel("0"); self.success.setStyleSheet("color:#73cfa6;font-weight:700;"); footer_row.addWidget(self.success)
        self.runtime_timer=QtCore.QTimer(self); self.runtime_timer.setInterval(1000); self.runtime_timer.timeout.connect(self.refresh_runtime); self.runtime_timer.start()

    def _shortcuts(self):
        for key, fn in (("Return",lambda:self.c.start_cycle() if self.start_btn.isEnabled() else None),("Space",lambda:self.c.start_cycle() if self.repeat_btn.isEnabled() else None),("Esc",self.c.stop_cycle),("Alt+X",self.close),("Alt+Space",self.c.switch_rigol_mode)):
            q=QtGui.QShortcut(QtGui.QKeySequence(key),self); q.activated.connect(fn)

    def append_log(self, line: str):
        self.log.appendPlainText(line); bar=self.log.verticalScrollBar(); bar.setValue(bar.maximum())

    def refresh_runtime(self):
        s=int(time.monotonic()-self.c.started_at); self.runtime.setText(f"{s//3600:02d}:{(s%3600)//60:02d}:{s%60:02d}")

    def refresh(self):
        cfg=self.c.config; ps=cfg["PowerSupply"]; snap=self.c.power.snapshot
        self.badge_com.set_status(str(ps.get("Port","COM")), snap.com_available and snap.responding)
        _,fw,_=self.c.programmer.paths(); self.badge_fw.set_status("ГОТОВ" if fw.is_file() else "НЕ ГОТОВ",fw.is_file())
        err=self.c.programmer.configuration_error(); self.badge_prg.set_status("ГОТОВ" if not err else "НЕ ГОТОВ",not bool(err))
        self.badge_rig.set_status(self.c.rigol_mode if self.c.rigol_connected else "НЕ ГОТОВ",self.c.rigol_connected)
        self.card_ps.set_status("ПОДКЛЮЧЕН" if snap.responding else "НЕ ПОДКЛЮЧЕН",snap.responding)
        self.ps_v.setText(f"{float(ps.get('Voltage',0)):.2f} В"); self.ps_i.setText(f"{float(ps.get('CurrentLimit',0)):.3f} А")
        self.card_out.set_status("ВКЛЮЧЕН" if snap.output_on else "ВЫКЛЮЧЕН",True if snap.output_on else False)
        self.out_v.setText(f"{snap.voltage:.2f} В"); self.out_i.setText(f"{snap.current*1000:.1f} мА")
        pst=self.c.progress_state; self.card_prg.set_status("Готов" if not err else "Не готов", not bool(err))
        self.progress.setValue(int(self.c.programmer.progress))
        self.card_rig.set_status("ПОДКЛЮЧЕН" if self.c.rigol_connected else "НЕТ СВЯЗИ",self.c.rigol_connected); self.rig_mode.setText(self.c.rigol_mode)
        self.rig_mode_btn.setEnabled(self.c.rigol_connected); self.rig_control_btn.setEnabled(True)
        idle=self.c.state=="Idle"; self.start_btn.setEnabled(idle and self.c.ready); self.repeat_btn.setEnabled(idle and self.c.ready and self.c.can_repeat); self.stop_btn.setEnabled(not idle or self.c._busy); self.settings_btn.setEnabled(idle)
        self.success.setText(str(self.c.successful_boards)); self.footer.setText("Готов к работе" if self.c.ready else f"Не готов: {self.c.readiness_reason}")

    def open_settings(self):
        if self.c.state!="Idle": return
        dlg=SettingsDialog(clone_config(self.c.config),self)
        if dlg.exec()==QtWidgets.QDialog.Accepted:
            self.c.apply_config(dlg.result_config())

    def open_rigol(self):
        if self.rigol_dialog is None:
            self.rigol_dialog=RigolControlDialog(self.c,self); self.rigol_dialog.finished.connect(lambda _:setattr(self,'rigol_dialog',None))
        self.rigol_dialog.show(); self.rigol_dialog.raise_(); self.rigol_dialog.activateWindow()
        if self.c.rigol.connected:
            try: self.rigol_dialog.refresh_all()
            except Exception as e: self.rigol_dialog.status.setText(str(e))
        else:
            self.rigol_dialog.status.setText("Нет связи. Нажмите «Подключить».")

    def closeEvent(self,e):
        self.runtime_timer.stop(); self.c.close(); super().closeEvent(e)
