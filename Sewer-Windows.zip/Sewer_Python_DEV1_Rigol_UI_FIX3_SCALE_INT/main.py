\
from __future__ import annotations
import json, sys
from pathlib import Path
from PySide6 import QtCore, QtWidgets
import pyqtgraph as pg
from sewer.rigol import RigolRSA

BW = [
    ("1 Hz",1),("3 Hz",3),("10 Hz",10),("30 Hz",30),("100 Hz",100),("300 Hz",300),
    ("1 kHz",1e3),("3 kHz",3e3),("10 kHz",1e4),("30 kHz",3e4),("100 kHz",1e5),
    ("300 kHz",3e5),("1 MHz",1e6),("3 MHz",3e6),("10 MHz",1e7)
]

class ReverseWheelCombo(QtWidgets.QComboBox):
    def wheelEvent(self, event):
        if not self.isEnabled() or self.count() == 0:
            event.ignore()
            return
        delta = event.angleDelta().y()
        if delta == 0:
            event.ignore()
            return
        step = 1 if delta > 0 else -1
        self.setCurrentIndex(max(0, min(self.count()-1, self.currentIndex()+step)))
        event.accept()

class Main(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Sewer Python DEV1 — Rigol Control UI FIX3")
        self.resize(1350, 820)
        self.cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        rc=self.cfg["rigol"]
        self.rigol=RigolRSA(rc["resource"], rc.get("timeout_ms",2500))
        self.timer=QtCore.QTimer(self); self.timer.setInterval(rc.get("live_interval_ms",300))
        self.timer.timeout.connect(self.refresh_live)
        self.build_ui()

    def build_ui(self):
        c=QtWidgets.QWidget(); self.setCentralWidget(c)
        root=QtWidgets.QVBoxLayout(c)

        top=QtWidgets.QHBoxLayout(); root.addLayout(top)
        self.resource=QtWidgets.QLineEdit(self.cfg["rigol"]["resource"]); top.addWidget(self.resource,1)
        b=QtWidgets.QPushButton("Подключить"); b.clicked.connect(self.connect_rigol); top.addWidget(b)
        self.mode=QtWidgets.QComboBox(); self.mode.addItems(["GPSA","RTSA"]); top.addWidget(self.mode)
        bm=QtWidgets.QPushButton("Режим"); bm.clicked.connect(self.apply_mode); top.addWidget(bm)
        self.status=QtWidgets.QLabel("Не подключен"); top.addWidget(self.status)

        body=QtWidgets.QHBoxLayout(); root.addLayout(body,1)
        left=QtWidgets.QVBoxLayout(); body.addLayout(left,0)

        self.center=self.spin(0,6500,1,0," MHz")
        self.span=self.spin(0,6500,1,0," MHz")
        left.addWidget(self.group("Frequency",[("Center",self.center,self.apply_center),("Span",self.span,self.apply_span)]))

        self.ref=self.spin(-99,99,1,1," dBm")
        self.off=self.spin(-300,300,1,1," dB")
        self.scale=self.spin(1,20,1,0," dB/div")
        self.att=self.spin(0,70,1,0," dB")
        left.addWidget(self.group("Amplitude",[("Ref Level",self.ref,self.apply_ref),("Ref Offset",self.off,self.apply_off),("Scale/Div",self.scale,self.apply_scale),("Attenuation",self.att,self.apply_att)]))

        gbw=QtWidgets.QGroupBox("BW"); gl=QtWidgets.QGridLayout(gbw)
        self.rbw=ReverseWheelCombo(); self.vbw=ReverseWheelCombo()
        for n,v in BW: self.rbw.addItem(n,v); self.vbw.addItem(n,v)
        self.rbwa=QtWidgets.QCheckBox("Auto"); self.vbwa=QtWidgets.QCheckBox("Auto")
        gl.addWidget(QtWidgets.QLabel("RBW"),0,0); gl.addWidget(self.rbw,0,1); gl.addWidget(self.rbwa,0,2)
        gl.addWidget(QtWidgets.QLabel("VBW"),1,0); gl.addWidget(self.vbw,1,1); gl.addWidget(self.vbwa,1,2)
        br=QtWidgets.QPushButton("Применить BW"); br.clicked.connect(self.apply_bw); gl.addWidget(br,2,0,1,3)
        left.addWidget(gbw)

        gs=QtWidgets.QGroupBox("Sweep"); sl=QtWidgets.QGridLayout(gs)
        self.sweept=self.spin(1,4000000,1,0," ms"); self.sweepa=QtWidgets.QCheckBox("Auto")
        self.points=self.spin(101,10001,1,0,"")
        bc=QtWidgets.QPushButton("Continuous"); bc.clicked.connect(lambda:self.safe(lambda:self.rigol.continuous(True)))
        bs=QtWidgets.QPushButton("Single"); bs.clicked.connect(lambda:self.safe(self.rigol.single))
        sl.addWidget(bc,0,0); sl.addWidget(bs,0,1)
        sl.addWidget(QtWidgets.QLabel("Sweep Time"),1,0); sl.addWidget(self.sweept,1,1); sl.addWidget(self.sweepa,1,2)
        sl.addWidget(QtWidgets.QLabel("Points"),2,0); sl.addWidget(self.points,2,1)
        ba=QtWidgets.QPushButton("Применить Sweep"); ba.clicked.connect(self.apply_sweep); sl.addWidget(ba,3,0,1,3)
        left.addWidget(gs)

        gt=QtWidgets.QGroupBox("Trace"); tl=QtWidgets.QGridLayout(gt)
        self.tr=QtWidgets.QComboBox(); self.tr.addItems([str(i) for i in range(1,7)])
        tl.addWidget(QtWidgets.QLabel("Trace"),0,0); tl.addWidget(self.tr,0,1)
        for i,(txt,typ) in enumerate([("Clear/Write","WRITe"),("Max Hold","MAXHold"),("Average","AVERage"),("Min Hold","MINHold")]):
            b=QtWidgets.QPushButton(txt); b.clicked.connect(lambda _,t=typ:self.set_trace(t)); tl.addWidget(b,1+i//2,i%2)
        self.live=QtWidgets.QCheckBox("Live 300 ms"); self.live.toggled.connect(lambda on:self.timer.start() if on else self.timer.stop()); tl.addWidget(self.live,3,0,1,2)
        left.addWidget(gt); left.addStretch()

        self.plot=pg.PlotWidget(); body.addWidget(self.plot,1)
        self.curve=self.plot.plot()
        self.plot.showGrid(x=True,y=True)
        self.plot.setLabel("bottom","Frequency","MHz")
        self.plot.setLabel("left","Level","dBm")

    def spin(self,a,b,step,dec,suffix):
        x=QtWidgets.QDoubleSpinBox(); x.setRange(a,b); x.setSingleStep(step); x.setDecimals(dec); x.setSuffix(suffix); x.setKeyboardTracking(False); return x

    def group(self,title,rows):
        g=QtWidgets.QGroupBox(title); l=QtWidgets.QGridLayout(g)
        for r,(name,w,fn) in enumerate(rows):
            l.addWidget(QtWidgets.QLabel(name),r,0); l.addWidget(w,r,1)
            b=QtWidgets.QPushButton("Set"); b.clicked.connect(fn); l.addWidget(b,r,2)
            w.editingFinished.connect(fn)
        return g

    def safe(self, fn):
        try:
            fn(); self.status.setText("OK")
        except Exception as e:
            self.status.setText(str(e))

    def connect_rigol(self):
        try:
            self.rigol.resource=self.resource.text().strip()
            idn=self.rigol.connect()
            self.status.setText(idn)
            self.refresh_all()
        except Exception as e: self.status.setText(str(e))

    def refresh_all(self):
        self.mode.setCurrentText(self.rigol.mode())
        self.center.setValue(self.rigol.center_hz()/1e6); self.span.setValue(self.rigol.span_hz()/1e6)
        self.ref.setValue(self.rigol.ref_level()); self.off.setValue(self.rigol.ref_offset())
        self.scale.setValue(self.rigol.scale_div()); self.att.setValue(self.rigol.attenuation())
        self.sweept.setValue(self.rigol.sweep_time()*1000.0); self.points.setValue(self.rigol.sweep_points())
        for combo,val in ((self.rbw,self.rigol.rbw()),(self.vbw,self.rigol.vbw())):
            idx=min(range(combo.count()), key=lambda i:abs(combo.itemData(i)-val)); combo.setCurrentIndex(idx)

    def apply_mode(self): self.safe(lambda:self.rigol.set_mode(self.mode.currentText()))
    def apply_center(self): self.safe(lambda:self.rigol.set_center_hz(self.center.value()*1e6))
    def apply_span(self): self.safe(lambda:self.rigol.set_span_hz(self.span.value()*1e6))
    def apply_ref(self): self.safe(lambda:self.rigol.set_ref_level(self.ref.value()))
    def apply_off(self): self.safe(lambda:self.rigol.set_ref_offset(self.off.value()))
    def apply_scale(self): self.safe(lambda:self.rigol.set_scale_div(self.scale.value()))
    def apply_att(self): self.safe(lambda:self.rigol.set_attenuation(self.att.value()))
    def apply_bw(self):
        def f():
            self.rigol.set_rbw_auto(self.rbwa.isChecked()); self.rigol.set_vbw_auto(self.vbwa.isChecked())
            if not self.rbwa.isChecked(): self.rigol.set_rbw(self.rbw.currentData())
            if not self.vbwa.isChecked(): self.rigol.set_vbw(self.vbw.currentData())
        self.safe(f)
    def apply_sweep(self):
        def f():
            self.rigol.set_sweep_time_auto(self.sweepa.isChecked())
            if not self.sweepa.isChecked(): self.rigol.set_sweep_time(self.sweept.value()/1000.0)
            self.rigol.set_sweep_points(int(self.points.value()))
        self.safe(f)
    def set_trace(self,t): self.safe(lambda:self.rigol.set_trace_type(int(self.tr.currentText()),t))

    def refresh_live(self):
        if not self.rigol.connected: return
        try:
            y=self.rigol.trace_ascii(int(self.tr.currentText()))
            if y.size<2: return
            c=self.rigol.center_hz()/1e6; s=self.rigol.span_hz()/1e6
            x = [c-s/2 + i*s/(len(y)-1) for i in range(len(y))]
            self.curve.setData(x,y)
            self.status.setText(f"Live: {len(y)} точек")
        except Exception as e:
            self.status.setText("Live error: "+str(e))

    def closeEvent(self,e):
        self.timer.stop(); self.rigol.close(); super().closeEvent(e)

app=QtWidgets.QApplication(sys.argv)
w=Main(); w.show()
sys.exit(app.exec())
