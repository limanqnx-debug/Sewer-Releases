# Sewer Python DEV1 — Rigol branch

Первое ответвление Sewer на Python. Цель DEV1 — повторить уже проверенный блок Rigol Control отдельно от стабильной PowerShell-ветки.

## Уже перенесено
- подключение RSA5065N через PyVISA;
- GPSA / RTSA;
- Center / Span;
- Ref Level / Ref Offset / Scale/Div / Attenuation;
- RBW / VBW;
- Sweep Time / Sweep Points;
- Continuous / Single;
- Trace 1..6;
- Clear/Write / Max Hold / Average / Min Hold;
- Live Spectrum через pyqtgraph;
- интервал Live по умолчанию 300 мс.

## Запуск
1. Установить Python 3.11+ x64.
2. Запустить `install.bat`.
3. В `config.json` указать VISA resource Rigol.
4. Запустить `run.bat`.

Для USB можно указать прежний ресурс вида:
`USB::0x1AB1::0x0968::RSA5F274300290::INSTR`

Для Ethernet:
`TCPIP::<IP>::INSTR`

## Важно
Это отдельная DEV-ветка. Стабильная PowerShell-версия Sewer не изменяется.
Источник питания, Programmer, прошивка и основной производственный workflow пока не перенесены — это следующий этап после проверки Rigol Python DEV1 на реальном RSA5065N.


## DEV1 UI FIX2
- Для RBW/VBW изменено направление колеса мыши: вверх -> полоса шире, вниз -> уже.
- Остальная логика не изменена.
