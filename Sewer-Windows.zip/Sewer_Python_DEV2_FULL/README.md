# Sewer Python DEV2 Full

Первый полный перенос Sewer с PowerShell на Python.

## Перенесено
- OWON SPE3102 по COM / SCPI;
- проверка и восстановление заданных ограничений V/I перед каждым Start/Repeat;
- контроль тока платы и пороги защиты;
- запуск Programmer с подстановкой `{FW}`;
- чтение процентов Programmer из stdout/stderr;
- Start / Repeat / Stop / Exit и горячие клавиши;
- журнал Sewer и диагностический лог Programmer;
- опциональное автоотключение источника после успеха;
- запуск сторонней программы и импульс после её закрытия;
- Rigol RSA5065N через PyVISA;
- GPSA / RTSA, Center / Span, Ref Level / Ref Offset / Scale/Div / Attenuation;
- RBW / VBW, Sweep Time в ms, Sweep Points;
- Trace 1..6 и Live Spectrum;
- Scale/Div только целые 1…20 dB/div с шагом 1;
- RBW/VBW: колесо вверх = полоса шире;
- окно настроек и сохранение `config.json`.

## Запуск
1. Установить Python 3.11+ x64.
2. Запустить `install.bat` один раз.
3. Проверить `config.json` / настройки в программе.
4. Для диагностики использовать `run-console.bat`, для обычной работы — `run.bat`.

## Важно
Это DEV2: код синтаксически проверен, но цикл питания и Programmer должен пройти стендовую проверку на реальном OWON/Programmer перед заменой стабильной PowerShell-версии.
