from __future__ import annotations

import unittest
import numpy as np

from test_rigol_live import FakeVisa
from sewer.rigol import RigolRSA, RigolConnectionError, parse_trace_ascii


class TerminatedVisa(FakeVisa):
    def read_raw(self):
        # This transport provides LF termination but no EOM. v1.0.19 times out.
        if self.read_termination is None:
            raise TimeoutError("No VISA EOM")
        return super().read_raw()

    def query(self, command):
        reply=super().query(command)
        if command.startswith(":TRACe:DATA?") and self.read_termination and self.read_termination in reply:
            return reply.split(self.read_termination,1)[0]
        return reply


class CompatibilityTests(unittest.TestCase):
    def test_usb_vxi11_and_socket_read_multiline_block_without_disabling_lf(self):
        values=np.full(801,-95.0);values[650]=-12.0
        payload=",\n".join(str(x) for x in values)
        block=f"#{len(str(len(payload)))}{len(payload)}{payload}\n"
        for resource in ("USB0::0x1AB1::0x0968::TEST::INSTR","TCPIP0::192.0.2.1::inst0::INSTR","TCPIP0::192.0.2.1::5555::SOCKET"):
            with self.subTest(resource=resource):
                visa=TerminatedVisa();visa.bad_reply=block
                # v1.0.18's LF-terminated query returns an incomplete IEEE block.
                with self.assertRaisesRegex(ValueError,"Неполный ответ"):
                    parse_trace_ascii(visa.query(":TRACe:DATA? TRACE1"))
                rigol=RigolRSA(resource);rigol.dev=visa;visa.commands.clear()
                result=rigol.trace_ascii(1)
                np.testing.assert_array_equal(result,values)
                self.assertEqual(visa.read_termination,"\n")
                self.assertEqual(set(visa.terminators),{"\n"})
                self.assertEqual(visa.buffer,b"")
                self.assertEqual(visa.commands,[":FORMat:TRACe:DATA ASCii",":TRACe:DATA? TRACE1"])
                self.assertEqual(rigol.center_hz(),433920000)
                visa.bad_reply=TimeoutError("transport timeout")
                with self.assertRaises(RigolConnectionError):rigol.trace_ascii()
                self.assertEqual(visa.read_termination,"\n")
                self.assertFalse(rigol.connected)
                rigol.close()

    def test_optional_metadata_cannot_block_a_valid_trace(self):
        visa=FakeVisa();base_query=visa.query
        required={":INSTrument:SELect?",":SENSe:FREQuency:CENTer?",":SENSe:FREQuency:SPAN?",":UNIT:POWer?",":TRACe:DATA? TRACE1"}
        def minimal_query(cmd):
            if cmd not in required:
                raise AssertionError("Ancillary query in live path: "+cmd)
            return base_query(cmd)
        visa.query=minimal_query
        rigol=RigolRSA("TEST");rigol.dev=visa
        frame=rigol.spectrum()
        self.assertEqual(frame.y.size,801)
        self.assertGreater(frame.y.max(),-30)
        self.assertIsNone(frame.display_on)
        self.assertIsNone(frame.y_limits)
        self.assertIsNone(frame.trace_type)
        rigol.close()

    def test_socket_keeps_termination_and_incomplete_blocks_still_fail(self):
        visa=TerminatedVisa();rigol=RigolRSA("TCPIP0::192.0.2.1::5555::SOCKET");rigol.dev=visa
        np.testing.assert_allclose(rigol.trace_ascii(),parse_trace_ascii(FakeVisa().query(":TRACe:DATA? TRACE1")))
        self.assertEqual(visa.read_termination,"\n")
        visa.bad_reply="#41000-90,-20"
        with self.assertRaisesRegex(RigolConnectionError,"Неполный ответ"):rigol.trace_ascii()
        self.assertFalse(rigol.connected)
        rigol.close()

    def test_front_panel_point_change_refreshes_frequency_axis(self):
        visa=FakeVisa();rigol=RigolRSA("TEST");rigol.dev=visa
        rigol.sweep_points()
        visa.points=10001
        frame=rigol.spectrum()
        self.assertEqual(frame.x_unit,"MHz")
        self.assertEqual(frame.y.size,10001)
        self.assertFalse(frame.warnings)
        np.testing.assert_allclose(frame.x[[0,-1]],[423.92,443.92])
        rigol.close()


if __name__=="__main__":unittest.main()
