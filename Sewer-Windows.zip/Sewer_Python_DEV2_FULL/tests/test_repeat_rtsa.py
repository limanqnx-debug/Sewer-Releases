"""Regression checks for production measurements and the RTSA quick action."""
from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import Mock, patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from PySide6 import QtCore, QtWidgets

from sewer.controller import SewerController
from sewer.gui import MainWindow
from test_rigol_live import FakeVisa


class SerialSupply:
    def __init__(self):
        self.is_open = True
        self.output_on = False
        self.voltage = 23.75
        self.current = .045
        self.limit_v = 24.0
        self.limit_i = .3
        self.commands = []
        self.threads = []
        self.pending = None
        self.gate = None
        self.entered = threading.Event()

    def reset_input_buffer(self):
        assert self.pending is None, "Concurrent serial query"

    def write(self, payload):
        command = payload.decode().strip()
        self.commands.append(command)
        self.threads.append(threading.get_ident())
        if command.endswith("?"):
            assert self.pending is None
            self.pending = command
        elif command.startswith("OUTPut "):
            self.output_on = command.endswith("ON")
        elif command.startswith("VOLTage "):
            self.limit_v = float(command.split()[1])
        elif command.startswith("CURRent "):
            self.limit_i = float(command.split()[1])

    def flush(self):
        pass

    def readline(self):
        command = self.pending
        self.entered.set()
        if self.gate and not self.gate.wait(3):
            raise TimeoutError("Simulated serial timeout")
        self.pending = None
        value = {"VOLTage?": self.limit_v, "CURRent?": self.limit_i,
                 "MEASure:VOLTage?": self.voltage if self.output_on else 0,
                 "MEASure:CURRent?": self.current if self.output_on else 0}[command]
        return f"{value}\n".encode()

    def close(self):
        self.is_open = False


class RepeatRtsaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.root = Path(__file__).resolve().parents[1]
        config = json.loads((self.root / "config.json").read_text(encoding="utf-8-sig"))
        for key in ("ExecutablePath", "FirmwarePath"):
            path = root / key
            path.touch()
            config["Programmer"][key] = str(path)
        config["PowerSupply"].update(CurrentSamples=2, SampleDelayMs=0)
        config["Logging"]["Enabled"] = False
        self.tick = SewerController.tick
        with patch.object(SewerController, "tick", lambda self: None):
            self.c = SewerController(root, root / "config.json", config)
        self.c.timer.stop()
        self.c._next_rigol_probe = float("inf")
        self.serial = SerialSupply()
        self.c.power.port = self.serial
        self.c.power.snapshot.com_available = True
        self.c.power.snapshot.responding = True
        self.port_patch = patch.object(self.c.power, "com_available", return_value=True)
        self.port_patch.start()
        self.c.programmer.start = Mock(return_value=True)
        self.c.update_readiness()
        self.w = MainWindow(self.c)
        self.w.show()
        self.app.processEvents()

    def tearDown(self):
        if self.serial.gate:
            self.serial.gate.set()
        self.c._executor.shutdown(wait=True)
        self.app.processEvents()
        self.w.close()
        self.app.processEvents()
        self.port_patch.stop()
        self.tmp.cleanup()

    def wait_for(self, condition):
        deadline = time.monotonic() + 3
        while not condition() and time.monotonic() < deadline:
            self.app.processEvents()
            time.sleep(.005)
        self.app.processEvents()
        self.assertTrue(condition())

    def poll_power(self):
        self.c._next_power_probe = 0
        self.tick(self.c)
        self.wait_for(lambda: not self.c._power_probe_pending)

    def enter_programming(self, button):
        button.click()
        self.wait_for(lambda: self.c.state == "PowerDelay")
        self.c.deadline = 0
        self.tick(self.c)
        self.wait_for(lambda: self.c.state == "Programming")

    def test_start_then_repeat_read_real_voltage_and_limits_each_time(self):
        self.enter_programming(self.w.start_btn)
        self.assertEqual(self.w.out_v.text(), "23.75 В")
        self.serial.voltage = 23.42
        self.serial.current = .052
        self.poll_power()
        self.assertEqual(self.w.out_v.text(), "23.42 В")
        self.assertEqual(self.w.out_i.text(), "52.0 мА")
        self.c._programmer_finished(0)
        self.assertEqual(self.w.out_v.text(), "0.00 В")
        self.assertTrue(self.w.repeat_btn.isEnabled())
        self.serial.voltage = 23.91
        self.serial.limit_v = 22
        self.enter_programming(self.w.repeat_btn)
        self.assertEqual(self.serial.limit_v, 24)
        self.assertEqual(self.w.out_v.text(), "23.91 В")
        self.serial.voltage = 23.89
        self.poll_power()
        self.assertEqual(self.w.out_v.text(), "23.89 В")
        self.assertEqual(self.serial.commands.count("CURRent?"), 2)
        self.c.stop_cycle()
        self.assertFalse(self.serial.output_on)
        self.assertEqual(self.w.out_v.text(), "0.00 В")

    def test_polling_continues_through_power_external_and_pulse_without_writes(self):
        self.c.power.output(True)
        self.c.external.process = Mock()
        self.c.external.poll = Mock(return_value=None)
        for index, state in enumerate(("PowerDelay", "Programming", "ExternalProgram", "PulseOn")):
            with self.subTest(state=state):
                self.c.state = state
                self.c.deadline = float("inf")
                self.serial.voltage = 23 + index / 10
                self.serial.commands.clear()
                self.serial.threads.clear()
                self.poll_power()
                self.assertEqual(self.w.out_v.text(), f"{self.serial.voltage:.2f} В")
                self.assertEqual(self.serial.commands, ["MEASure:VOLTage?", "MEASure:CURRent?"])
                self.assertNotIn(threading.get_ident(), self.serial.threads)
        self.c.external.process = None

    def test_slow_probe_does_not_queue_duplicate_queries_or_block_gui(self):
        self.c.state = "Programming"
        self.c.power.output(True)
        self.serial.gate = threading.Event()
        self.c._next_power_probe = 0
        self.tick(self.c)
        self.wait_for(self.serial.entered.is_set)
        for _ in range(10):
            self.tick(self.c)
        events = []
        QtCore.QTimer.singleShot(0, lambda: events.append(True))
        self.wait_for(lambda: bool(events))
        self.assertEqual(self.serial.commands.count("MEASure:VOLTage?"), 1)
        self.serial.gate.set()
        self.wait_for(lambda: not self.c._power_probe_pending)

    def test_active_poll_never_reconnects_disconnected_supply(self):
        self.c.state = "Programming"
        self.serial.is_open = False
        with patch.object(self.c.power, "connect") as connect:
            self.poll_power()
        connect.assert_not_called()
        self.assertFalse(self.c.power.snapshot.responding)

    def test_no_board_and_overcurrent_still_stop_before_programming(self):
        for current in (0, .15):
            with self.subTest(current=current):
                self.c.power.snapshot.responding = True
                self.c.power.output(True)
                self.c.stop_requested = False
                self.c.state = "CurrentCheck"
                self.serial.current = current
                self.c._start_current_check()
                self.wait_for(lambda: not self.c._busy)
                self.assertEqual(self.c.state, "Idle")
                self.assertFalse(self.serial.output_on)
                self.c.programmer.start.assert_not_called()

    def test_rtsa_button_sets_span_and_refreshes_open_spectrum(self):
        visa = FakeVisa()
        visa.mode = "RTSA"
        self.c.rigol.dev = visa
        self.c.rigol_connected = True
        self.c.rigol_mode = "RTSA"
        self.c.updated.emit()
        self.w.open_rigol()
        dialog = self.w.rigol_dialog
        dialog.live.setChecked(False)
        dialog.markers.reader.set_enabled(False)
        self.wait_for(lambda: not dialog.live_reader._pending and not dialog.markers.reader._poll_pending)
        for hz,text in ((500_000,"0.5"),(1_000_000,"1"),(1_500_000,"1.5"),(2_000_000,"2")):
            with self.subTest(span=hz):
                visa.commands.clear()
                self.w.rig_span_buttons[hz].click()
                self.wait_for(lambda: not self.c._rigol_action_pending)
                self.wait_for(lambda: dialog.live_reader.frame is not None and dialog.live_reader.frame.span_hz == hz)
                self.assertEqual(visa.span, hz)
                self.assertEqual(dialog.span.text(), text)
                self.assertEqual(visa.center, 433920000)
                # Live may reassert the ASCII transfer format when refreshing the trace.
                writes = [cmd for cmd in visa.commands if "?" not in cmd and cmd != ":FORMat:TRACe:DATA ASCii"]
                self.assertEqual(writes, [f":SENSe:FREQuency:SPAN {float(hz)}"])
                self.assertTrue(all(b.isEnabled() for b in self.w.rig_span_buttons.values()))
        self.assertIn("Span 500 кГц", self.w.log.toPlainText())
        dest = os.environ.get("SEWER_QA_DIR")
        if dest:
            Path(dest).mkdir(parents=True, exist_ok=True)
            self.w.grab().save(str(Path(dest) / "main-rtsa-presets.png"))

    def test_span_button_guards_gpsa_disconnect_and_front_panel_mode_change(self):
        self.assertTrue(all(not b.isEnabled() for b in self.w.rig_span_buttons.values()))
        visa = FakeVisa()
        self.c.rigol.dev = visa
        self.c.rigol_connected = True
        self.c.updated.emit()
        self.assertTrue(all(not b.isEnabled() for b in self.w.rig_span_buttons.values()))
        self.c.rigol_mode = "RTSA"  # The actual instrument is already back in GPSA.
        self.c.updated.emit()
        self.w.rig_span_btn.click()
        self.wait_for(lambda: not self.c._rigol_action_pending)
        self.assertEqual(visa.commands, [":INSTrument:SELect?"])
        self.assertIn("RTSA", self.c.rigol_error)
        self.assertEqual(visa.span, 20e6)

    def test_span_reports_actual_value_instead_of_requested_value(self):
        visa = FakeVisa()
        visa.mode = "RTSA"
        original_write = visa.write
        def write(command):
            original_write(command)
            if command.startswith(":SENSe:FREQuency:SPAN "):
                visa.span = 1e6
        visa.write = write
        self.c.rigol.dev = visa
        self.c.rigol_connected = True
        self.c.rigol_mode = "RTSA"
        results = []
        self.c.rigol_span_changed.connect(results.append)
        self.c.set_rigol_rtsa_span()
        self.wait_for(lambda: not self.c._rigol_action_pending)
        self.assertEqual(results, [1e6])
        self.assertIn("Span 1000 кГц", self.w.log.toPlainText())


if __name__ == "__main__":
    unittest.main()
