from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import Mock, patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from PySide6 import QtCore, QtTest, QtWidgets
import pyvisa

from sewer.controller import SewerController
from sewer.gui import MainWindow
from sewer.path_picker import PathPicker
from sewer.rigol_local import find_browser, web_host
from test_repeat_rtsa import SerialSupply
from test_rigol_connection import FakeManager
from test_rigol_markers import MarkerVisa


class HotkeyReleaseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        source = Path(__file__).resolve().parents[1]
        config = json.loads((source / "config.json").read_text(encoding="utf-8-sig"))
        config["Logging"]["Enabled"] = False
        config["PowerSupply"].update(CurrentSamples=2, SampleDelayMs=0)
        config["Rigol"]["Resource"] = "TCPIP0::192.0.2.1::INSTR"
        self.tick = SewerController.tick
        with patch.object(SewerController, "tick", lambda self: None):
            self.c = SewerController(root, root / "config.json", config)
        self.c.timer.stop()
        self.c._next_rigol_probe = self.c._next_power_probe = float("inf")
        self.serial = SerialSupply()
        self.c.power.port = self.serial
        self.c.power.snapshot.com_available = self.c.power.snapshot.responding = True
        self.c.programmer.start = Mock(return_value=True)
        self.visa = MarkerVisa()
        self.c.rigol.dev = self.visa
        self.c.rigol_connected = True
        self.c.update_readiness()
        self.w = MainWindow(self.c)
        self.w.show()
        self.w.activateWindow()
        self.app.processEvents()

    def tearDown(self):
        if self.serial.gate:
            self.serial.gate.set()
        if self.visa.gate:
            self.visa.gate.set()
        self.c._executor.shutdown(wait=True)
        self.app.processEvents()
        self.w.close()
        self.app.processEvents()
        self.tmp.cleanup()

    def wait_for(self, condition):
        deadline = time.monotonic() + 4
        while not condition() and time.monotonic() < deadline:
            self.app.processEvents()
            time.sleep(.005)
        self.app.processEvents()
        self.assertTrue(condition())

    def press(self, key, modifiers, window=None):
        target = window or self.w
        target.activateWindow()
        self.app.processEvents()
        QtTest.QTest.keyClick(target, key, modifiers)
        self.app.processEvents()

    def finish_power_check(self):
        self.wait_for(lambda: self.c.state == "PowerDelay")
        self.c.deadline = 0
        self.tick(self.c)
        self.wait_for(lambda: not self.c._busy)

    def test_alt_c_replaces_alt_space_in_main_and_control_window(self):
        self.press(QtCore.Qt.Key_Space, QtCore.Qt.AltModifier)
        self.assertEqual(self.visa.mode, "SA")
        self.press(QtCore.Qt.Key_C, QtCore.Qt.AltModifier)
        self.assertEqual(self.visa.mode, "RTSA")
        self.w.open_rigol()
        dialog = self.w.rigol_dialog
        self.press(QtCore.Qt.Key_C, QtCore.Qt.AltModifier, dialog)
        self.assertEqual(self.visa.mode, "SA")

    def test_alt_z_checks_limits_without_programmer_and_esc_stops(self):
        self.assertFalse(self.c.ready)  # The programmer and firmware are absent.
        self.serial.limit_v = 22
        self.serial.limit_i = .5
        self.press(QtCore.Qt.Key_Z, QtCore.Qt.AltModifier)
        self.finish_power_check()
        self.assertEqual(self.c.state, "ManualPower")
        self.assertTrue(self.serial.output_on)
        self.assertEqual((self.serial.limit_v, self.serial.limit_i), (24, .3))
        self.c.programmer.start.assert_not_called()
        commands = list(self.serial.commands)
        self.press(QtCore.Qt.Key_Z, QtCore.Qt.AltModifier)
        self.assertEqual(self.serial.commands, commands)
        self.press(QtCore.Qt.Key_Escape, QtCore.Qt.NoModifier)
        self.assertFalse(self.serial.output_on)
        self.assertEqual(self.c.state, "Idle")

    def test_manual_power_trip_and_missing_board_are_not_bypassed(self):
        for current in (0, .15):
            with self.subTest(current=current):
                self.serial.current = current
                self.c.power_on()
                self.finish_power_check()
                self.assertEqual(self.c.state, "Idle")
                self.assertFalse(self.serial.output_on)
                self.c.programmer.start.assert_not_called()

    def test_power_button_switches_manual_output_on_and_off(self):
        self.assertTrue(self.w.ps_power_btn.isEnabled())
        self.w.ps_power_btn.click()
        self.finish_power_check()
        self.assertEqual(self.c.state, "ManualPower")
        self.assertTrue(self.serial.output_on)
        self.c.programmer.start.assert_not_called()
        self.assertTrue(self.w.ps_power_btn.isEnabled())
        self.assertTrue(self.w.ps_power_btn.active)
        self.assertIn("Выключить", self.w.ps_power_btn.accessibleName())
        self.w.ps_power_btn.click()
        self.assertFalse(self.serial.output_on)
        self.assertEqual(self.c.state, "Idle")
        self.assertFalse(self.w.ps_power_btn.active)
        self.assertTrue(self.w.ps_power_btn.isEnabled())

    def test_power_toggle_does_not_interrupt_programming(self):
        self.serial.output_on = self.c.power.snapshot.output_on = True
        self.c.state = "Programming"
        self.w.refresh()
        self.assertFalse(self.w.ps_power_btn.isEnabled())
        commands = list(self.serial.commands)
        self.c.toggle_manual_power()
        self.assertEqual(self.serial.commands, commands)
        self.assertTrue(self.serial.output_on)

    def test_screenshot_settings_keep_power_on_and_save_folder_and_name(self):
        self.serial.output_on = self.c.power.snapshot.output_on = True
        previous_resource = self.c.rigol.resource

        self.w.settings_btn.click()
        settings = self.w.settings_page
        self.assertIs(settings.window(), self.w)
        self.assertIn("Скриншоты", [settings.tabs.tabText(i) for i in range(settings.tabs.count())])
        settings.controls["rig.shot_folder"].setText("Мои снимки")
        settings.controls["rig.shot_name"].setText("Спектр.png")
        settings.buttons.button(QtWidgets.QDialogButtonBox.Save).click()
        saved = json.loads(self.c.config_path.read_text(encoding="utf-8-sig"))
        self.assertEqual(saved["RigolScreenshot"]["Folder"], "Мои снимки")
        self.assertEqual(saved["RigolScreenshot"]["BaseName"], "Спектр")
        self.assertTrue(self.serial.output_on)
        self.assertEqual(self.c.rigol.resource, previous_resource)
        self.assertIs(self.w.pages.currentWidget(), self.w.dashboard)

    def test_settings_folder_picker_and_errors_stay_in_main_window(self):
        folder = self.c.root / "Снимки Rigol"
        folder.mkdir()
        self.w.settings_btn.click()
        page = self.w.settings_page
        page.tabs.setCurrentIndex(next(i for i in range(page.tabs.count()) if page.tabs.tabText(i) == "Скриншоты"))
        browse = page.tabs.currentWidget().findChild(QtWidgets.QPushButton)
        browse.click()
        picker = page.detail
        self.assertIsInstance(picker, PathPicker)
        self.assertIs(picker.window(), self.w)
        self.assertFalse(picker.isWindow())
        picker.path.setText(str(folder / "нет такой папки"))
        picker.accept()
        self.assertTrue(picker.error.isVisible())
        self.assertIs(page.detail, picker)
        picker.path.setText(str(folder))
        picker.accept()
        self.assertIsNone(page.detail)
        self.assertEqual(Path(page.controls["rig.shot_folder"].text()).resolve(), folder.resolve())

        name = page.controls["rig.shot_name"]
        name.setText("Спектр")
        name.setFocus()
        self.w.repeat_btn.setEnabled(True)
        with patch.object(self.c, "start_cycle") as start:
            QtTest.QTest.keyClick(name, QtCore.Qt.Key_Space)
            self.assertEqual(name.text(), "Спектр ")
            start.assert_not_called()

        page.controls["ps.port"].setEditText("")
        page.buttons.button(QtWidgets.QDialogButtonBox.Save).click()
        self.assertIs(self.w.settings_page, page)
        self.assertIn("COM-порт", page.error_label.text())
        self.assertTrue(page.error_label.isVisible())
        page.back_button.click()
        self.assertIsNone(self.w.settings_page)

    def test_escape_stops_power_from_settings_before_navigating_back(self):
        self.serial.output_on = self.c.power.snapshot.output_on = True
        self.w.refresh()
        self.w.settings_btn.click()
        self.assertTrue(self.w.settings_page.stop_button.isEnabled())
        self.press(QtCore.Qt.Key_Escape, QtCore.Qt.NoModifier)
        self.assertFalse(self.serial.output_on)
        self.assertIsNotNone(self.w.settings_page)
        self.press(QtCore.Qt.Key_Escape, QtCore.Qt.NoModifier)
        self.assertIsNone(self.w.settings_page)

    def test_screenshot_runs_off_thread_and_does_not_release_rigol(self):
        gate = threading.Event()
        started = threading.Event()
        path = self.c.root / "снимки" / "Спектр_001.png"
        self.c.config["RigolScreenshot"] = {
            "Folder": "снимки", "BaseName": "Спектр", "FillGaps": True,
        }
        ui_thread = threading.get_ident()
        calls = []

        def capture(resource, folder, base, fill_gaps, cancel):
            calls.append((threading.get_ident(), resource, folder, base, fill_gaps))
            started.set()
            self.assertTrue(gate.wait(2))
            return path

        with patch("sewer.controller.capture_rigol_screenshot", side_effect=capture) as worker:
            try:
                self.w.rig_screenshot_btn.click()
                self.wait_for(lambda: started.is_set() or not self.c.screenshot_busy)
                self.assertTrue(started.is_set(), self.w.log.toPlainText())
                thread, resource, folder, base, fill_gaps = calls[0]
                self.assertNotEqual(thread, ui_thread)
                self.assertEqual(resource, self.c.rigol.resource)
                self.assertEqual((folder.resolve(), base, fill_gaps), (path.parent.resolve(), "Спектр", True))
                self.assertFalse(self.w.rig_screenshot_btn.isEnabled())
                self.c.take_rigol_screenshot()
                self.c.release_rigol()
                self.assertFalse(self.c.rigol.suspended)
                self.assertEqual(worker.call_count, 1)
            finally:
                gate.set()
            self.wait_for(lambda: not self.c.screenshot_busy)
            self.assertIn(str(path), self.w.log.toPlainText())
            self.assertTrue(self.c.rigol.connected)

    def test_manual_power_stays_monitored_and_stops_on_later_overcurrent(self):
        self.c.power_on()
        self.finish_power_check()
        self.assertEqual(self.c.state, "ManualPower")
        self.serial.current = .15
        self.c._next_power_probe = 0
        self.tick(self.c)
        self.wait_for(lambda: not self.c._power_probe_pending)
        self.assertFalse(self.serial.output_on)
        self.assertEqual(self.c.state, "Idle")

    def test_stop_during_limit_check_cannot_turn_the_supply_back_on(self):
        self.serial.gate = threading.Event()
        self.c.power_on()
        self.wait_for(self.serial.entered.is_set)
        self.c.power.output = Mock(wraps=self.c.power.output)
        # Let the current serial query finish so Stop can acquire the port lock.
        self.serial.gate.set()
        self.c.stop_cycle()
        self.wait_for(lambda: not self.c._busy)
        self.assertFalse(self.serial.output_on)
        self.assertNotIn(unittest.mock.call(True), self.c.power.output.call_args_list)

    def test_release_blocks_all_pollers_then_hotkey_reconnects_new_session(self):
        self.w.open_rigol()
        dialog = self.w.rigol_dialog
        self.wait_for(lambda: dialog.live_reader.frame is not None and not dialog.live_reader._pending)
        self.visa.gate = threading.Event()
        self.visa.trace_started.clear()
        dialog.live_reader.refresh(force=True)
        self.wait_for(self.visa.trace_started.is_set)
        called = []
        def release(resource, cancel):
            self.assertTrue(self.visa.closed)
            called.append(resource)
        with patch("sewer.rigol_local.release_via_web", release):
            self.press(QtCore.Qt.Key_C, QtCore.Qt.ControlModifier | QtCore.Qt.AltModifier, dialog)
            self.assertTrue(self.c.rigol.suspended)
            self.assertFalse(dialog.live_timer.isActive())
            self.assertFalse(dialog.markers.reader.timer.isActive())
            self.visa.gate.set()
            self.wait_for(lambda: not self.c._rigol_connection_pending and not dialog.live_reader._pending)
        self.assertEqual(called, ["TCPIP0::192.0.2.1::INSTR"])
        self.assertFalse(self.c.rigol.connected)
        self.assertEqual(self.w.rig_access_btn.text(), "Подключить")
        commands = list(self.visa.commands)
        with patch("sewer.rigol.pyvisa.ResourceManager") as manager:
            for _ in range(8):
                self.c._next_rigol_probe = 0
                self.tick(self.c)
                dialog.live_reader.refresh(force=True)
                dialog.markers.reader.refresh(force=True)
                dialog.apply_span()
            self.app.processEvents()
            manager.assert_not_called()
        self.assertEqual(self.visa.commands, commands)
        # A late result from the old monitor cannot restore the old connection.
        self.c._rigol_probe_done((True,"GPSA",""),None,0)
        self.assertFalse(self.c.rigol_connected)
        replacement = MarkerVisa()
        replacement.mode = "RTSA"
        manager = FakeManager(replacement)
        with patch("sewer.rigol.pyvisa.ResourceManager", return_value=manager):
            self.press(QtCore.Qt.Key_C, QtCore.Qt.ControlModifier | QtCore.Qt.AltModifier, dialog)
            self.wait_for(lambda: not self.c._rigol_connection_pending)
            self.wait_for(lambda: dialog.live_reader.frame is not None and dialog.live_reader.frame.mode == "RTSA")
        self.assertFalse(self.c.rigol.suspended)
        self.assertTrue(self.c.rigol_connected)
        self.assertEqual(self.w.rig_access_btn.text(), "Освободить")
        self.assertEqual(len(manager.opens), 1)

    def test_failed_web_release_stays_paused_and_reports_reason(self):
        with patch("sewer.rigol_local.release_via_web", side_effect=RuntimeError("Web Control выключен")):
            self.c.release_rigol()
            self.wait_for(lambda: not self.c._rigol_connection_pending)
        self.assertTrue(self.c.rigol.suspended)
        self.assertFalse(self.c.rigol_connected)
        self.assertTrue(self.visa.closed)
        self.assertIn("не подтверждено", self.w.log.toPlainText())
        self.assertIn("Web Control выключен", self.c.rigol_error)

    def test_usb_uses_gtl_and_closes_without_new_queries(self):
        self.c.rigol.resource = "USB0::TEST::INSTR"
        self.visa.control_ren = Mock()
        with patch("sewer.rigol_local.release_via_web") as web:
            self.c.release_rigol()
            self.wait_for(lambda: not self.c._rigol_connection_pending)
        self.visa.control_ren.assert_called_once_with(pyvisa.constants.RENLineOperation.deassert_gtl)
        self.assertTrue(self.visa.closed)
        self.assertEqual(self.visa.commands, [])
        web.assert_not_called()


class WebReleaseHelpersTests(unittest.TestCase):
    def test_resource_uses_ethernet_host_without_changing_scpi_port(self):
        self.assertEqual(web_host("TCPIP0::192.168.1.102::INSTR"), "192.168.1.102")
        self.assertEqual(web_host("TCPIP0::rsa5065::5025::SOCKET"), "rsa5065")
        with self.assertRaises(ValueError):
            web_host("TCPIP0::example.org/path::INSTR")
        with self.assertRaises(ValueError):
            web_host("USB0::TEST::INSTR")

    def test_widget_browser_is_preferred_with_edge_fallback(self):
        with tempfile.TemporaryDirectory() as temp, patch.dict(os.environ,{"LOCALAPPDATA":temp,"PROGRAMFILES":temp,"PROGRAMFILES(X86)":temp}):
            edge = Path(temp) / "Microsoft/Edge/Application/msedge.exe"
            edge.parent.mkdir(parents=True); edge.touch()
            self.assertEqual(find_browser(), edge)
            yandex = Path(temp) / "Yandex/YandexBrowser/Application/browser.exe"
            yandex.parent.mkdir(parents=True); yandex.touch()
            self.assertEqual(find_browser(), yandex)


if __name__ == "__main__":
    unittest.main()
