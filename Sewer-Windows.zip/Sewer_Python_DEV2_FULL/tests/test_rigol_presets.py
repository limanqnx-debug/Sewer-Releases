import copy
import json
import math
import os
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from PySide6 import QtWidgets
from sewer.rigol_presets import *
from sewer.rigol_preset_editor import PresetEditor
import test_repeat_rtsa as fixture


class PresetRigol:
    def __init__(self):
        self.resource = "TCPIP0::192.0.2.1::INSTR"
        self.lock=threading.RLock();self.connected=True;self.suspended=False;self._readbacks={}
        self.commands=[];self.values={':INSTrument:SELect':'SA',':SENSe:FREQuency:SPAN':'100000000'}
        self.round_span=False;self.idn="RIGOL,RSA5065N";self.release_cancel=threading.Event()
        self.close=lambda:None
    def _require_control(self):
        if self.suspended: raise ValueError('Освобождён')
    def mode(self):return 'GPSA' if self.values[':INSTrument:SELect']=='SA' else 'RTSA'
    def span_hz(self):return float(self.values[':SENSe:FREQuency:SPAN'])
    def write(self,cmd):
        self.commands.append(cmd);key,value=cmd.split(' ',1)
        if self.round_span and key==':SENSe:FREQuency:SPAN':value='750000'
        self.values[key]=value.removesuffix('HZ')
    def query(self,cmd):
        if cmd=='*OPC?':return '1'
        if cmd==':SYSTem:ERRor?':return '0,"No error"'
        return self.values[cmd[:-1]]


class PresetTests(unittest.TestCase):
    def test_units_comma_markers_and_readback(self):
        r=PresetRigol();row=new_preset('Проверка')
        row.update(center='2400,5',span='.5',rbw='3',time='20',points=801,m1_freq='2400.6',m1_band='BPOW',m1_band_span='.1')
        result=apply_preset(r,row)
        self.assertIn(':SENSe:FREQuency:CENTer 2400500000',r.commands)
        self.assertIn(':SENSe:SWEep:TIME:AUTO OFF',r.commands)
        self.assertIn(':SENSe:SWEep:TIME 0.02',r.commands)
        self.assertIn(':CALCulate:MARKer1:MODE POS',r.commands)
        self.assertIn(':CALCulate:MARKer1:X 2400600000HZ',r.commands)
        self.assertIn(':CALCulate:MARKer1:FUNCtion:BAND:SPAN 100000',r.commands)
        self.assertEqual(result['differences'],[])
    def test_blank_does_not_write(self):
        r=PresetRigol();row=new_preset('Пусто');row.update(center='',span=None)
        with self.assertRaisesRegex(ValueError,'пуст'):apply_preset(r,row)
        self.assertEqual(r.commands,[])
    def test_invalid_entire_row_prevents_partial_write(self):
        for bad in (float('nan'),float('inf'),'oops',-1):
            r=PresetRigol();row=new_preset('Ошибка');row.update(center=2400,rbw=bad)
            with self.assertRaises(ValueError):apply_preset(r,row)
            self.assertEqual(r.commands,[])
    def test_enum_injection_and_fractional_points_rejected(self):
        for key,v in [('det','POS;*RST'),('points',801.5)]:
            row=new_preset('Ошибка');row[key]=v
            with self.assertRaises(ValueError):validate_row(row)
    def test_rtsa_incompatible_fields_prevent_mode_write(self):
        r=PresetRigol();row=new_preset('RTSA');row.update(mode='RTSA',points=801)
        with self.assertRaisesRegex(ValueError,'GPSA'):apply_preset(r,row)
        self.assertEqual(r.commands,[])
    def test_capture_auto_and_marker_off_roundtrip(self):
        r=PresetRigol()
        for key,(cmd,factor) in COMMANDS.items():
            r.values[cmd]='1' if key.endswith('_auto') else str(801 if key=='points' else 10)
        r.values[':TRACe1:TYPE']='WRIT'
        r.values[':SENSe:DETector:TRACe1:AUTO']='1'
        for n in range(1,4):r.values[f':CALCulate:MARKer{n}:MODE']='OFF'
        r.trace_type=lambda n:r.query(f':TRACe{n}:TYPE?')
        r.query_bool=lambda cmd:r.query(cmd) in ('1','ON')
        row=capture_preset(r,'С прибора')
        self.assertNotIn('rbw',row)
        self.assertEqual(row['rbw_auto'],'ON')
        self.assertEqual(row['m1_mode'],'OFF')
        result=apply_preset(r,row)
        self.assertEqual(result['differences'],[])
        self.assertIn(':CALCulate:MARKer1:MODE OFF',r.commands)

    def test_auto_and_value_conflict(self):
        row=new_preset('Auto');row.update(rbw=3,rbw_auto='ON')
        with self.assertRaises(ValueError):validate_row(row)
    def test_marker_function_conflict(self):
        row=new_preset('M1');row.update(m1_func='NOIS',m1_band='BPOW')
        with self.assertRaises(ValueError):validate_row(row)
    def test_zero_span_rejects_frequency_before_writes(self):
        r=PresetRigol();r.values[':SENSe:FREQuency:SPAN']='0';row=new_preset('M1');row['m1_freq']=10
        with self.assertRaises(ValueError):apply_preset(r,row)
        self.assertEqual(r.commands,[])
    def test_suspended_never_writes(self):
        r=PresetRigol();r.suspended=True;row=new_preset('M1');row['span']=1
        with self.assertRaises(ValueError):apply_preset(r,row)
        self.assertEqual(r.commands,[])
    def test_rounding_reported(self):
        r=PresetRigol();r.round_span=True;row=new_preset('RTSA');row['span']=.5
        self.assertTrue(apply_preset(r,row)['differences'])
    def test_store_unicode_backup_unknown_fields_and_cancel(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'rigol_presets.json';store=PresetStore(p);rows=copy.deepcopy(store.rows)
            rows[0].update(name='Измерение №1',future={'a':1});store.save(rows)
            old=p.read_bytes();rows[0]['center']='2400,5';store.save(rows)
            self.assertEqual(p.with_suffix('.backup.json').read_bytes(),old)
            self.assertEqual(PresetStore(p).rows[0]['future'],{'a':1})
            self.assertEqual(PresetStore(p).rows[0]['center'],2400.5)
    def test_corrupt_file_is_not_overwritten(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'rigol_presets.json';p.write_text('broken');s=PresetStore(p)
            self.assertTrue(s.error)
            with self.assertRaises(ValueError):s.save(s.rows)
            self.assertEqual(p.read_text(),'broken')
    def test_duplicate_names_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            s=PresetStore(Path(d)/'presets.json');rows=s.rows;rows[1]['name']=rows[0]['name']
            with self.assertRaises(ValueError):s.save(rows)


class PresetGuiTests(unittest.TestCase):
    setUpClass=classmethod(fixture.RepeatRtsaTests.setUpClass.__func__)
    setUp=fixture.RepeatRtsaTests.setUp
    tearDown=fixture.RepeatRtsaTests.tearDown
    def test_editor_available_only_in_hedgehog_settings(self):
        self.w.open_settings()
        settings=self.w.settings_page
        self.assertIn('Пресеты Rigol',[settings.tabs.tabText(i) for i in range(settings.tabs.count())])
        self.assertEqual(self.w.preset_combo.count(),3)
        self.assertFalse(self.w.preset_apply.isEnabled())
        settings.open_preset_editor()
        self.assertIs(settings.detail.window(), self.w)
        self.assertIsInstance(settings.detail, PresetEditor)
        settings.back_button.click()
        self.assertIsNone(settings.detail)
        self.assertIs(self.w.settings_page, settings)
        settings.back_button.click()
        self.assertIsNone(self.w.settings_page)
    def test_edit_copy_save_rename_reload_and_cancel(self):
        editor=PresetEditor(self.c,self.w);editor.show()
        editor.table.item(0,0).setText('Мой пресет')
        editor.copy_row();editor.accept()
        self.assertEqual(self.w.preset_combo.count(),4)
        self.assertEqual(self.w.preset_combo.itemText(0),'Мой пресет')
        p=self.c.presets.path;old=p.read_bytes()
        editor=PresetEditor(self.c,self.w);editor.table.item(0,0).setText('Отмена');editor.reject()
        self.assertEqual(p.read_bytes(),old)
    def test_async_apply_pauses_controls_and_resumes(self):
        r=PresetRigol();self.c.rigol=r;self.c.rigol_connected=True
        row=self.c.presets.rows[0];row['span']=.5
        gate=threading.Event()
        original_query=r.query
        def query(cmd):
            gate.wait(3)
            return original_query(cmd)
        r.query=query
        self.w.refresh();self.w.apply_selected_preset()
        self.assertFalse(self.w.preset_apply.isEnabled())
        gate.set()
        deadline=time.monotonic()+3
        while self.c._rigol_action_pending and time.monotonic()<deadline:
            self.app.processEvents();time.sleep(.01)
        self.assertFalse(self.c._rigol_action_pending)
        self.assertTrue(self.w.preset_apply.isEnabled())
        self.assertIn('Применён',self.w.preset_status.text())
        # Fixture cleanup expects the real Rigol API.
        r.close=lambda:None;r.release_cancel=threading.Event()
