from __future__ import annotations

import csv
import io
import json
import os
import tempfile
import time
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

import numpy as np
from PySide6 import QtCore, QtWidgets

from test_rigol_live import FakeVisa
from sewer.controller import SewerController
from sewer.gui import MainWindow
from sewer.rigol import RigolRSA, RigolConnectionError
from sewer.rigol_diagnostic import save_diagnostic


class CaptureTests(unittest.TestCase):
    def setUp(self):
        self.rigol=RigolRSA("TEST")
        self.visa=FakeVisa()
        self.rigol.dev=self.visa

    def tearDown(self):
        self.rigol.close()

    def test_export_preserves_raw_reply_and_all_samples(self):
        # Include a narrow single-bin peak in 10001 points: no decimation, smoothing, or fabricated samples.
        self.visa.points=10001
        values=np.full(10001,-93.125); values[7023]=-12.375
        payload=", ".join(map(str,values))+","
        self.visa.bad_reply=f"#{len(str(len(payload)))}{len(payload)}{payload}\r\n"
        frame=self.rigol.spectrum(3)
        before=list(self.visa.commands)
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/"capture.zip"
            save_diagnostic(path,frame.diagnostic,b"",{"frame_visible":True},"test")
            with zipfile.ZipFile(path) as z:
                self.assertEqual(z.read("trace-response.txt").decode(),self.visa.bad_reply)
                report=json.loads(z.read("report.json"))
                self.assertEqual(report["trace"],3)
                np.testing.assert_array_equal(report["samples"],values)
                rows=list(csv.reader(io.StringIO(z.read("trace.csv").decode())))
                self.assertEqual(len(rows),10002)
                self.assertEqual(float(rows[7024][2]),-12.375)
                self.assertEqual(float(rows[7024][1]),frame.x[7023])
        self.assertEqual(self.visa.commands,before)

    def test_count_mismatch_keeps_points_without_inventing_frequency_axis(self):
        self.rigol.sweep_points()
        self.visa.bad_reply="-90, -20, -91\n"
        frame=self.rigol.spectrum()
        capture=self.rigol.last_capture
        self.assertEqual(capture["received_points"],3)
        self.assertEqual(frame.x_label,"Номер точки")
        np.testing.assert_array_equal(frame.x,[0,1,2])
        self.assertTrue(frame.warnings)
        self.assertEqual(capture["samples"],[-90,-20,-91])
        self.assertTrue(any(e.get("response")==self.visa.bad_reply for e in capture["commands"]))

    def test_unknown_mode_and_trace_timeout_remain_diagnosable(self):
        self.visa.mode="VNA"
        with self.assertRaisesRegex(ValueError,"GPSA и RTSA"):
            self.rigol.spectrum()
        self.assertIn("error",self.rigol.last_capture)
        self.assertFalse(self.visa.trace_threads)
        self.visa.mode="SA"; self.visa.trace_format="ASC,8"
        self.visa.bad_reply=TimeoutError("test timeout")
        with self.assertRaises(RigolConnectionError): self.rigol.spectrum()
        self.assertEqual(self.rigol.last_capture["commands"][-1]["error"],"test timeout")


class PlotTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

    def test_instrument_scale_single_curve_and_gui_export(self):
        root=Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as temp,patch.object(SewerController,"tick",lambda self:None):
            config=json.loads((root/"config.json").read_text(encoding="utf-8-sig"))
            c=SewerController(root,Path(temp)/"config.json",config)
            v=FakeVisa(); c.rigol.dev=v; c.rigol_connected=True
            v.ref=10; v.scale=5
            # The optional instrument scale remains available alongside default auto Y.
            v.bad_reply=",".join(str(-37+np.sin(i/100)) for i in range(v.points))
            w=MainWindow(c)
            try:
                w.show(); w.open_rigol(); d=w.rigol_dialog
                deadline=time.monotonic()+3
                while d.live_reader.frame is None and time.monotonic()<deadline:
                    self.app.processEvents(); time.sleep(.005)
                self.assertIsNotNone(d.live_reader.frame,d.live_reader.status)
                self.assertTrue(d.auto_y.isChecked())
                d.auto_y.setChecked(False)
                d.live.setChecked(False)
                while d.live_reader._pending:
                    self.app.processEvents(); time.sleep(.005)
                frame=c.rigol.spectrum()
                d.live_reader.frame=frame
                for _ in range(5): d._show_live_frame(frame)
                np.testing.assert_allclose(d.plot.viewRange()[1],[-40,10])
                self.assertEqual(len(d.plot.listDataItems()),1)
                np.testing.assert_allclose(d.curve.getData()[1],frame.y)
                d.auto_y.setChecked(True); self.app.processEvents()
                self.assertTrue(d.plot.getViewBox().autoRangeEnabled()[1])
                d.auto_y.setChecked(False); self.app.processEvents()
                np.testing.assert_allclose(d.plot.viewRange()[1],[-40,10])
                path=Path(temp)/"gui-diagnostic.zip"
                before=list(v.commands)
                with patch.object(QtWidgets.QFileDialog,"getSaveFileName",return_value=(str(path),"ZIP (*.zip)")):
                    d.diagnostic_save.click()
                with zipfile.ZipFile(path) as z:
                    report=json.loads(z.read("report.json"))
                    self.assertEqual(report["display"]["view_range"][1],[-40,10])
                    self.assertTrue(z.read("sewer-rigol-window.png").startswith(b"\x89PNG\r\n\x1a\n"))
                    self.assertIn("-37.0",z.read("trace-response.txt").decode())
                self.assertEqual(v.commands,before)
                self.assertIn("Диагностика сохранена",d.diagnostic_status.text())
                self.assertTrue(w.log.isVisible())
                if os.environ.get("SEWER_QA_DIR"):
                    dest=Path(os.environ["SEWER_QA_DIR"]);dest.mkdir(parents=True,exist_ok=True)
                    d.diagnostic_status.clear();d.grab().save(str(dest/"rigol-diagnostic-simulated.png"))
            finally:
                w.close(); self.app.processEvents()


if __name__=="__main__": unittest.main()
