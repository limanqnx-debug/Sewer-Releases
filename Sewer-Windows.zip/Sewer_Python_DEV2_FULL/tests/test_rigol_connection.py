from __future__ import annotations

import json
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

import pyvisa
from PySide6 import QtWidgets, QtTest

from test_rigol_live import FakeVisa
from sewer.controller import SewerController
from sewer.gui import MainWindow
from sewer.rigol import RigolRSA, RigolConnectionError


class FakeManager:
    def __init__(self, device=None, error=None):
        self.device, self.error = device, error
        self.closed = False
        self.opens = []

    def open_resource(self, resource):
        self.opens.append(resource)
        if self.error:
            raise self.error
        return self.device

    def close(self):
        self.closed = True


class ConnectionTests(unittest.TestCase):
    def test_failed_open_releases_manager_and_reports_actual_error(self):
        manager = FakeManager(error=OSError("USB device unavailable"))
        rigol = RigolRSA("USB0::TEST::INSTR")
        with patch("sewer.rigol.pyvisa.ResourceManager", return_value=manager):
            with self.assertRaisesRegex(RigolConnectionError, "USB device unavailable"):
                rigol.connect()
        self.assertFalse(rigol.connected)
        self.assertTrue(manager.closed)
        self.assertIsNone(rigol.rm)
        self.assertIn("USB device unavailable", rigol.last_error)

    def test_failed_or_wrong_idn_cannot_leave_a_connected_device(self):
        for reply in (TimeoutError("IDN timeout"), "-93,-91,-20,-92", "RIGOL,OTHER,TEST,1.0"):
            with self.subTest(reply=reply):
                visa = FakeVisa()
                if isinstance(reply, Exception):
                    visa.query = lambda command, error=reply: (_ for _ in ()).throw(error)
                else:
                    visa.query = lambda command, value=reply: value
                manager = FakeManager(visa)
                rigol = RigolRSA("USB0::TEST::INSTR")
                with patch("sewer.rigol.pyvisa.ResourceManager", return_value=manager):
                    self.assertFalse(rigol.identity_ok())
                self.assertFalse(rigol.connected)
                self.assertEqual(rigol.idn, "")
                self.assertIn("*IDN?", rigol.last_error)
                self.assertTrue(visa.closed)
                self.assertTrue(manager.closed)

    def test_timeout_clears_old_response_and_reconnects_a_fresh_session(self):
        visa, replacement = FakeVisa(), FakeVisa()
        old_manager, new_manager = FakeManager(visa), FakeManager(replacement)
        rigol = RigolRSA("TCPIP0::192.0.2.1::inst0::INSTR")
        with patch("sewer.rigol.pyvisa.ResourceManager", side_effect=[old_manager, new_manager]):
            self.assertTrue(rigol.identity_ok())
            self.assertEqual(visa.commands, ["*IDN?"])
            visa.bad_reply = pyvisa.errors.VisaIOError(pyvisa.constants.StatusCode.error_timeout)
            with self.assertRaisesRegex(RigolConnectionError, "VI_ERROR_TMO"):
                rigol.spectrum()
            self.assertTrue(visa.cleared)
            self.assertTrue(visa.closed)
            self.assertTrue(old_manager.closed)
            self.assertFalse(rigol.connected)
            before = list(visa.commands)
            self.assertTrue(rigol.identity_ok())
            self.assertIs(rigol.dev, replacement)
            self.assertEqual(rigol.last_error, "")
            self.assertEqual(rigol.spectrum().y.size, 801)
            self.assertEqual(rigol.center_hz(), 433920000)
            self.assertEqual(visa.commands, before)
        rigol.close()


class ConnectionUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.tick_patch = patch.object(SewerController, "tick", lambda self: None)
        self.tick_patch.start()
        root = Path(__file__).resolve().parents[1]
        config = json.loads((root / "config.json").read_text(encoding="utf-8-sig"))
        self.controller = SewerController(root, Path(self.temp.name) / "config.json", config)
        self.visa = FakeVisa()
        self.controller.rigol.dev = self.visa
        self.controller.rigol_connected = True
        self.window = MainWindow(self.controller)
        self.window.show()

    def tearDown(self):
        self.window.close()
        self.app.processEvents()
        self.tick_patch.stop()
        self.temp.cleanup()

    def wait_for(self, predicate):
        deadline = time.monotonic() + 3
        while not predicate() and time.monotonic() < deadline:
            self.app.processEvents()
            time.sleep(.005)
        self.app.processEvents()
        self.assertTrue(predicate())

    def test_connection_error_reaches_journal_once_and_mode_is_not_connection(self):
        manager = FakeManager(error=OSError("ETH instrument not found"))
        self.controller.rigol.close()
        with patch("sewer.rigol.pyvisa.ResourceManager", return_value=manager):
            result = self.controller._probe_rigol()
        for _ in range(3):
            self.controller._rigol_probe_done(result, None)
        self.assertFalse(self.controller.rigol_connected)
        self.assertIn("ETH instrument not found", self.window.card_rig.toolTip())
        self.assertEqual(self.window.log.toPlainText().count("ETH instrument not found"), 1)
        replacement = FakeVisa()
        replacement.mode = "VNA"
        with patch("sewer.rigol.pyvisa.ResourceManager", return_value=FakeManager(replacement)):
            result = self.controller._probe_rigol()
        self.controller._rigol_probe_done(result, None)
        self.assertTrue(self.controller.rigol_connected)
        self.assertIn("VNA", self.controller.rigol_error)
        self.assertFalse(replacement.trace_threads)

    def test_live_timeout_pauses_even_if_monitor_reconnects_before_callback(self):
        self.window.open_rigol()
        dialog = self.window.rigol_dialog
        feed = dialog.live_reader
        self.wait_for(lambda: feed.frame is not None and not feed._pending)
        self.visa.bad_reply = TimeoutError("Trace link timeout")
        feed.refresh(force=True)
        # Leave the Qt callback queued while the monitor establishes a fresh link.
        deadline = time.monotonic() + 3
        while self.controller.rigol.connected and time.monotonic() < deadline:
            time.sleep(.005)
        self.assertFalse(self.controller.rigol.connected)
        replacement = FakeVisa()
        with patch("sewer.rigol.pyvisa.ResourceManager", return_value=FakeManager(replacement)):
            result = self.controller._probe_rigol()
        self.controller._rigol_probe_done(result, None)
        # A control edit can invalidate the pending frame but must not hide its transport failure.
        feed.set_trace(2)
        self.wait_for(lambda: not feed._pending)
        self.assertTrue(self.controller.rigol_connected)
        self.assertFalse(dialog.live.isChecked())
        self.assertFalse(feed.timer.isActive())
        self.assertIn("Trace link timeout", dialog.live_status.text())
        self.assertIn("Trace link timeout", self.window.log.toPlainText())
        QtTest.QTest.qWait(350)
        self.assertEqual(replacement.trace_threads, [])
        dialog.live_refresh.click()
        self.wait_for(lambda: feed.frame is not None and not feed._pending)
        self.assertEqual(feed.frame.trace, 2)
        self.assertEqual(dialog.curve.getData()[1].size, 801)
        self.assertFalse(dialog.live.isChecked())


if __name__ == "__main__":
    unittest.main()
