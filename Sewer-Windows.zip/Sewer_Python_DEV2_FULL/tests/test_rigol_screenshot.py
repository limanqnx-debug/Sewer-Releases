from pathlib import Path
import tempfile
from threading import Event
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock, patch

from PySide6 import QtCore, QtGui

from sewer import rigol_screenshot as shot


class ScreenshotTests(unittest.TestCase):
    def test_retry_captures_png_from_web_screen_without_rmt_click(self):
        image = QtGui.QImage(1240, 480, QtGui.QImage.Format_RGB32)
        image.fill(QtGui.QColor("#17682f"))
        buffer = QtCore.QBuffer()
        buffer.open(QtCore.QIODevice.WriteOnly)
        self.assertTrue(image.save(buffer, "PNG"))
        png = bytes(buffer.data())
        slow_page, working_page = MagicMock(), MagicMock()
        slow_page.frames = []
        frame, screen, tab = MagicMock(), MagicMock(), MagicMock()
        working_page.frames = [frame]
        frame.locator.return_value.count.return_value = 1
        frame.locator.return_value.first = screen
        frame.get_by_text.return_value.count.return_value = 1
        frame.get_by_text.return_value.nth.return_value = tab
        tab.is_visible.return_value = True
        opened = False

        def show_screen(**kwargs):
            nonlocal opened
            opened = True

        tab.click.side_effect = show_screen
        screen.is_visible.side_effect = lambda: opened
        screen.screenshot.return_value = png
        now = 0.0

        def tick(ms):
            nonlocal now
            now += ms / 1000

        slow_page.wait_for_timeout.side_effect = working_page.wait_for_timeout.side_effect = tick
        with tempfile.TemporaryDirectory() as tmp, patch.object(shot, "release_browser") as browser, patch.object(
                shot, "time", SimpleNamespace(monotonic=lambda: now)):
            folder = Path(tmp) / "Снимки"
            browser.return_value.__enter__.return_value.new_page.side_effect = [slow_page, working_page]
            path = shot.capture_rigol_screenshot("TCPIP0::192.0.2.1::INSTR", folder, "Спектр", False, Event())
            browser.assert_called_once_with(viewport_width=1250, timeout_ms=5000)
            tab.click.assert_called_once()
            screen.click.assert_not_called()
            slow_page.close.assert_called_once()
            working_page.close.assert_called_once()
            working_page.goto.assert_called_once_with("http://192.0.2.1/", wait_until="domcontentloaded", timeout=1800)
            self.assertEqual(path.name, "Спектр_001.png")
            self.assertEqual(QtGui.QImage(str(path)).pixelColor(1239, 479).name(), "#17682f")
            (folder / "Спектр_003.png").write_bytes(png)
            self.assertEqual(shot.save_numbered_png(folder, "Спектр", False, png).name, "Спектр_004.png")
            self.assertEqual(shot.save_numbered_png(folder, "Спектр", True, png).name, "Спектр_002.png")
            self.assertEqual(path.read_bytes(), png)
