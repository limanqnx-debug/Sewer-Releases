"""Run with: QT_QPA_PLATFORM=offscreen python -m unittest discover -s tests -v"""
from __future__ import annotations

import json
import os
import re
import tempfile
import threading
import time
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import numpy as np
from PySide6 import QtCore, QtWidgets

from sewer.rigol import RigolRSA, parse_trace_ascii
from sewer.rigol_live import RigolLive
from sewer.controller import SewerController
from sewer.gui import MainWindow
from sewer.themes import THEMES, mapped_color


class FakeVisa:
    def __init__(self):
        self.commands = []
        self.trace_threads = []
        self.points = 801
        self.center = 433920000
        self.span = 20e6
        self.sweep_time = .025
        self.ref = 0.0
        self.offset = 0.0
        self.scale = 10.0
        self.att = 10.0
        self.visible = {1}
        self.updating = {1}
        self.signal_hz = 433920000
        self.rbw_auto = True
        self.vbw_auto = True
        self.sweep_auto = True
        self.mode = "SA"
        self.view = "NORM"
        self.unit = "DBM"
        self.spacing = "LOG"
        self.trace_format = "ASC,8"
        self.bad_reply = None
        self.gate = None
        self.trace_started = threading.Event()

    def write(self, command):
        self.commands.append(command)
        if command.startswith(":INSTrument:SELect "):
            self.mode = command.split()[-1]
        mapping = {
            ":SENSe:FREQuency:CENTer": "center", ":SENSe:FREQuency:SPAN": "span",
            ":SENSe:SWEep:TIME": "sweep_time", ":SENSe:SWEep:POINts": "points",
            ":DISPlay:WINDow:TRACe:Y:SCALe:RLEVel": "ref",
            ":DISPlay:WINDow:TRACe:Y:SCALe:RLEVel:OFFSet": "offset",
            ":DISPlay:WINDow:TRACe:Y:SCALe:PDIVision": "scale",
            ":SENSe:POWer:RF:ATTenuation": "att",
        }
        for prefix, field in mapping.items():
            if command.startswith(prefix + " "):
                value = float(command.split()[-1])
                setattr(self, field, int(value) if field == "points" else value)
        if command.startswith(":SENSe:SWEep:TIME:AUTO "):
            self.sweep_auto = command.split()[-1] == "ON"

    def query(self, command):
        self.commands.append(command)
        trace_state = re.fullmatch(r":TRACe([1-6]):(TYPE|DISPlay:STATe|UPDate:STATe)\?", command)
        if trace_state:
            n, prop = int(trace_state[1]), trace_state[2]
            if prop == "TYPE": return "WRIT"
            return str(int(n in (self.visible if prop == "DISPlay:STATe" else self.updating)))
        if command.startswith(":TRACe:DATA?"):
            self.trace_threads.append(threading.get_ident())
            self.trace_started.set()
            if self.gate:
                if not self.gate.wait(3):
                    raise TimeoutError("Таймаут тестового прибора")
            if self.bad_reply is not None:
                if isinstance(self.bad_reply, Exception):
                    raise self.bad_reply
                return self.bad_reply
            x = np.linspace(self.center - self.span / 2, self.center + self.span / 2, self.points)
            y = -95 + 70 * np.exp(-((x - self.signal_hz) / max(self.span / 45, 1)) ** 2) + 1.7 * np.sin(np.linspace(-260,260,self.points))
            return ", ".join(f"{value:.8e}" for value in y) + "\n"
        return {
            "*IDN?": "RIGOL,RSA5065N,TEST,1.0",
            ":INSTrument:SELect?": self.mode,
            ":CONFigure?": self.view,
            ":SENSe:FREQuency:CENTer?": str(self.center),
            ":SENSe:FREQuency:SPAN?": str(self.span),
            ":UNIT:POWer?": self.unit,
            ":FORMat:TRACe:DATA?": self.trace_format,
            ":DISPlay:WINDow:TRACe:Y:SCALe:SPACing?": self.spacing,
            ":SENSe:SWEep:TIME?": str(self.sweep_time),
            ":SENSe:SWEep:POINts?": str(self.points),
            ":DISPlay:WINDow:TRACe:Y:SCALe:RLEVel?": str(self.ref),
            ":DISPlay:WINDow:TRACe:Y:SCALe:RLEVel:OFFSet?": str(self.offset),
            ":DISPlay:WINDow:TRACe:Y:SCALe:PDIVision?": str(self.scale),
            ":SENSe:POWer:RF:ATTenuation?": str(self.att),
            ":SENSe:BANDwidth:RESolution?": "10000",
            ":SENSe:BANDwidth:VIDeo?": "10000",
            ":SENSe:BANDwidth:RESolution:AUTO?": str(int(self.rbw_auto)),
            ":SENSe:BANDwidth:VIDeo:AUTO?": str(int(self.vbw_auto)),
            ":SENSe:SWEep:TIME:AUTO?": str(int(self.sweep_auto)),
        }[command]

    def close(self):
        pass


class LiveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

    def setUp(self):
        self.rigol = RigolRSA("TEST")
        self.visa = FakeVisa()
        self.rigol.dev = self.visa
        self.feed = RigolLive(self.rigol, 100)

    def tearDown(self):
        if self.visa.gate:
            self.visa.gate.set()
        self.feed.close()
        self.rigol.close()
        self.app.processEvents()

    def wait_for(self, predicate, timeout=2):
        deadline = time.monotonic() + timeout
        while not predicate() and time.monotonic() < deadline:
            self.app.processEvents()
            time.sleep(.005)
        self.app.processEvents()
        self.assertTrue(predicate(), self.feed.status)

    def test_parser_rejects_missing_truncated_and_invalid_samples(self):
        for bad in ("", "-99", "-90,broken,-91", "-90,,1", "nan,1", "inf,-20", "9.9e37,-20", "#2121,2", "#x1,2", "#131,2extra"):
            with self.subTest(reply=bad), self.assertRaises(ValueError):
                parse_trace_ascii(bad)
        for good in ("-90, -2e1, -91\r\n", "-90, -20, -91,", "#212-90,-20,-91 "):
            np.testing.assert_allclose(parse_trace_ascii(good), [-90, -20, -91])

    def test_automatic_read_large_trace_and_zero_span(self):
        self.feed.set_active(True)
        self.wait_for(lambda: self.feed.frame is not None)
        frame = self.feed.frame
        self.assertEqual(frame.y.size, 801)
        np.testing.assert_allclose(frame.x[[0, -1]], [423.92, 443.92])
        self.assertEqual(frame.y_unit, "dBm")
        self.assertNotIn(threading.get_ident(), self.visa.trace_threads)
        self.visa.points = 10001
        self.wait_for(lambda: self.feed.frame.y.size == 10001)
        self.visa.span = 0
        self.wait_for(lambda: self.feed.frame.x_unit == "ms")
        np.testing.assert_allclose(self.feed.frame.x[[0, -1]], [0, 25])
        writes = [cmd for cmd in self.visa.commands if not "?" in cmd]
        self.assertTrue(all(cmd == ":FORMat:TRACe:DATA ASCii" for cmd in writes))

    def test_empty_reply_and_timeout_are_visible_and_recoverable(self):
        self.visa.bad_reply = ""
        self.feed.set_active(True)
        self.wait_for(lambda: self.feed.error)
        self.assertIsNone(self.feed.frame)
        self.assertIn("не вернул точки", self.feed.status)
        reads = len(self.visa.trace_threads)
        for _ in range(20):
            self.feed.refresh()
        self.assertEqual(len(self.visa.trace_threads), reads)
        self.visa.bad_reply = TimeoutError("VISA timeout")
        self.feed.refresh(force=True)
        self.wait_for(lambda: "VISA timeout" in self.feed.status)
        self.visa.bad_reply = None
        self.feed.refresh(force=True)
        self.wait_for(lambda: self.feed.frame is not None)
        self.assertFalse(self.feed.error)
        self.rigol.close()
        self.feed.refresh()
        self.assertIsNone(self.feed.frame)
        self.assertIn("Нет связи", self.feed.status)
        self.rigol.dev = self.visa
        self.wait_for(lambda: self.feed.frame is not None)

    def test_single_inflight_query_keeps_qt_responsive_and_discards_old_selection(self):
        self.visa.gate = threading.Event()
        self.feed.set_active(True)
        self.wait_for(self.visa.trace_started.is_set)
        ticks = []
        timer = QtCore.QTimer()
        timer.timeout.connect(lambda: ticks.append(1))
        timer.start(10)
        for _ in range(20):
            self.feed.refresh(force=True)
        self.wait_for(lambda: len(ticks) >= 8)
        timer.stop()
        self.assertEqual(len(self.visa.trace_threads), 1)
        self.feed.set_trace(2)
        self.feed.set_enabled(False)
        self.visa.gate.set()
        self.wait_for(lambda: not self.feed._pending)
        self.assertIsNone(self.feed.frame)
        self.feed.refresh(force=True)
        self.wait_for(lambda: self.feed.frame is not None)
        self.assertEqual(self.feed.frame.trace, 2)
        self.assertFalse(self.feed.enabled)

    def test_rt_modes_and_units(self):
        self.feed.timer.stop()
        self.visa.mode = "RTSA"
        self.visa.unit = "DBMV"
        self.feed.set_active(True)
        self.wait_for(lambda: self.feed.frame is not None)
        self.assertEqual(self.feed.frame.mode, "RTSA")
        self.assertEqual(self.feed.frame.y_unit, "dBmV")
        self.visa.view = "PVT"
        self.feed.refresh(force=True)
        self.wait_for(lambda: self.feed.error)
        self.assertIn("Normal", self.feed.status)

    def test_live_is_confined_to_control_dialog_and_stops_on_close(self):
        self.feed.close()
        root = Path(__file__).resolve().parents[1]
        config = json.loads((root / "config.json").read_text(encoding="utf-8-sig"))
        original_tick = SewerController.tick
        SewerController.tick = lambda controller: None
        try:
            with tempfile.TemporaryDirectory() as tmp:
                controller = SewerController(root, Path(tmp) / "config.json", config)
                controller.rigol.dev = self.visa
                controller.rigol_connected = True
                window = MainWindow(controller)
                try:
                    window.show()
                    self.app.processEvents()
                    self.assertFalse(hasattr(controller, "rigol_live"))
                    self.assertFalse(hasattr(window, "main_spectrum"))
                    self.assertFalse(window.findChildren(QtWidgets.QTabWidget))
                    self.assertTrue(window.log.isVisible())
                    self.assertEqual(self.visa.trace_threads, [])
                    window.append_log("Test journal entry")
                    self.assertIn("Test journal entry", window.log.toPlainText())
                    window.open_rigol()
                    dialog = window.rigol_dialog
                    self.feed = dialog.live_reader
                    self.wait_for(lambda: self.feed.frame is not None)
                    self.assertTrue(dialog.live.isChecked())
                    self.assertEqual(dialog.curve.getData()[1].size, 801)
                    dialog.tr.setCurrentIndex(2)
                    self.wait_for(lambda: self.feed.frame is not None and self.feed.frame.trace == 3)
                    for key in THEMES:
                        window.apply_theme(key)
                        self.app.processEvents()
                        self.assertEqual(dialog.plot.backgroundBrush().color().name(), mapped_color("#171d23"))
                        self.assertEqual(window.size().toTuple(), (1040, 640))
                    window.apply_theme("graphite")
                    if os.environ.get("SEWER_QA_DIR"):
                        dest = Path(os.environ["SEWER_QA_DIR"])
                        dest.mkdir(exist_ok=True, parents=True)
                        window.grab().save(str(dest / "main-v14-restored.png"))
                        dialog.grab().save(str(dest / "controls-spectrum-simulated.png"))
                    dialog.live.setChecked(False)
                    self.wait_for(lambda: not self.feed._pending)
                    self.assertFalse(dialog.live_timer.isActive())
                    self.assertEqual(dialog.live_status.text(), "Пауза Live")
                    before = len(self.visa.trace_threads)
                    dialog.live_refresh.click()
                    self.wait_for(lambda: len(self.visa.trace_threads) == before + 1 and not self.feed._pending)
                    self.assertEqual(dialog.curve.getData()[1].size, 801)
                    dialog.live.setChecked(True)
                    self.wait_for(lambda: not self.feed._pending)
                    # Real Esc follows QDialog.reject/done, bypassing closeEvent.
                    from PySide6 import QtTest
                    QtTest.QTest.keyClick(dialog, QtCore.Qt.Key_Escape)
                    self.app.processEvents()
                    self.assertIsNone(window.rigol_dialog)
                    self.assertTrue(self.feed._closed)
                    before = len(self.visa.trace_threads)
                    for _ in range(75):
                        self.app.processEvents()
                        time.sleep(.005)
                    self.assertEqual(len(self.visa.trace_threads), before)
                    window.open_rigol()
                    self.feed = window.rigol_dialog.live_reader
                    self.wait_for(lambda: self.feed.frame is not None)
                    self.assertEqual(window.rigol_dialog.curve.getData()[1].size, 801)
                    self.assertTrue(window.log.isVisible())
                    # Closing Sewer also shuts down an open Rigol reader.
                    window.close()
                    self.app.processEvents()
                    self.assertTrue(self.feed._closed)
                    self.assertIsNone(window.rigol_dialog)
                finally:
                    if window.rigol_dialog:
                        window.rigol_dialog.close()
                    if window.isVisible():
                        window.close()
                    self.app.processEvents()
        finally:
            SewerController.tick = original_tick


if __name__ == "__main__":
    unittest.main()
