from __future__ import annotations

import json
import os
import unittest
import zipfile

import numpy as np

from test_rigol_live import FakeVisa
from sewer.rigol import RigolRSA, RigolConnectionError, parse_trace_ascii


class FragmentTests(unittest.TestCase):
    def setUp(self):
        self.visa = FakeVisa()
        self.visa.fragment_size = 4096
        # Model the observed short read as conservatively as possible: even an
        # early EOM must not accept fewer points than GPSA says are in the trace.
        self.visa.early_eom = True
        self.rigol = RigolRSA("TCPIP0::192.0.2.1::inst0::INSTR")
        self.rigol.dev = self.visa

    def tearDown(self):
        self.rigol.close()

    def set_samples(self, values, terminator="\n"):
        self.visa.points = len(values)
        self.visa.bad_reply = ",".join(f"{value:.9E}" for value in values) + terminator

    def test_4096_byte_fragments_return_all_801_points_including_late_peak(self):
        values = np.full(801, -55.0)
        values[650] = -5.0
        self.set_samples(values)
        self.assertEqual(len(parse_trace_ascii(self.visa.bad_reply[:4096])), 241)
        frame = self.rigol.spectrum()
        np.testing.assert_array_equal(frame.y, values)
        self.assertEqual(int(np.argmax(frame.y)), 650)
        self.assertEqual(frame.x_unit, "MHz")
        self.assertEqual(self.visa.buffer, b"")
        self.assertEqual(self.visa.commands.count(":TRACe:DATA? TRACE1"), 1)
        trace_pos = self.visa.commands.index(":TRACe:DATA? TRACE1")
        self.assertLess(self.visa.commands.index(":SENSe:SWEep:POINts?"), trace_pos)
        self.assertEqual(self.visa.commands[trace_pos + 1:], [])
        entry = frame.diagnostic["commands"][-1]
        self.assertEqual([r["bytes"] for r in entry["read_chunks"]], [4096, 4096, 4096, 1329])
        self.assertEqual(entry["received_bytes"], 13617)
        self.assertEqual(self.visa.read_termination, "\n")
        self.assertEqual(self.visa.timeout, 2500)
        self.assertTrue(self.rigol.identity_ok())

    def test_full_10001_points_without_lf_and_wrapped_lists(self):
        for count, suffix, wrap in ((10001, "", False), (801, "\n", True)):
            with self.subTest(count=count, wrap=wrap):
                self.visa.points = count
                values = np.full(count, -95.0)
                values[-2] = -13.125
                self.set_samples(values, suffix)
                if wrap:
                    self.visa.bad_reply = self.visa.bad_reply.replace(",", ",\n")
                frame = self.rigol.spectrum()
                np.testing.assert_array_equal(frame.y, values)
                self.assertEqual(self.visa.buffer, b"")
                self.assertTrue(self.rigol.identity_ok())

    def test_partial_final_number_is_not_accepted_at_a_count_boundary(self):
        self.visa.early_eom = False
        values = np.full(801, -55.0)
        values[-1] = -12.345
        self.set_samples(values)
        self.visa.fragment_size = len(self.visa.bad_reply) - 5
        frame = self.rigol.spectrum()
        np.testing.assert_array_equal(frame.y, values)
        self.assertEqual(self.visa.buffer, b"")

    def test_missing_remainder_closes_session_instead_of_plotting_241_points(self):
        self.set_samples(np.full(801, -55.0), "")
        self.visa.bad_reply = self.visa.bad_reply[:4096]
        with self.assertRaisesRegex(RigolConnectionError, "241 из 801 точек; 4096 байт"):
            self.rigol.spectrum()
        self.assertFalse(self.rigol.connected)
        capture = self.rigol.last_capture
        self.assertNotIn("frame", capture)
        self.assertNotIn("samples", capture)
        self.assertEqual(capture["expected_points"], 801)
        self.assertEqual(capture["commands"][-1]["response"], self.visa.bad_reply)

    def test_size_header_can_be_split_and_line_ending_is_consumed(self):
        values = np.full(801, -90.0)
        payload = ",".join(str(v) for v in values)
        self.visa.bad_reply = f"#{len(str(len(payload)))}{len(payload)}{payload}\n"
        self.visa.fragment_size = 1
        self.visa.early_eom = False
        frame = self.rigol.spectrum()
        np.testing.assert_array_equal(frame.y, values)
        self.assertEqual(self.visa.buffer, b"")
        self.assertTrue(self.rigol.identity_ok())

    def test_front_panel_change_after_count_query_is_rechecked_after_complete_reply(self):
        base_reply = self.visa._reply
        values = np.full(1001, -80.0)
        self.visa.bad_reply = ",".join(f"{v:.9E}" for v in values) + "\n"
        def reply(command):
            if command.startswith(":TRACe:DATA?"):
                self.visa.points = 1001
            return base_reply(command)
        self.visa._reply = reply
        frame = self.rigol.spectrum()
        np.testing.assert_array_equal(frame.y, values)
        self.assertEqual(frame.diagnostic["expected_points"], 1001)
        self.assertEqual(frame.x_unit, "MHz")

    @unittest.skipUnless(os.environ.get("SEWER_DIAGNOSTIC_ZIP"), "optional user capture")
    def test_user_capture_prefix_with_explicitly_simulated_remainder(self):
        # Only the first 241 points are measured. The added tail is a test fixture,
        # not a reconstruction of the user's missing measurement.
        with zipfile.ZipFile(os.environ["SEWER_DIAGNOSTIC_ZIP"]) as z:
            raw = z.read("trace-response.txt").decode("ascii")
            report = json.loads(z.read("report.json"))
        self.assertEqual(len(raw), 4096)
        prefix = parse_trace_ascii(raw)
        self.assertEqual(prefix.size, 241)
        self.assertEqual(report["expected_points"], 801)
        tail = np.full(801 - prefix.size, -70.0)
        tail[-1] = -1.0
        self.visa.center = report["frame"]["center_hz"]
        self.visa.span = report["frame"]["span_hz"]
        self.visa.bad_reply = raw + "," + ",".join(f"{v:.9E}" for v in tail) + "\n"
        frame = self.rigol.spectrum()
        np.testing.assert_array_equal(frame.y, np.concatenate([prefix, tail]))
        np.testing.assert_array_equal(frame.x[[0, -1]], [350, 850])
        self.assertEqual(frame.diagnostic["commands"][-1]["read_chunks"][0]["bytes"], 4096)
