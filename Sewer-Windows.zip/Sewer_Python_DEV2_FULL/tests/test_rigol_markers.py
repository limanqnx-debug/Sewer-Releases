from __future__ import annotations

from dataclasses import replace
import json
import os
from pathlib import Path
import re
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

from PySide6 import QtCore, QtTest, QtWidgets
import numpy as np

from sewer.controller import SewerController
from sewer.gui import MainWindow
from sewer.rigol import RigolRSA
from sewer.rigol_markers import RigolMarkerControl
from sewer.rigol_marker_panel import MarkerReader
from test_rigol_live import FakeVisa


class MarkerVisa(FakeVisa):
    def __init__(self):
        super().__init__()
        self.markers = {n: {"MODE": "OFF", "TRACe": 1, "X:READout": "FREQ", "X": self.center,
                           "Y": -25.0, "REFerence": n % 8 + 1, "CPSearch:STATe": 0, "FUNCtion": "OFF"}
                        for n in range(1, 9)}
        self.marker_gate = None
        self.marker_started = threading.Event()
        self.marker_threads = []
        self.invalid_marker = False

    def write(self, command):
        super().write(command)
        if command == ":CALCulate:MARKer:AOFF":
            for marker in self.markers.values():
                marker["MODE"] = "OFF"
        match = re.fullmatch(r":CALCulate:MARKer([1-8]):(.+)", command)
        if match:
            marker, rest = self.markers[int(match[1])], match[2]
            if " " in rest:
                key, value = rest.split(" ", 1)
                if key == "X":
                    # Simulate the instrument's quantization to 1 kHz.
                    marker[key] = round(float(value[:-2]) / 1000) * 1000 if value.endswith("HZ") else float(value[:-1])
                elif key in ("TRACe", "REFerence"):
                    marker[key] = int(value)
                elif key == "CPSearch:STATe":
                    marker[key] = int(value == "ON")
                elif key != "TRACe:AUTO":
                    marker[key] = value
            elif rest.startswith("MAXimum:"):
                marker["X"] = self.signal_hz
                marker["Y"] = -25.0
            elif rest == "MINimum":
                marker["Y"] = -95.0
            elif rest == "SET:CENTer":
                ref = self.markers[marker["REFerence"]]
                self.center = marker["X"] + (ref["X"] if marker["MODE"] == "DELT" else 0)
            elif rest == "SET:DELTa:SPAN":
                self.span = abs(marker["X"])
            elif rest == "SET:RLEVel":
                self.ref = marker["Y"]

    def _reply(self, command):
        match = re.fullmatch(r":CALCulate:MARKer([1-8]):(.+)\?", command)
        if match:
            self.marker_started.set()
            self.marker_threads.append(threading.get_ident())
            if self.marker_gate and not self.marker_gate.wait(3):
                raise TimeoutError("Marker timeout")
            if self.invalid_marker and int(match[1]) == 1 and match[2] == "Y":
                return "9.9e37"
            return str(self.markers[int(match[1])][match[2]])
        return super()._reply(command)


class MarkerTests(unittest.TestCase):
    def setUp(self):
        self.r = RigolRSA("TEST")
        self.v = MarkerVisa()
        self.r.dev = self.v
        self.api = RigolMarkerControl(self.r)

    def tearDown(self):
        self.r.close()

    def test_read_all_eight_is_read_only_and_delta_is_absolute_on_plot(self):
        self.v.markers[8].update(MODE="POS", X=432e6, Y=-40)
        self.v.markers[1].update(MODE="DELT", X=1e6, Y=15, REFerence=8)
        self.v.markers[2].update(MODE="POS", TRACe=3)
        frame = self.r.spectrum()
        self.v.commands.clear()
        data = self.api.read()
        self.assertEqual(len(data.markers), 8)
        np.testing.assert_allclose(data.position(1, frame), (433, -25))
        np.testing.assert_allclose(data.position(8, frame), (432, -40))
        self.assertIsNone(data.position(2, frame))
        self.assertTrue(all("?" in cmd for cmd in self.v.commands))
        for other in (replace(frame, center_hz=500e6), replace(frame, trace=6), replace(frame, y_unit="V")):
            self.assertIsNone(data.position(1, other))
        self.v.markers[8]["MODE"] = "DELT"
        self.assertIsNone(self.api.read().position(1, frame))

    def test_zero_span_time_and_special_readout_are_not_frequency_markers(self):
        self.v.span = 0
        self.v.markers[1].update(MODE="POS", X=.010, Y=-30, **{"X:READout": "TIME"})
        frame = self.r.spectrum()
        self.assertEqual(self.api.read().position(1, frame), (10, -30))
        self.api.set_x(1, .0125, "TIME")
        self.assertEqual(self.v.markers[1]["X"], .0125)
        with self.assertRaisesRegex(ValueError, "Span = 0"):
            self.api.action(1, "center")
        self.v.markers[1]["X:READout"] = "ITIM"
        self.assertIsNone(self.api.read().position(1, frame))
        with self.assertRaisesRegex(ValueError, "изменился"):
            self.api.set_x(1, 10, "TIME")

    def test_guard_invalid_references_hidden_trace_and_all_off(self):
        before = list(self.v.commands)
        with self.assertRaises(ValueError):
            self.api.configure(1, "DELT", 1, 1)
        with self.assertRaises(ValueError):
            self.api.configure(1, "DELT", 1, 2)
        with self.assertRaisesRegex(ValueError, "Display"):
            self.api.configure(1, "POS", 2, 2)
        self.assertTrue(all("?" in cmd for cmd in self.v.commands[len(before):]))
        self.api.configure(8, "POS", 1, 1)
        self.api.configure(1, "DELT", 1, 8)
        self.api.set_continuous(8, True)
        self.assertEqual(self.api.read().markers[0].reference, 8)
        self.assertTrue(self.api.read().markers[7].continuous)
        self.api.all_off()
        self.assertTrue(all(m.mode == "OFF" for m in self.api.read().markers))

    def test_invalid_marker_does_not_replace_or_block_valid_full_spectrum(self):
        self.v.markers[1]["MODE"] = "POS"
        self.v.invalid_marker = True
        self.v.points = 10001
        self.v.fragment_size = 4096
        self.v.early_eom = True
        frame = self.r.spectrum()
        data = self.api.read()
        self.assertTrue(data.markers[0].error)
        self.assertIsNone(data.position(1, frame))
        self.assertEqual(frame.y.size, 10001)
        self.assertEqual(self.r.spectrum().y.size, 10001)
        self.assertFalse(self.v.buffer)


class MarkerUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

    def wait_for(self, predicate, timeout=3):
        deadline = time.monotonic() + timeout
        while not predicate() and time.monotonic() < deadline:
            self.app.processEvents()
            time.sleep(.005)
        self.app.processEvents()
        self.assertTrue(predicate())

    def test_background_read_discards_stale_frame_and_stops_after_close(self):
        r = RigolRSA("TEST")
        v = MarkerVisa(); r.dev = v
        v.markers[1]["MODE"] = "POS"
        reader = MarkerReader(r)
        try:
            frame = r.spectrum()
            reader.set_frame(frame); reader.set_active(True)
            reader.timer.stop()
            v.marker_gate = threading.Event()
            reader.refresh(force=True)
            self.wait_for(v.marker_started.is_set)
            pulses = []
            QtCore.QTimer.singleShot(0, lambda: pulses.append(True))
            self.wait_for(lambda: bool(pulses))
            reader.set_frame(replace(frame, center_hz=500e6))
            v.marker_gate.set()
            self.wait_for(lambda: not reader._poll_pending)
            self.assertIsNone(reader.snapshot)
            self.assertNotIn(threading.get_ident(), v.marker_threads)
            reader.close()
            count = len(v.commands)
            reader.refresh(force=True)
            self.assertEqual(len(v.commands), count)
        finally:
            if v.marker_gate: v.marker_gate.set()
            reader.close(); r.close()

    def test_real_controls_readback_delta_peak_table_and_full_plot(self):
        root = Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as temp, patch.object(SewerController, "tick", lambda self: None):
            config = json.loads((root / "config.json").read_text(encoding="utf-8-sig"))
            c = SewerController(root, Path(temp) / "config.json", config)
            v = MarkerVisa(); c.rigol.dev = v; c.rigol_connected = True
            v.markers[1].update(MODE="POS", X=433920000, Y=-25)
            v.markers[2].update(MODE="DELT", X=1e6, Y=-20, REFerence=1)
            w = MainWindow(c)
            try:
                w.show(); w.open_rigol(); d = w.rigol_dialog; p = d.markers
                self.wait_for(lambda: d.live_reader.frame is not None)
                d.live.setChecked(False)
                self.wait_for(lambda: not d.live_reader._pending)
                p.reader.refresh(force=True)
                self.wait_for(lambda: p.reader.snapshot is not None)
                self.assertEqual(p.table.rowCount(), 2)
                self.assertEqual(len(p.overlay.points()), 2)
                np.testing.assert_allclose(p.overlay.getData()[0], [433.92, 434.92])
                self.assertIn("Δ", p.table.item(1, 0).text())
                self.assertTrue(w.log.isVisible())
                self.assertEqual(len(d.curve.getData()[1]), 801)
                d.control_tabs.setCurrentIndex(1)
                p.x.setFocus()
                p.x.selectAll()
                QtTest.QTest.keyClicks(p.x, "433,921234")
                QtTest.QTest.keyClick(p.x, QtCore.Qt.Key_Return)
                self.wait_for(lambda: not p.reader._action_pending)
                self.assertEqual(p.x.text(), "433.921")
                self.assertEqual(p.x.suffix(), "")
                self.assertEqual(p.x.unit_label.text(), "MHz")
                p.action_buttons["peak"].click()
                self.wait_for(lambda: not p.reader._action_pending)
                self.assertEqual(v.markers[1]["X"], v.signal_hz)
                self.assertNotIn(threading.get_ident(), v.marker_threads)
                # Moving an axis must refresh even while Live is paused.
                self.wait_for(lambda: not p._refresh_timer.isActive() and not d.live_reader._pending)
                v.markers[1]["X"] = 435e6
                p.action_buttons["center"].click()
                self.wait_for(lambda: not p.reader._action_pending)
                self.wait_for(lambda: d.live_reader.frame is not None and d.live_reader.frame.center_hz == 435e6)
                self.assertEqual(d.center.text(), "435")
                self.assertFalse(d.live.isChecked())
                self.assertEqual(d.curve.getData()[1].size, 801)
                d.trace_display.click()
                self.assertNotIn(1, v.visible)
                d.trace_update.click()
                self.assertNotIn(1, v.updating)
                if os.environ.get("SEWER_QA_DIR"):
                    dest = Path(os.environ["SEWER_QA_DIR"]); dest.mkdir(parents=True, exist_ok=True)
                    d.refresh_live()
                    self.wait_for(lambda: d.live_reader.frame is not None)
                    p.reader.refresh(force=True)
                    self.wait_for(lambda: p.reader.snapshot is not None)
                    d.grab().save(str(dest / "rigol-markers-simulated.png"))
                    d.control_tabs.setCurrentIndex(0)
                    d.grab().save(str(dest / "rigol-controls-simulated.png"))
                QtTest.QTest.keyClick(d, QtCore.Qt.Key_Escape)
                self.app.processEvents()
                self.assertTrue(p.reader.closed)
            finally:
                w.close(); self.app.processEvents()


if __name__ == "__main__":
    unittest.main()
