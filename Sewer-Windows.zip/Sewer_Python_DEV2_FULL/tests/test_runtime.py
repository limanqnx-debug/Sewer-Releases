from pathlib import Path
import os
import tempfile
import unittest
from unittest.mock import patch

from sewer.runtime import prepare_user_files
from sewer.process_launch import external_environment


class RuntimeTests(unittest.TestCase):
    def test_frozen_config_is_next_to_exe_and_preserved_after_restart(self):
        with tempfile.TemporaryDirectory() as temp:
            bundle = Path(temp) / "bundle"
            install = Path(temp) / "Sewer Portable"
            bundle.mkdir(); install.mkdir()
            original = b'{"Application":{"Theme":"hellokitty"}}\r\n'
            (bundle / "config.json").write_bytes(original)
            with patch("sewer.runtime.sys.frozen", True, create=True), patch("sewer.runtime.sys.executable", str(install / "Sewer.exe")), patch("sewer.runtime.asset_path", lambda *parts: bundle.joinpath(*parts)):
                root, config = prepare_user_files()
                self.assertEqual(root, install)
                self.assertEqual(config.read_bytes(), original)
                changed = b'{"existing":"keep"}'
                config.write_bytes(changed)
                self.assertEqual(prepare_user_files()[1].read_bytes(), changed)
                self.assertEqual((bundle / "config.json").read_bytes(), original)

    def test_readonly_install_imports_adjacent_config_into_appdata_once(self):
        with tempfile.TemporaryDirectory() as temp:
            install = Path(temp) / "protected"
            install.mkdir()
            (install / "config.json").write_bytes(b'{"custom":123}')
            local = Path(temp) / "local"
            def writable(path):
                if path == install:
                    return False
                path.mkdir(parents=True, exist_ok=True)
                return True
            with patch("sewer.runtime.application_dir", return_value=install), patch("sewer.runtime._writable", side_effect=writable), patch.dict(os.environ, {"LOCALAPPDATA": str(local)}):
                root, config = prepare_user_files()
                self.assertEqual(root, local / "Sewer-P")
                self.assertEqual(config.read_bytes(), b'{"custom":123}')
                config.write_bytes(b'{"custom":456}')
                self.assertEqual(prepare_user_files()[1].read_bytes(), b'{"custom":456}')

    def test_external_tools_do_not_inherit_bundled_qt_search_path(self):
        with tempfile.TemporaryDirectory() as temp:
            bundle = Path(temp) / "bundle"
            external = Path(temp) / "tools"
            inherited = os.pathsep.join([str(bundle), str(bundle / "PySide6"), str(external)])
            with patch("sewer.process_launch.sys.frozen", True, create=True), patch("sewer.process_launch.sys._MEIPASS", str(bundle), create=True), patch.dict(os.environ, {"PATH": inherited, "QT_PLUGIN_PATH": str(bundle / "plugins")}):
                cleaned = external_environment()
                self.assertEqual(cleaned["PATH"], str(external))
                self.assertNotIn("QT_PLUGIN_PATH", cleaned)
                self.assertEqual(os.environ["PATH"], inherited)


if __name__ == "__main__":
    unittest.main()
