from __future__ import annotations

import json
import os
import tempfile
import time
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6 import QtCore, QtTest, QtWidgets
from test_rigol_live import FakeVisa
from sewer.controller import SewerController
from sewer.gui import MainWindow
from sewer.themes import THEMES


class InputTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

    def setUp(self):
        self.root = Path(__file__).resolve().parents[1]
        self.tmp = tempfile.TemporaryDirectory()
        self.original_tick = SewerController.tick
        SewerController.tick = lambda self: None
        config = json.loads((self.root / "config.json").read_text(encoding="utf-8-sig"))
        self.c = SewerController(self.root, Path(self.tmp.name) / "config.json", config)
        self.visa = FakeVisa()
        self.visa.span = 100000
        self.c.rigol.dev = self.visa
        self.c.rigol_connected = True
        self.window = MainWindow(self.c)
        self.window.show()
        self.window.open_rigol()
        self.d = self.window.rigol_dialog
        self.d.live.setChecked(False)
        self.wait_for(lambda: not self.d.live_reader._pending)
        self.visa.commands.clear()

    def tearDown(self):
        self.window.close()
        self.app.processEvents()
        SewerController.tick = self.original_tick
        self.tmp.cleanup()

    def wait_for(self, predicate):
        deadline = time.monotonic() + 2
        while not predicate() and time.monotonic() < deadline:
            self.app.processEvents()
            time.sleep(.005)
        self.app.processEvents()
        self.assertTrue(predicate())

    def type_value(self, editor, text):
        QtTest.QTest.mouseClick(editor.lineEdit(), QtCore.Qt.LeftButton)
        QtTest.QTest.keyClick(editor, QtCore.Qt.Key_A, QtCore.Qt.ControlModifier)
        QtTest.QTest.keyClicks(editor, text)

    def test_focus_changes_preserve_narrow_signal_and_send_no_settings(self):
        self.assertEqual(self.d.center.text(), "433.92")
        self.assertEqual(self.d.span.text(), "0.1")
        for editor in (self.d.center, self.d.span, self.d.ref, self.d.off, self.d.scale, self.d.att, self.d.sweept, self.d.points):
            self.assertEqual(editor.suffix(), "")
            QtTest.QTest.mouseClick(editor.lineEdit(), QtCore.Qt.LeftButton)
            self.app.processEvents()
        QtTest.QTest.mouseClick(self.d.status, QtCore.Qt.LeftButton)
        self.app.processEvents()
        self.assertEqual(self.visa.commands, [])
        self.assertEqual(self.visa.center, 433920000)
        self.assertEqual(self.visa.span, 100000)
        self.d.refresh_live()
        self.wait_for(lambda: self.d.live_reader.frame is not None)
        self.assertGreater(self.d.curve.getData()[1].max(), -30)
        self.assertIn("Span 0.1 MHz", self.d.live_status.text())

    def test_enter_supports_dot_comma_and_does_not_reconnect(self):
        self.type_value(self.d.center, "433,920123")
        self.assertEqual(self.visa.commands, [])
        QtTest.QTest.keyClick(self.d.center, QtCore.Qt.Key_Return)
        self.app.processEvents()
        writes = [cmd for cmd in self.visa.commands if "?" not in cmd]
        self.assertEqual(writes, [":SENSe:FREQuency:CENTer 433920123.0"])
        self.assertEqual(self.visa.center, 433920123)
        self.assertEqual(self.d.center.text(), "433.920123")
        self.assertIs(self.c.rigol.dev, self.visa)
        self.type_value(self.d.span, "0.25")
        QtTest.QTest.keyClick(self.d.span, QtCore.Qt.Key_Return)
        self.app.processEvents()
        self.assertEqual(self.visa.span, 250000)
        self.type_value(self.d.off, "-12,5")
        QtTest.QTest.keyClick(self.d.off, QtCore.Qt.Key_Return)
        self.app.processEvents()
        self.assertEqual(self.visa.offset, -12.5)
        self.assertEqual(self.d.off.text(), "-12.5")

    def test_sweep_ms_is_converted_and_auto_state_is_read(self):
        self.assertTrue(self.d.rbwa.isChecked())
        self.assertTrue(self.d.vbwa.isChecked())
        self.assertTrue(self.d.sweepa.isChecked())
        self.d.sweepa.setChecked(False)
        self.type_value(self.d.sweept, "250")
        QtTest.QTest.keyClick(self.d.sweept, QtCore.Qt.Key_Return)
        self.app.processEvents()
        self.assertEqual(self.visa.sweep_time, .25)
        self.assertEqual(self.d.sweept.text(), "250")
        self.assertEqual(self.d.sweept.unit_label.text(), "ms")
        self.assertFalse(self.visa.sweep_auto)

    def test_readback_replaces_requested_value_with_actual_value(self):
        original_write = self.visa.write
        def quantized(cmd):
            original_write(cmd)
            if cmd.startswith(":SENSe:FREQuency:CENTer "):
                self.visa.center = round(self.visa.center / 1000) * 1000
        self.visa.write = quantized
        self.type_value(self.d.center, "433.920123")
        QtTest.QTest.keyClick(self.d.center, QtCore.Qt.Key_Return)
        self.app.processEvents()
        self.assertEqual(self.d.center.text(), "433.92")
        self.assertFalse(self.d.center._user_edited)

    def test_visible_trace_is_selected_without_changing_instrument(self):
        self.visa.visible = {4}
        self.visa.updating = {4}
        self.d._choose_visible_trace = True
        self.d.refresh_all()
        self.assertEqual(self.d.tr.currentText(), "4")
        self.d.refresh_live()
        self.wait_for(lambda: self.d.live_reader.frame is not None)
        self.assertEqual(self.d.live_reader.frame.trace, 4)
        self.assertTrue(self.d.live_reader.frame.display_on)
        self.assertIn("видна на приборе", self.d.live_status.text())
        self.assertTrue(all("?" in cmd or cmd == ":FORMat:TRACe:DATA ASCii" for cmd in self.visa.commands))

    def test_units_render_outside_fields_in_all_themes(self):
        for theme in THEMES:
            self.window.apply_theme(theme)
            self.app.processEvents()
            for editor in (self.d.center,self.d.span,self.d.ref,self.d.off,self.d.scale,self.d.att,self.d.sweept):
                self.assertEqual(editor.suffix(), "")
                self.assertTrue(editor.unit_label.isVisible())
                self.assertGreaterEqual(editor.unit_label.x(), editor.geometry().right())
                self.assertEqual(editor.unit_label.text(), editor.unit)
        if os.environ.get("SEWER_QA_DIR"):
            dest = Path(os.environ["SEWER_QA_DIR"])
            dest.mkdir(exist_ok=True, parents=True)
            self.window.apply_theme("graphite")
            self.d.refresh_live()
            self.wait_for(lambda: self.d.live_reader.frame is not None)
            self.d.grab().save(str(dest / "control-inputs-simulated.png"))


if __name__ == "__main__":
    unittest.main()
