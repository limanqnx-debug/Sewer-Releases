@echo off
cd /d "%~dp0"
if exist "Sewer.exe" (
    start "" "%~dp0Sewer.exe"
    exit /b
)
start "" pyw main.py
