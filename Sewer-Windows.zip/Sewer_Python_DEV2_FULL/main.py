from __future__ import annotations

import sys
from pathlib import Path

from PySide6 import QtWidgets

from sewer.config import load_config
from sewer.controller import SewerController
from sewer.gui import MainWindow
from sewer.runtime import prepare_user_files


def main() -> int:
    app = QtWidgets.QApplication(sys.argv)
    app.setApplicationName("Sewer-P")
    try:
        root, config_path = prepare_user_files()
        if len(sys.argv) == 3 and sys.argv[1] == "--self-test":
            from sewer.selftest import run_self_test
            return run_self_test(app, root, config_path, Path(sys.argv[2]))
        config = load_config(config_path)
        controller = SewerController(root, config_path, config)
        window = MainWindow(controller)
        window.show()
        return app.exec()
    except Exception as e:
        if len(sys.argv) == 3 and sys.argv[1] == "--self-test":
            import json, traceback
            Path(sys.argv[2]).write_text(json.dumps({"ok":False,"error":str(e),"traceback":traceback.format_exc()},ensure_ascii=False),encoding="utf-8")
            return 1
        QtWidgets.QMessageBox.critical(None, "Sewer", f"Не удалось запустить Sewer.\n\n{e}")
        return 1


if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    raise SystemExit(main())
