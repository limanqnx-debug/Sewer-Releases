from __future__ import annotations

import sys
from pathlib import Path

from PySide6 import QtWidgets

from sewer.config import load_config
from sewer.controller import SewerController
from sewer.gui import MainWindow


def main() -> int:
    root = Path(__file__).resolve().parent
    config_path = root / "config.json"
    app = QtWidgets.QApplication(sys.argv)
    app.setApplicationName("Sewer")
    try:
        config = load_config(config_path)
        controller = SewerController(root, config_path, config)
        window = MainWindow(controller)
        window.show()
        return app.exec()
    except Exception as e:
        QtWidgets.QMessageBox.critical(None, "Sewer", f"Не удалось запустить Sewer.\n\n{e}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
