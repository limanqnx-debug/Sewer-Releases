# Sewer-P — Settings update (base v1.0.5)

- Numeric settings: arrow buttons removed; keyboard entry and mouse wheel retained.
- COM baud rate: standard values from 1200 to 921600; custom entry disabled.
- No board threshold: three decimal places in amperes.
- Programmer and firmware: Browse file dialogs, manual paths retained.
- Rigol settings tab renamed to Rigol.
- USB / ETH selection with separate remembered addresses; ETH accepts host/IP or a full TCPIP VISA resource.
- Existing Resource config key continues to drive the connection.

Validation: all Python files compile; USB and ETH resource conversion checked.
GUI and hardware validation on Windows is pending (local Qt runtime lacks libEGL).

Extract the folder and run using the existing install.bat / run.bat procedure.
To keep your settings, copy your current config.json into this folder before starting.
