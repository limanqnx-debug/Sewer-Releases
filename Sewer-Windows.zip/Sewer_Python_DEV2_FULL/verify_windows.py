"""Launch only the built EXE from a Unicode path, with Python absent from PATH."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile


def main():
    root = Path(__file__).resolve().parent
    exe = root / "dist" / "Sewer.exe"
    out = root / "dist" / "smoke"
    out.mkdir(exist_ok=True)
    import pefile
    pe = pefile.PE(str(exe), fast_load=True)
    assert pe.FILE_HEADER.Machine == 0x8664, "Not a Windows x64 executable"
    assert pe.OPTIONAL_HEADER.Subsystem == 2, "The EXE must not open a console"
    pe.close()
    env = dict(os.environ)
    for key in ("PYTHONHOME", "PYTHONPATH", "VIRTUAL_ENV", "QT_PLUGIN_PATH", "QT_QPA_PLATFORM_PLUGIN_PATH"):
        env.pop(key, None)
    # os.environ is case-insensitive on Windows; a copied plain dict is not.
    system_root = os.environ["SystemRoot"]
    env["PATH"] = os.pathsep.join([system_root, str(Path(system_root) / "System32")])
    # Use Windows' native font database and platform plugin, as in a real launch.
    # Qt's offscreen plugin in a frozen Windows bundle may have no font directory.
    env["QT_QPA_PLATFORM"] = "windows"
    with tempfile.TemporaryDirectory(prefix="Sewer EXE ") as temporary:
        install = Path(temporary) / "Sewer Проверка"
        cwd = Path(temporary) / "empty-working-dir"
        install.mkdir(); cwd.mkdir()
        target = install / "Sewer.exe"
        shutil.copy2(exe, target)
        for attempt in (1, 2):
            report = out / f"launch-{attempt}.json"
            subprocess.run([str(target), "--self-test", str(report)], cwd=cwd, env=env, check=True, timeout=120)
            data = json.loads(report.read_text(encoding="utf-8"))
            assert data["ok"] and data["frozen"] and data["bits"] == 64, data
            assert Path(data["data_dir"]).resolve() == install.resolve()
            assert not (cwd / "config.json").exists()
            if attempt == 1:
                saved = json.loads((install / "config.json").read_text(encoding="utf-8-sig"))
                saved["EXE_Persistence_Check"] = "keep"
                (install / "config.json").write_text(json.dumps(saved), encoding="utf-8")
            else:
                assert data["loaded_theme"] == "hellokitty"
                assert json.loads((install / "config.json").read_text(encoding="utf-8-sig"))["EXE_Persistence_Check"] == "keep"
    summary = {"ok": True, "exe_sha256": hashlib.sha256(exe.read_bytes()).hexdigest(),
               "exe_bytes": exe.stat().st_size, "launches": 2, "python_on_path": False}
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
