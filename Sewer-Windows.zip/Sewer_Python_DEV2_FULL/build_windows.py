"""Run with Windows x64 Python: python build_windows.py."""
from pathlib import Path
import platform
import subprocess
import sys


def main():
    if sys.platform != "win32" or platform.architecture()[0] != "64bit":
        raise SystemExit("Build Sewer.exe on Windows with 64-bit Python")
    root = Path(__file__).resolve().parent
    build = root / "build"
    build.mkdir(exist_ok=True)
    version = (root / "version.txt").read_text().strip().lstrip("v")
    version_numbers = tuple(int(n) for n in version.split(".")) + (0,)
    info = build / "version_info.txt"
    info.write_text(f'''VSVersionInfo(
 ffi=FixedFileInfo(filevers={version_numbers!r}, prodvers={version_numbers!r}, mask=0x3f, flags=0x0, OS=0x40004, fileType=0x1, subtype=0x0, date=(0,0)),
 kids=[StringFileInfo([StringTable('040904B0',[
  StringStruct('FileDescription','Sewer-P'), StringStruct('FileVersion','{version}'),
  StringStruct('ProductName','Sewer-P'), StringStruct('ProductVersion','{version}'),
  StringStruct('OriginalFilename','Sewer.exe')])]), VarFileInfo([VarStruct('Translation',[1033,1200])])])
''', encoding="utf-8")
    command = [sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean", "--onefile", "--windowed",
               "--name", "Sewer", "--noupx", "--icon", "Resources/Hedgehog.png",
               "--version-file", str(info), "--add-data", "Resources:Resources",
               "--add-data", "sewer/theme_palettes.json:sewer", "--add-data", "config.json:.",
               "--add-data", "version.txt:.", "--hidden-import", "pyvisa.ctwrapper.highlevel",
               "--hidden-import", "serial.tools.list_ports_windows", "--collect-submodules", "pyvisa.resources",
               "--copy-metadata", "PyVISA", "--copy-metadata", "pyserial", "--copy-metadata", "pyqtgraph",
               "--exclude-module", "PySide6.QtWebEngineCore", "--exclude-module", "PySide6.QtWebEngineWidgets",
               "--exclude-module", "matplotlib", "--exclude-module", "scipy", "main.py"]
    subprocess.run(command, cwd=root, check=True)
    executable = root / "dist" / "Sewer.exe"
    assert executable.is_file() and executable.stat().st_size > 10_000_000
    print(executable)


if __name__ == "__main__":
    main()
