"""Instrument marker values. No interpolation or synthetic peaks are used."""
from __future__ import annotations

from dataclasses import dataclass
import math
import time

from .rigol import RigolConnectionError


@dataclass(frozen=True)
class Marker:
    number: int
    mode: str
    trace: int = 0
    readout: str = ""
    x: float | None = None
    y: float | None = None
    reference: int | None = None
    continuous: bool = False
    function: str = "OFF"
    error: str = ""


@dataclass(frozen=True)
class MarkerSnapshot:
    mode: str
    view: str
    center_hz: float
    span_hz: float
    y_unit: str
    markers: tuple[Marker, ...]
    captured_at: float

    def matches(self, frame):
        return frame is not None and (self.mode, self.view, self.center_hz, self.span_hz, self.y_unit) == (
            frame.mode, frame.view, frame.center_hz, frame.span_hz, frame.y_unit)

    def position(self, number, frame):
        """Absolute plot coordinates, or None when the readout cannot be mapped safely."""
        if not self.matches(frame):
            return None
        marker = self.markers[number - 1]
        if marker.error or marker.mode == "OFF" or marker.trace != frame.trace or marker.function != "OFF":
            return None
        expected = "TIME" if frame.x_unit == "ms" else "FREQ"
        if marker.readout != expected or marker.x is None or marker.y is None:
            return None
        x, y = marker.x, marker.y
        if marker.mode == "DELT":
            if marker.reference not in range(1, 9) or self.y_unit not in ("dBm", "dBmV", "dBµV"):
                return None
            ref = self.markers[marker.reference - 1]
            # Do not guess an absolute position from cyclic/relative references.
            if (ref.error or ref.mode not in ("POS", "FIX") or ref.readout != expected
                    or ref.function != "OFF" or ref.x is None or ref.y is None):
                return None
            x += ref.x
            y += ref.y
        x *= 1000 if expected == "TIME" else 1e-6
        if not math.isfinite(x) or not math.isfinite(y) or not frame.x[0] <= x <= frame.x[-1]:
            return None
        return x, y


class RigolMarkerControl:
    ACTIONS = {
        "peak": "MAXimum:MAX", "next": "MAXimum:NEXT", "left": "MAXimum:LEFT",
        "right": "MAXimum:RIGHt", "minimum": "MINimum", "center": "SET:CENTer",
        "reference_level": "SET:RLEVel", "delta_span": "SET:DELTa:SPAN",
    }

    def __init__(self, rigol):
        self.rigol = rigol

    @staticmethod
    def prefix(number):
        if isinstance(number, bool) or number not in range(1, 9):
            raise ValueError("Номер маркера должен быть от 1 до 8")
        return f":CALCulate:MARKer{number}"

    def mode(self, number):
        value = self.rigol.query(self.prefix(number) + ":MODE?").upper()
        if value not in ("OFF", "POS", "DELT", "FIX"):
            raise ValueError("Неизвестный режим маркера: " + value)
        return value

    def read(self):
        r = self.rigol
        with r.lock:
            mode = r.mode()
            view = r.query(":CONFigure?").upper() if mode == "RTSA" else "SA"
            if mode == "RTSA" and view not in ("NORM", "DENS"):
                raise ValueError("Для маркеров спектра выберите Normal или Density на Rigol")
            center, span = r.center_hz(), r.span_hz()
            if not math.isfinite(center) or not math.isfinite(span) or span < 0:
                raise ValueError("Некорректный частотный диапазон маркеров")
            unit = {"DBM": "dBm", "DBMV": "dBmV", "DBUV": "dBµV", "V": "V", "W": "W"}.get(r.query(":UNIT:POWer?").upper())
            if unit is None:
                raise ValueError("Неизвестная единица уровня маркера")
            markers = []
            for n in range(1, 9):
                try:
                    typ = self.mode(n)
                    if typ == "OFF":
                        markers.append(Marker(n, typ))
                        continue
                    prefix = self.prefix(n)
                    trace = int(r.query(prefix + ":TRACe?"))
                    readout = r.query(prefix + ":X:READout?").upper()
                    x, y = r.query_float(prefix + ":X?"), r.query_float(prefix + ":Y?")
                    reference = int(r.query(prefix + ":REFerence?")) if typ == "DELT" else None
                    continuous = r.query_bool(prefix + ":CPSearch:STATe?")
                    function = r.query(prefix + ":FUNCtion?").upper()
                    if trace not in range(1, 7) or not all(math.isfinite(v) and abs(v) < 1e30 for v in (x, y)):
                        raise ValueError("Нет достоверного измерения")
                    markers.append(Marker(n, typ, trace, readout, x, y, reference, continuous, function))
                except RigolConnectionError:
                    raise
                except Exception as exc:
                    markers.append(Marker(n, "?", error=str(exc)))
            return MarkerSnapshot(mode, view, center, span, unit, tuple(markers), time.monotonic())

    def configure(self, number, mode, trace, reference):
        prefix = self.prefix(number)
        if mode not in ("POS", "DELT", "FIX", "OFF") or trace not in range(1, 7):
            raise ValueError("Некорректный режим или Trace маркера")
        r = self.rigol
        with r.lock:
            if mode == "OFF":
                r.write(prefix + ":MODE OFF")
                return
            if not r.trace_display(trace):
                raise ValueError(f"Сначала включите Display для Trace {trace}")
            if mode == "DELT":
                self.prefix(reference)
                if reference == number or self.mode(reference) not in ("POS", "FIX"):
                    raise ValueError("Для Delta выберите другой включённый маркер Normal или Fixed")
            r.write(prefix + ":MODE " + mode)
            r.write(prefix + ":TRACe:AUTO OFF")
            r.write(prefix + f":TRACe {trace}")
            if mode == "DELT":
                r.write(prefix + f":REFerence {reference}")

    def require_enabled(self, number):
        mode = self.mode(number)
        if mode == "OFF":
            raise ValueError(f"Сначала включите M{number}")
        return mode

    def set_x(self, number, value, readout):
        prefix = self.prefix(number)
        if readout not in ("FREQ", "TIME") or not math.isfinite(value):
            raise ValueError("Поддерживается ввод частоты или времени")
        with self.rigol.lock:
            self.require_enabled(number)
            actual = self.rigol.query(prefix + ":X:READout?").upper()
            if actual != readout:
                raise ValueError("Режим отсчёта изменился на приборе; прочитайте маркеры заново")
            self.rigol.write(prefix + f":X {value:.12g}" + ("HZ" if readout == "FREQ" else "S"))

    def set_continuous(self, number, enabled):
        with self.rigol.lock:
            self.require_enabled(number)
            self.rigol.write(self.prefix(number) + ":CPSearch:STATe " + ("ON" if enabled else "OFF"))

    def action(self, number, action):
        if action not in self.ACTIONS:
            raise ValueError("Неизвестная операция с маркером")
        r = self.rigol
        with r.lock:
            mode = self.require_enabled(number)
            if action in ("center", "delta_span") and r.span_hz() == 0:
                raise ValueError("Эта операция недоступна при Span = 0")
            if action == "delta_span" and mode != "DELT":
                raise ValueError("Δ → Span доступно только для Delta")
            r.write(self.prefix(number) + ":" + self.ACTIONS[action])
            # Query settings immediately after commands that change the displayed axes.
            return {"center": r.center_hz(), "span": r.span_hz(), "ref": r.ref_level()} if action in (
                "center", "delta_span", "reference_level") else {}

    def all_off(self):
        self.rigol.write(":CALCulate:MARKer:AOFF")
