"""Read and configure markers on the analyzer."""
from __future__ import annotations

from dataclasses import dataclass
import math
import time
from bisect import bisect_left

from .rigol import RigolConnectionError


@dataclass(frozen=True)
class Marker:
    number: int
    mode: str
    trace: int = 0
    readout: str = ""
    x: float | None = None
    y: float | None = None
    reference: int | None = None
    continuous: bool = False
    function: str = "OFF"
    error: str = ""


@dataclass(frozen=True)
class MarkerSnapshot:
    mode: str
    view: str
    center_hz: float
    span_hz: float
    y_unit: str
    markers: tuple[Marker, ...]
    captured_at: float

    def matches(self, frame):
        return frame is not None and (self.mode, self.view, self.center_hz, self.span_hz, self.y_unit) == (
            frame.mode, frame.view, frame.center_hz, frame.span_hz, frame.y_unit)

    def position(self, number, frame, *, on_trace=False):
        """Absolute plot coordinates, or None when the readout cannot be mapped safely."""
        if not self.matches(frame):
            return None
        marker = self.markers[number - 1]
        if marker.mode not in ("POS", "DELT", "FIX") or marker.trace != frame.trace:
            return None
        expected = "TIME" if frame.x_unit == "ms" else "FREQ"
        if marker.readout != expected or marker.x is None:
            return None
        x, y = marker.x, marker.y
        trace_level = marker.function != "OFF" or (on_trace and marker.mode != "FIX")
        if marker.mode == "DELT":
            if marker.reference not in range(1, 9) or marker.reference == number:
                return None
            ref = self.markers[marker.reference - 1]
            # Do not guess an absolute position from cyclic/relative references.
            if ref.mode not in ("POS", "FIX") or ref.readout != expected or ref.x is None:
                return None
            x += ref.x
            trace_level = trace_level or ref.function != "OFF" or not self.y_unit.startswith("dB")
            if not trace_level:
                y = y + ref.y if y is not None and ref.y is not None else None
        x *= 1000 if expected == "TIME" else 1e-6
        # Conversion from Hz to MHz can leave an endpoint one float outside the sweep.
        if (not math.isfinite(x) or x < math.nextafter(float(frame.x[0]), -math.inf)
                or x > math.nextafter(float(frame.x[-1]), math.inf)):
            return None
        x = min(max(x, float(frame.x[0])), float(frame.x[-1]))
        if trace_level:
            # Place a tracking marker on the same frame as the curve, even if its
            # independently polled level is older or is not an absolute level.
            i = min(bisect_left(frame.x, x), len(frame.x) - 1)
            j = max(0, i - 1)
            y = frame.y[i]
            if frame.x[i] != frame.x[j]:
                y = frame.y[j] + (y - frame.y[j]) * (x - frame.x[j]) / (frame.x[i] - frame.x[j])
        return (x, float(y)) if y is not None and math.isfinite(y) else None


class RigolMarkerControl:
    ACTIONS = {
        "peak": "MAXimum:MAX", "next": "MAXimum:NEXT", "left": "MAXimum:LEFT",
        "right": "MAXimum:RIGHt", "minimum": "MINimum", "center": "SET:CENTer",
        "reference_level": "SET:RLEVel", "delta_span": "SET:DELTa:SPAN",
    }

    def __init__(self, rigol):
        self.rigol = rigol

    @staticmethod
    def prefix(number):
        if isinstance(number, bool) or number not in range(1, 9):
            raise ValueError("Номер маркера должен быть от 1 до 8")
        return f":CALCulate:MARKer{number}"

    def mode(self, number):
        value = self.rigol.query(self.prefix(number) + ":MODE?").upper()
        if value not in ("OFF", "POS", "DELT", "FIX"):
            raise ValueError("Неизвестный режим маркера: " + value)
        return value

    def read(self):
        r = self.rigol
        with r.lock:
            mode = r.mode()
            view = r.query(":CONFigure?").upper() if mode == "RTSA" else "SA"
            if mode == "RTSA" and view not in ("NORM", "DENS", "DSPE"):
                raise ValueError("Для маркеров спектра выберите Normal или Density на Rigol")
            center, span = r.center_hz(), r.span_hz()
            if not math.isfinite(center) or not math.isfinite(span) or span < 0:
                raise ValueError("Некорректный частотный диапазон маркеров")
            unit = {"DBM": "dBm", "DBMV": "dBmV", "DBUV": "dBµV", "V": "V", "W": "W"}.get(r.query(":UNIT:POWer?").upper())
            if unit is None:
                raise ValueError("Неизвестная единица уровня маркера")
            markers = []
            for n in range(1, 9):
                typ, trace, readout, reference, continuous, function = "?", 0, "", None, False, "OFF"
                x = y = None
                try:
                    typ = self.mode(n)
                    if typ == "OFF":
                        markers.append(Marker(n, typ))
                        continue
                    prefix = self.prefix(n)
                    trace = int(r.query(prefix + ":TRACe?"))
                    reference = int(r.query(prefix + ":REFerence?")) if typ == "DELT" else None
                    continuous = r.query_bool(prefix + ":CPSearch:STATe?")
                    function = r.query(prefix + ":FUNCtion?").upper()
                    readout = r.query(prefix + ":X:READout?").upper()
                    x = self._finite_reading(r.query_float(prefix + ":X?"))
                    y = self._finite_reading(r.query_float(prefix + ":Y?"))
                    if trace not in range(1, 7) or x is None or y is None:
                        raise ValueError("Нет достоверного измерения")
                    markers.append(Marker(n, typ, trace, readout, x, y, reference, continuous, function))
                except RigolConnectionError:
                    raise
                except Exception as exc:
                    markers.append(Marker(n, typ, trace, readout, x, y, reference, continuous, function, str(exc)))
            return MarkerSnapshot(mode, view, center, span, unit, tuple(markers), time.monotonic())

    @staticmethod
    def _finite_reading(value):
        return value if math.isfinite(value) and abs(value) < 1e30 else None

    def _absolute_delta_x(self, number, reference):
        if reference not in range(1, 9) or reference == number or self.mode(reference) not in ("POS", "FIX"):
            return None
        delta = self.prefix(number)
        r = self.rigol
        readout = r.query(delta + ":X:READout?").upper()
        if readout not in ("FREQ", "TIME"):
            return None
        x1 = self._finite_reading(r.query_float(delta + ":X?"))
        x2 = self._read_x(reference, readout)
        return (x1 + x2, readout) if x1 is not None and x2 is not None else None

    def _read_x(self, number, readout):
        prefix = self.prefix(number)
        if self.rigol.query(prefix + ":X:READout?").upper() == readout:
            return self._finite_reading(self.rigol.query_float(prefix + ":X?"))
        return None

    def _write_x(self, prefix, value, readout):
        self.rigol.write(prefix + f":X {value:.12g}" + ("HZ" if readout == "FREQ" else "S"))

    def _set_mode(self, prefix, mode, absolute_x=None):
        self.rigol.write(prefix + ":MODE " + mode)
        self._restore_x(prefix, absolute_x)

    def _restore_x(self, prefix, absolute_x, reference=None):
        if absolute_x is not None:
            value, readout = absolute_x
            if reference is not None:
                reference_x = self._read_x(reference, readout)
                if reference_x is None:
                    return
                value -= reference_x
            if self.rigol.query(prefix + ":X:READout?").upper() == readout:
                self._write_x(prefix, value, readout)

    def _release_dependents(self, number):
        r = self.rigol
        for other in range(1, 9):
            if other != number and self.mode(other) == "DELT":
                prefix = self.prefix(other)
                if int(r.query(prefix + ":REFerence?")) == number:
                    self._set_mode(prefix, "POS", self._absolute_delta_x(other, number))

    def configure(self, number, mode, trace, reference):
        prefix = self.prefix(number)
        if mode not in ("POS", "DELT", "FIX", "OFF") or trace not in range(1, 7):
            raise ValueError("Некорректный режим или Trace маркера")
        r = self.rigol
        with r.lock:
            if mode == "DELT" and reference is None:
                mode = "POS"
            if mode == "OFF":
                self._release_dependents(number)
                self._set_mode(prefix, "OFF")
                return
            if not r.trace_display(trace):
                raise ValueError(f"Сначала включите Display для Trace {trace}")
            if mode == "DELT":
                self.prefix(reference)
                ref_mode = self.mode(reference)
                if reference == number or ref_mode not in ("POS", "FIX", "OFF"):
                    raise ValueError("Опорой может быть только другой маркер Normal или Fixed")
            current = self.mode(number)
            absolute_x = None
            if current == "DELT":
                current_reference = int(r.query(prefix + ":REFerence?"))
                if mode != "DELT" or current_reference != reference:
                    absolute_x = self._absolute_delta_x(number, current_reference)
            if mode == "DELT":
                if current in ("POS", "FIX"):
                    self._release_dependents(number)
                if ref_mode == "OFF":
                    ref_prefix = self.prefix(reference)
                    self._set_mode(ref_prefix, "POS")
                    r.write(ref_prefix + ":TRACe:AUTO OFF")
                    r.write(ref_prefix + f":TRACe {trace}")
                if current == "OFF":
                    self._set_mode(prefix, "POS")
            else:
                self._set_mode(prefix, mode)
            r.write(prefix + ":TRACe:AUTO OFF")
            r.write(prefix + f":TRACe {trace}")
            if mode == "DELT":
                r.write(prefix + f":REFerence {reference}")
                if current != "DELT":
                    self._set_mode(prefix, mode)
                    if int(r.query(prefix + ":REFerence?")) != reference:
                        r.write(prefix + f":REFerence {reference}")
                if self.mode(number) != "DELT" or int(r.query(prefix + ":REFerence?")) != reference:
                    raise ValueError(f"Rigol не назначил M{reference} опорным для M{number}")
            self._restore_x(prefix, absolute_x, reference if mode == "DELT" else None)

    def require_enabled(self, number):
        mode = self.mode(number)
        if mode == "OFF":
            raise ValueError(f"Сначала включите M{number}")
        return mode

    def set_x(self, number, value, readout):
        prefix = self.prefix(number)
        if readout not in ("FREQ", "TIME") or not math.isfinite(value):
            raise ValueError("Поддерживается ввод частоты или времени")
        with self.rigol.lock:
            self.require_enabled(number)
            actual = self.rigol.query(prefix + ":X:READout?").upper()
            if actual != readout:
                raise ValueError("Режим отсчёта изменился на приборе; прочитайте маркеры заново")
            self._write_x(prefix, value, readout)

    def set_continuous(self, number, enabled):
        with self.rigol.lock:
            self.require_enabled(number)
            self.rigol.write(self.prefix(number) + ":CPSearch:STATe " + ("ON" if enabled else "OFF"))

    def action(self, number, action):
        if action not in self.ACTIONS:
            raise ValueError("Неизвестная операция с маркером")
        r = self.rigol
        with r.lock:
            mode = self.require_enabled(number)
            if action in ("center", "delta_span") and r.span_hz() == 0:
                raise ValueError("Эта операция недоступна при Span = 0")
            if action == "delta_span" and mode != "DELT":
                raise ValueError("Δ → Span доступно только для Delta")
            r.write(self.prefix(number) + ":" + self.ACTIONS[action])
            # Query settings immediately after commands that change the displayed axes.
            return {"center": r.center_hz(), "span": r.span_hz(), "ref": r.ref_level()} if action in (
                "center", "delta_span", "reference_level") else {}

    def all_off(self):
        self.rigol.write(":CALCulate:MARKer:AOFF")
