"""Persistent user files and bundled assets have separate locations in an EXE."""
from __future__ import annotations

import os
from pathlib import Path
import shutil
import sys
import tempfile


def asset_path(*parts: str) -> Path:
    return Path(__file__).resolve().parent.parent.joinpath(*parts)


def application_dir() -> Path:
    return Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else asset_path()


def _writable(directory: Path) -> bool:
    try:
        directory.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryFile(dir=directory):
            pass
        return True
    except OSError:
        return False


def prepare_user_files() -> tuple[Path, Path]:
    """Keep an existing config; seed a fresh portable installation just once."""
    app_dir = application_dir()
    root = app_dir
    if not _writable(root):
        base = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / ".local" / "share")))
        root = base / "Sewer-P"
        if not _writable(root):
            raise OSError("Нет доступа для сохранения настроек Sewer-P: " + str(root))
    config_path = root / "config.json"
    if not config_path.exists():
        source = app_dir / "config.json"
        if not source.is_file():
            source = asset_path("config.json")
        # Validate before creating the new persistent file.
        from .config import load_config
        load_config(source)
        try:
            with config_path.open("xb") as dest, source.open("rb") as src:
                shutil.copyfileobj(src, dest)
        except FileExistsError:
            pass
    return root, config_path
