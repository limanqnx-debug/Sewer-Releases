from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from PySide6 import QtCore

from .config import resolve_path, save_config
from .external_program import ExternalProgram
from .logger import SewerLogger
from .power_supply import OwonSPE3102
from .programmer import ProgrammerProcess
from .rigol import RigolRSA


class SewerController(QtCore.QObject):
    presets_changed = QtCore.Signal()
    preset_finished = QtCore.Signal(object, object)
    updated = QtCore.Signal()
    log_line = QtCore.Signal(str)
    rigol_span_changed = QtCore.Signal(float)
    rigol_access_changed = QtCore.Signal(bool)
    _task_done = QtCore.Signal(object, object, object)

    def __init__(self, root: Path, config_path: Path, config: dict):
        super().__init__()
        self.root = root
        self.temp_dir = root / "Temp"; self.temp_dir.mkdir(exist_ok=True)
        from .rigol_presets import PresetStore
        self.presets = PresetStore(root / "rigol_presets.json")
        self.config_path = config_path
        self.config = config
        self.state = "Idle"
        self.status_text = "Готов"
        self.deadline = 0.0
        self.stop_requested = False
        self.successful_boards = 0
        self.can_repeat = False
        self.ready = False
        self.readiness_reason = "Инициализация"
        self.started_at = time.monotonic()
        self.progress_state = "Idle"
        self._busy = False
        self._power_only = False
        self._closing = False
        self._executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="Sewer")
        self._task_done.connect(self._dispatch_task_done)
        self.logger = SewerLogger(root, config, self.log_line.emit)
        self.power = OwonSPE3102(config["PowerSupply"])
        self.programmer = ProgrammerProcess(root, self.temp_dir, config["Programmer"], self.logger)
        self.external = ExternalProgram(root, config.get("ExternalProgram", {}))
        rc = config.get("Rigol", {})
        self.rigol = RigolRSA(str(rc.get("Resource", "")), int(rc.get("TimeoutMs", 2500)))
        self.rigol_connected = False
        self.rigol_mode = "GPSA"
        self.rigol_error = ""
        self._next_power_probe = 0.0
        self._next_rigol_probe = 0.0
        self._power_probe_pending = False
        self._rigol_probe_pending = False
        self._rigol_action_pending = False
        self._rigol_connection_pending = False
        self._rigol_access_generation = 0
        self.timer = QtCore.QTimer(self)
        self.timer.setInterval(int(config.get("Application", {}).get("UpdateIntervalMs", 500)))
        self.timer.timeout.connect(self.tick)
        self.timer.start()
        QtCore.QTimer.singleShot(50, self.tick)

    def set_logger_sink(self, sink):
        self.log_line.connect(sink)

    def apply_config(self, new_config: dict) -> None:
        old_rig = self.config.get("Rigol", {}).copy()
        self.safe_stop("Настройки изменены.", log=False)
        self.config = save_config(new_config, self.config_path)
        self.logger.reconfigure(self.config)
        self.power.reconfigure(self.config["PowerSupply"])
        self.programmer.reconfigure(self.config["Programmer"])
        self.external.reconfigure(self.config.get("ExternalProgram", {}))
        rc = self.config.get("Rigol", {})
        if old_rig != rc:
            self.rigol.reconfigure(str(rc.get("Resource", "")), int(rc.get("TimeoutMs", 2500)))
            self.rigol_connected = False
        self.timer.setInterval(int(self.config.get("Application", {}).get("UpdateIntervalMs", 500)))
        self._next_power_probe = self._next_rigol_probe = 0.0
        self.logger.write(f"Настройки сохранены: {self.config_path}")
        self.updated.emit()

    @QtCore.Slot(object, object, object)
    def _dispatch_task_done(self, done, result, error):
        done(result, error)

    def _submit(self, fn, done):
        future = self._executor.submit(fn)
        def finished(f):
            try:
                result = f.result(); error = None
            except Exception as e:
                result = None; error = e
            self._task_done.emit(done, result, error)
        future.add_done_callback(finished)

    def _probe_power(self):
        if self._closing:
            return None
        # Reconnect only while idle. During a cycle, monitoring must only read
        # the existing session, without resetting the output or its limits.
        if self.state == "Idle" and not self._busy:
            return self.power.probe()
        return self.power.read_measurements()

    def _power_probe_done(self, result, error):
        self._power_probe_pending = False
        if self._closing:
            return
        self._next_power_probe = time.monotonic() + 1.0
        if error:
            self.power.snapshot.responding = False
        if self.state == "ManualPower":
            snapshot = self.power.snapshot
            if error or not snapshot.responding:
                self.safe_stop("Источник не отвечает. Ручное питание остановлено.", "Ошибка источника", "Error", False)
                return
            cfg = self.config["PowerSupply"]
            if snapshot.current <= float(cfg.get("NoBoardCurrent", .001)):
                self.safe_stop("Плата не подключена. Ручное питание отключено.", "Плата не подключена", "Error", False)
                return
            if snapshot.current > float(cfg.get("TripCurrent", .1)):
                self.safe_stop(f"Авария: превышение тока ({snapshot.current * 1000:.1f} мА).", "Превышение тока", "Error", False)
                return
        self.update_readiness()
        self.updated.emit()

    def _probe_rigol(self):
        rc = self.config.get("Rigol", {})
        with self.rigol.lock:
            if self._closing or self.rigol.suspended or self._rigol_connection_pending:
                return None
            ok = self.rigol.identity_ok(str(rc.get("ExpectedManufacturer","RIGOL")), str(rc.get("ExpectedModel","RSA5065N")))
            if not ok:
                return False, "—", self.rigol.last_error or "Нет ответа на *IDN?"
            try:
                mode = self.rigol.mode()
                return True, mode, ""
            except ValueError as exc:
                # A valid IDN establishes the link even in another analyzer mode.
                return True, "—", str(exc)

    def _rigol_probe_done(self, result, error, generation=None):
        self._rigol_probe_pending = False
        if (self._closing or self.rigol.suspended or self._rigol_connection_pending
                or (generation is not None and generation != self._rigol_access_generation)):
            return
        interval = int(self.config.get("Rigol", {}).get("MonitorIntervalMs", 2500)) / 1000
        self._next_rigol_probe = time.monotonic() + max(.5, interval)
        previous_error = self.rigol_error
        if error or not result:
            self.rigol_connected = False; self.rigol_error = str(error or "Нет ответа")
            self.rigol_mode = "—"
        else:
            self.rigol_connected, self.rigol_mode, self.rigol_error = result
        if self.rigol_error and self.rigol_error != previous_error:
            self.logger.write("Rigol: " + self.rigol_error)
        self.updated.emit()

    def update_readiness(self) -> bool:
        reason = ""
        s = self.power.snapshot
        if not s.com_available: reason = "COM-порт не найден"
        elif not s.responding: reason = "Источник не отвечает"
        else:
            err = self.programmer.configuration_error()
            if err: reason = err.rstrip(".")
            else:
                ext_err = self.external.configuration_error()
                if ext_err: reason = ext_err.rstrip(".")
        new_ready = not reason
        changed = new_ready != self.ready or reason != self.readiness_reason
        self.ready, self.readiness_reason = new_ready, reason
        if changed and self.state == "Idle":
            self.logger.write("Стенд готов к работе." if new_ready else f"Стенд не готов: {reason}.")
        return new_ready

    def power_on(self):
        self.start_cycle(power_only=True)

    def start_cycle(self, power_only=False) -> None:
        if self.state != "Idle" or self._busy:
            return
        if power_only:
            snapshot = self.power.snapshot
            if not snapshot.com_available or not snapshot.responding:
                self.logger.write("Включение невозможно: источник не подключён или не отвечает.")
                return
        elif not self.update_readiness():
            self.logger.write(f"Запуск невозможен: {self.readiness_reason}.")
            return
        self.stop_requested = False
        self._power_only = bool(power_only)
        self.can_repeat = False
        self.progress_state = "Preparing"
        self.status_text = "Проверка источника"
        self.state = "Preparing"
        self._busy = True
        self.logger.write("Включение источника: Alt+Z." if power_only else "Старт.")
        self.updated.emit()

        def prepare():
            if not self.power.is_open and not self.power.connect():
                return False, ["Не удалось подключить источник."]
            if not self.power.snapshot.responding and not self.power.initialize():
                return False, ["Не удалось настроить источник."]
            ok, msgs = self.power.confirm_limits()
            return ok, msgs

        def prepared(result, error):
            self._busy = False
            if self.stop_requested:
                return
            if error or not result or not result[0]:
                self.safe_stop("Не удалось проверить или восстановить ограничения источника.", "Ошибка источника", "Error", False)
                return
            for msg in result[1]: self.logger.write(msg + ". Коррекция подтверждена.")
            if not self.power.output(True):
                self.safe_stop("Не удалось включить источник.", "Ошибка источника", "Error", False)
                return
            self.logger.write("Источник ON.")
            self._next_power_probe = 0.0
            self.state = "PowerDelay"; self.status_text = "Подача питания"
            self.deadline = time.monotonic() + int(self.config["PowerSupply"].get("PowerOnDelayMs",1000))/1000
            self.updated.emit()
        self._submit(prepare, prepared)

    def _start_current_check(self):
        if self._busy: return
        self._busy = True; self.status_text = "Контроль тока"; self.updated.emit()
        cfg = self.config["PowerSupply"]
        def measure():
            # Also refresh voltage during the settling/current-check phase,
            # including cycles whose programming step finishes very quickly.
            self.power.measure_voltage()
            return self.power.average_current(int(cfg.get("CurrentSamples",5)), int(cfg.get("SampleDelayMs",100)), lambda:self.stop_requested)
        def measured(avg, error):
            self._busy = False
            if self.stop_requested: return
            if error or avg is None:
                self.safe_stop("Не удалось измерить ток.", "Ошибка источника", "Error", False); return
            ma = avg * 1000
            if avg <= float(cfg.get("NoBoardCurrent",.001)):
                self.safe_stop(f"Плата не подключена ({ma:.1f} мА).", "Плата не подключена", "Error", False); return
            if avg > float(cfg.get("TripCurrent",.1)):
                self.safe_stop(f"Авария: превышение тока ({ma:.1f} мА).", "Превышение тока", "Error", False); return
            if avg < float(cfg.get("LowCurrent",.03)):
                self.logger.write(f"Предупреждение: низкий ток ({ma:.1f} мА).")
            elif avg > float(cfg.get("HighCurrent",.06)):
                self.logger.write(f"Предупреждение: повышенный ток ({ma:.1f} мА).")
            else:
                self.logger.write(f"Ток в норме ({ma:.1f} мА).")
            if self._power_only:
                self.state="ManualPower"; self.status_text="Ручное питание"; self.progress_state="Idle"
                self.logger.write("Ручное питание включено. Отключение: Стоп / Esc.")
                self.updated.emit()
            elif self.programmer.start():
                self.state="Programming"; self.status_text="Прошивка"; self.progress_state="Running"; self.updated.emit()
            else:
                self.safe_stop("Не удалось запустить Programmer.", "Ошибка Programmer", "Error", False)
        self._submit(measure, measured)

    def _programmer_finished(self, code: int):
        self.programmer.complete_log(code)
        self.programmer.process = None
        if code == 0:
            self.programmer.progress = 100
            self.progress_state = "Success"
            self.successful_boards += 1
            self.logger.write("Прошивка завершена успешно.")
            if self.external.enabled():
                if self.external.start():
                    self.state="ExternalProgram"; self.status_text="Внешняя программа"
                    self.logger.write("Источник оставлен включённым до закрытия сторонней программы.")
                    self.updated.emit(); return
                self.safe_stop("Ошибка запуска сторонней программы.", "Ошибка программы", "Error", False); return
            if bool(self.config["PowerSupply"].get("AutoPowerOffAfterSuccess", True)):
                self.power.output(False); self.logger.write("Источник отключен автоматически.")
            else:
                self.logger.write("Источник оставлен включённым.")
            self.set_idle(True, "Success")
        else:
            self.power.output(False)
            self.progress_state="Error"
            self.logger.write(f"Programmer завершил работу с ошибкой, код {code}.")
            if self.programmer.last_error: self.logger.write(f"Programmer: {self.programmer.last_error}")
            if self.programmer.log_path: self.logger.write(f"Лог Programmer: {self.programmer.log_path}")
            self.set_idle(True, "Error")

    def set_idle(self, repeat=True, progress="Idle"):
        self.state="Idle"; self.status_text="Готов"; self.progress_state=progress; self.can_repeat=repeat
        self.stop_requested=False; self.deadline=0.0; self.update_readiness(); self.updated.emit()

    def safe_stop(self, reason: str, status="Готов", progress="Idle", repeat=True, log=True):
        self.stop_requested=True
        self.programmer.stop(); self.external.stop(); self.power.output(False)
        self.state="Idle"; self.status_text=status; self.progress_state=progress; self.can_repeat=repeat; self.deadline=0.0
        if log and reason: self.logger.write(reason)
        self.update_readiness(); self.updated.emit()

    def stop_cycle(self):
        if self.state != "Idle" or self._busy or self.power.snapshot.output_on:
            self.safe_stop("Процесс остановлен оператором.", "Готов", "Idle", True)

    def switch_rigol_mode(self):
        if not self.rigol_connected or self._rigol_action_pending: return
        target = "RTSA" if self.rigol_mode == "GPSA" else "GPSA"
        try:
            self.rigol.set_mode(target); self.rigol_mode = target; self.logger.write(f"Rigol: режим {target}.")
        except Exception as e:
            self.rigol_connected=False; self.rigol_error=str(e)
        self.updated.emit()

    def toggle_rigol_connection(self):
        if self._closing or self._rigol_action_pending:
            return
        if self.rigol.connected and not self.rigol.suspended:
            self.release_rigol()
        else:
            self.connect_rigol()

    def release_rigol(self):
        if self._closing or self._rigol_action_pending:
            return
        self._rigol_action_pending = self._rigol_connection_pending = True
        self._rigol_access_generation += 1
        self.rigol.suspended = True
        self.rigol.release_cancel.clear()
        self.rigol_connected = False
        self.rigol_error = ""
        self.rigol_access_changed.emit(False)
        self.logger.write("Rigol: освобождение передней панели…")
        self.updated.emit()

        def done(message, error):
            self._rigol_action_pending = self._rigol_connection_pending = False
            if self._closing:
                return
            self.rigol_connected = False
            self.rigol_error = str(error) if error else ""
            self.logger.write("Rigol: " + ("Опрос остановлен, освобождение панели не подтверждено: " + str(error) if error else message))
            self.updated.emit()
        self._submit(self.rigol.release_control, done)

    def connect_rigol(self, resource=None):
        if self._closing or self._rigol_action_pending:
            return
        self._rigol_action_pending = self._rigol_connection_pending = True
        self._rigol_access_generation += 1
        self.rigol_connected = False
        self.rigol_error = ""
        self.rigol_access_changed.emit(False)
        self.updated.emit()
        def connect():
            with self.rigol.lock:
                if self._closing:
                    return None
                rc = self.config.get("Rigol", {})
                self.rigol.reconfigure(resource if resource is not None else self.rigol.resource, int(rc.get("TimeoutMs",2500)))
                self.rigol.suspended = False
                self.rigol.connect(str(rc.get("ExpectedManufacturer","RIGOL")),str(rc.get("ExpectedModel","RSA5065N")))
                return self.rigol.mode()
        def done(mode, error):
            self._rigol_action_pending = self._rigol_connection_pending = False
            if self._closing:
                return
            self.rigol_connected = self.rigol.connected
            self.rigol_mode = mode or "—"
            self.rigol_error = str(error) if error else ""
            self._next_rigol_probe = time.monotonic() + 2.5
            self.logger.write("Rigol: " + ("ошибка подключения: " + str(error) if error else f"подключён, {mode}."))
            self.rigol_access_changed.emit(not self.rigol.suspended)
            self.updated.emit()
        self._submit(connect, done)

    def preset_task(self, operation, callback):
        if self._closing or self._rigol_action_pending or not self.rigol.connected:
            return False
        self._rigol_action_pending = self._rigol_connection_pending = True
        self._rigol_access_generation += 1
        self.rigol_access_changed.emit(False)
        self.updated.emit()
        def done(result, error):
            self._rigol_action_pending = self._rigol_connection_pending = False
            if self._closing:
                return
            self.rigol_connected = self.rigol.connected
            self.rigol_error = str(error) if error else ""
            self._next_rigol_probe = 0.0
            callback(result, error)
            self.rigol_access_changed.emit(not self.rigol.suspended and self.rigol.connected)
            self.updated.emit()
        self._submit(operation, done)
        return True

    def apply_rigol_preset(self, row):
        from .rigol_presets import apply_preset
        import copy
        row = copy.deepcopy(row)
        def done(result, error):
            if error:
                self.logger.write("Rigol, пресет: " + str(error))
            else:
                self.rigol_mode = result['mode']
                self.rigol_span_changed.emit(result['span'])
                self.logger.write("Rigol, пресет «" + result['name'] + "»: считанные значения " + str(result['actual']))
            self.preset_finished.emit(result, error)
        return self.preset_task(lambda: apply_preset(self.rigol, row), done)

    def set_rigol_rtsa_span(self, hz=500_000):
        if not self.rigol_connected or self.rigol_mode != "RTSA" or self._rigol_action_pending:
            return
        self._rigol_action_pending = True
        self.updated.emit()

        def done(actual_hz, error):
            self._rigol_action_pending = False
            self._next_rigol_probe = 0.0
            if error:
                self.rigol_connected = self.rigol.connected
                self.rigol_error = str(error)
                self.logger.write("Rigol: " + str(error))
            else:
                self.rigol_error = ""
                text = f"Rigol: RTSA, Span {actual_hz / 1000:g} кГц."
                if abs(actual_hz - hz) > 1:
                    text += f" Прибор вернул другое значение вместо {hz / 1000:g} кГц."
                self.logger.write(text)
                self.rigol_span_changed.emit(actual_hz)
            self.updated.emit()

        self._submit(lambda: self.rigol.set_rtsa_span_hz(hz), done)

    def tick(self):
        if self._closing:
            return
        now = time.monotonic()
        if not self.rigol.suspended and not self._rigol_action_pending and not self._rigol_probe_pending and now >= self._next_rigol_probe:
            generation = self._rigol_access_generation
            self._rigol_probe_pending = True
            self._submit(self._probe_rigol, lambda result,error:self._rigol_probe_done(result,error,generation))
        if self.state == "PowerDelay" and now >= self.deadline:
            self.state = "CurrentCheck"; self._start_current_check()
        elif self.state == "Programming":
            code = self.programmer.poll()
            if code is not None:
                self._programmer_finished(code)
        elif self.state == "ExternalProgram":
            if self.external.process is None:
                self.safe_stop("Процесс сторонней программы потерян.", "Ошибка программы", "Error", False)
            elif self.external.poll() is not None:
                self.external.process = None
                self.power.output(False); self.logger.write("Сторонняя программа закрыта. Источник отключен.")
                p = self.config.get("Pulse", {})
                if p.get("Enabled", False):
                    self.state="PulsePause"; self.status_text="Пауза"; self.deadline=now+float(p.get("PauseSeconds",1)); self.logger.write(f"Импульс: пауза {float(p.get('PauseSeconds',1)):.1f} с.")
                else: self.set_idle(True,"Success")
        elif self.state == "PulsePause" and now >= self.deadline:
            if self.power.output(True):
                self._next_power_probe = 0.0
                p=self.config.get("Pulse",{}); self.state="PulseOn"; self.status_text="Импульс"; self.deadline=now+float(p.get("OnSeconds",3)); self.logger.write(f"Источник включён импульсом на {float(p.get('OnSeconds',3)):.1f} с.")
            else: self.safe_stop("Не удалось включить источник для импульса.","Ошибка источника","Error",False)
        elif self.state == "PulseOn" and now >= self.deadline:
            self.power.output(False); self.logger.write("Импульс завершён. Источник отключен."); self.set_idle(True,"Success")
        if not self._busy and not self._power_probe_pending and now >= self._next_power_probe:
            self._power_probe_pending = True; self._submit(self._probe_power, self._power_probe_done)
        self.updated.emit()

    def close(self):
        self._closing = True
        self.rigol.suspended = True
        self.rigol.release_cancel.set()
        self.timer.stop(); self.stop_requested=True
        self.programmer.stop(); self.external.stop(); self.power.output(False); self.power.close(); self.rigol.close()
        self._executor.shutdown(wait=False, cancel_futures=True)
