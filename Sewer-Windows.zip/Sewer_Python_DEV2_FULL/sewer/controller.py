from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from PySide6 import QtCore

from .config import resolve_path, save_config
from .external_program import ExternalProgram
from .logger import SewerLogger
from .power_supply import OwonSPE3102
from .programmer import ProgrammerProcess
from .rigol import RigolRSA
from .rigol_live import RigolLive


class SewerController(QtCore.QObject):
    updated = QtCore.Signal()
    log_line = QtCore.Signal(str)
    _task_done = QtCore.Signal(object, object, object)

    def __init__(self, root: Path, config_path: Path, config: dict):
        super().__init__()
        self.root = root
        self.temp_dir = root / "Temp"; self.temp_dir.mkdir(exist_ok=True)
        self.config_path = config_path
        self.config = config
        self.state = "Idle"
        self.status_text = "Готов"
        self.deadline = 0.0
        self.stop_requested = False
        self.successful_boards = 0
        self.can_repeat = False
        self.ready = False
        self.readiness_reason = "Инициализация"
        self.started_at = time.monotonic()
        self.progress_state = "Idle"
        self._busy = False
        self._executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="Sewer")
        self._task_done.connect(self._dispatch_task_done)
        self.logger = SewerLogger(root, config, self.log_line.emit)
        self.power = OwonSPE3102(config["PowerSupply"])
        self.programmer = ProgrammerProcess(root, self.temp_dir, config["Programmer"], self.logger)
        self.external = ExternalProgram(root, config.get("ExternalProgram", {}))
        rc = config.get("Rigol", {})
        self.rigol = RigolRSA(str(rc.get("Resource", "")), int(rc.get("TimeoutMs", 2500)))
        self.rigol_live = RigolLive(self.rigol, rc.get("LiveIntervalMs", 300), self)
        self.rigol_connected = False
        self.rigol_mode = "GPSA"
        self.rigol_error = ""
        self._next_power_probe = 0.0
        self._next_rigol_probe = 0.0
        self._power_probe_pending = False
        self._rigol_probe_pending = False
        self.timer = QtCore.QTimer(self)
        self.timer.setInterval(int(config.get("Application", {}).get("UpdateIntervalMs", 500)))
        self.timer.timeout.connect(self.tick)
        self.timer.start()
        QtCore.QTimer.singleShot(50, self.tick)

    def set_logger_sink(self, sink):
        self.log_line.connect(sink)

    def apply_config(self, new_config: dict) -> None:
        old_rig = self.config.get("Rigol", {}).copy()
        self.safe_stop("Настройки изменены.", log=False)
        self.config = save_config(new_config, self.config_path)
        self.logger.reconfigure(self.config)
        self.power.reconfigure(self.config["PowerSupply"])
        self.programmer.reconfigure(self.config["Programmer"])
        self.external.reconfigure(self.config.get("ExternalProgram", {}))
        rc = self.config.get("Rigol", {})
        if old_rig != rc:
            self.rigol_live.invalidate()
            self.rigol.reconfigure(str(rc.get("Resource", "")), int(rc.get("TimeoutMs", 2500)))
            self.rigol_connected = False
        self.rigol_live.set_interval(rc.get("LiveIntervalMs", 300))
        self.timer.setInterval(int(self.config.get("Application", {}).get("UpdateIntervalMs", 500)))
        self._next_power_probe = self._next_rigol_probe = 0.0
        self.logger.write(f"Настройки сохранены: {self.config_path}")
        self.updated.emit()

    @QtCore.Slot(object, object, object)
    def _dispatch_task_done(self, done, result, error):
        done(result, error)

    def _submit(self, fn, done):
        future = self._executor.submit(fn)
        def finished(f):
            try:
                result = f.result(); error = None
            except Exception as e:
                result = None; error = e
            self._task_done.emit(done, result, error)
        future.add_done_callback(finished)

    def _probe_power(self):
        return self.power.probe()

    def _power_probe_done(self, result, error):
        self._power_probe_pending = False
        self._next_power_probe = time.monotonic() + 1.0
        if error:
            self.power.snapshot.responding = False
        self.update_readiness()
        self.updated.emit()

    def _probe_rigol(self):
        rc = self.config.get("Rigol", {})
        ok = self.rigol.identity_ok(str(rc.get("ExpectedManufacturer","RIGOL")), str(rc.get("ExpectedModel","RSA5065N")))
        mode = self.rigol.mode() if ok else "GPSA"
        return ok, mode, self.rigol.idn

    def _rigol_probe_done(self, result, error):
        self._rigol_probe_pending = False
        interval = int(self.config.get("Rigol", {}).get("MonitorIntervalMs", 2500)) / 1000
        self._next_rigol_probe = time.monotonic() + max(.5, interval)
        if error or not result:
            self.rigol_connected = False; self.rigol_error = str(error or "Нет ответа")
        else:
            self.rigol_connected, self.rigol_mode, _ = result
            self.rigol_error = ""
        self.updated.emit()

    def update_readiness(self) -> bool:
        reason = ""
        s = self.power.snapshot
        if not s.com_available: reason = "COM-порт не найден"
        elif not s.responding: reason = "Источник не отвечает"
        else:
            err = self.programmer.configuration_error()
            if err: reason = err.rstrip(".")
            else:
                ext_err = self.external.configuration_error()
                if ext_err: reason = ext_err.rstrip(".")
        new_ready = not reason
        changed = new_ready != self.ready or reason != self.readiness_reason
        self.ready, self.readiness_reason = new_ready, reason
        if changed and self.state == "Idle":
            self.logger.write("Стенд готов к работе." if new_ready else f"Стенд не готов: {reason}.")
        return new_ready

    def start_cycle(self) -> None:
        if self.state != "Idle" or self._busy:
            return
        if not self.update_readiness():
            self.logger.write(f"Запуск невозможен: {self.readiness_reason}.")
            return
        self.stop_requested = False
        self.can_repeat = False
        self.progress_state = "Preparing"
        self.status_text = "Проверка источника"
        self.state = "Preparing"
        self._busy = True
        self.logger.write("Старт.")
        self.updated.emit()

        def prepare():
            if not self.power.is_open and not self.power.connect():
                return False, ["Не удалось подключить источник."]
            if not self.power.snapshot.responding and not self.power.initialize():
                return False, ["Не удалось настроить источник."]
            ok, msgs = self.power.confirm_limits()
            return ok, msgs

        def prepared(result, error):
            self._busy = False
            if self.stop_requested:
                return
            if error or not result or not result[0]:
                self.safe_stop("Не удалось проверить или восстановить ограничения источника.", "Ошибка источника", "Error", False)
                return
            for msg in result[1]: self.logger.write(msg + ". Коррекция подтверждена.")
            if not self.power.output(True):
                self.safe_stop("Не удалось включить источник.", "Ошибка источника", "Error", False)
                return
            self.logger.write("Источник ON.")
            self.state = "PowerDelay"; self.status_text = "Подача питания"
            self.deadline = time.monotonic() + int(self.config["PowerSupply"].get("PowerOnDelayMs",1000))/1000
            self.updated.emit()
        self._submit(prepare, prepared)

    def _start_current_check(self):
        if self._busy: return
        self._busy = True; self.status_text = "Контроль тока"; self.updated.emit()
        cfg = self.config["PowerSupply"]
        def measure():
            return self.power.average_current(int(cfg.get("CurrentSamples",5)), int(cfg.get("SampleDelayMs",100)), lambda:self.stop_requested)
        def measured(avg, error):
            self._busy = False
            if self.stop_requested: return
            if error or avg is None:
                self.safe_stop("Не удалось измерить ток.", "Ошибка источника", "Error", False); return
            ma = avg * 1000
            if avg <= float(cfg.get("NoBoardCurrent",.001)):
                self.safe_stop(f"Плата не подключена ({ma:.1f} мА).", "Плата не подключена", "Error", False); return
            if avg > float(cfg.get("TripCurrent",.1)):
                self.safe_stop(f"Авария: превышение тока ({ma:.1f} мА).", "Превышение тока", "Error", False); return
            if avg < float(cfg.get("LowCurrent",.03)):
                self.logger.write(f"Предупреждение: низкий ток ({ma:.1f} мА).")
            elif avg > float(cfg.get("HighCurrent",.06)):
                self.logger.write(f"Предупреждение: повышенный ток ({ma:.1f} мА).")
            else:
                self.logger.write(f"Ток в норме ({ma:.1f} мА).")
            if self.programmer.start():
                self.state="Programming"; self.status_text="Прошивка"; self.progress_state="Running"; self.updated.emit()
            else:
                self.safe_stop("Не удалось запустить Programmer.", "Ошибка Programmer", "Error", False)
        self._submit(measure, measured)

    def _programmer_finished(self, code: int):
        self.programmer.complete_log(code)
        self.programmer.process = None
        if code == 0:
            self.programmer.progress = 100
            self.progress_state = "Success"
            self.successful_boards += 1
            self.logger.write("Прошивка завершена успешно.")
            if self.external.enabled():
                if self.external.start():
                    self.state="ExternalProgram"; self.status_text="Внешняя программа"
                    self.logger.write("Источник оставлен включённым до закрытия сторонней программы.")
                    self.updated.emit(); return
                self.safe_stop("Ошибка запуска сторонней программы.", "Ошибка программы", "Error", False); return
            if bool(self.config["PowerSupply"].get("AutoPowerOffAfterSuccess", True)):
                self.power.output(False); self.logger.write("Источник отключен автоматически.")
            else:
                self.logger.write("Источник оставлен включённым.")
            self.set_idle(True, "Success")
        else:
            self.power.output(False)
            self.progress_state="Error"
            self.logger.write(f"Programmer завершил работу с ошибкой, код {code}.")
            if self.programmer.last_error: self.logger.write(f"Programmer: {self.programmer.last_error}")
            if self.programmer.log_path: self.logger.write(f"Лог Programmer: {self.programmer.log_path}")
            self.set_idle(True, "Error")

    def set_idle(self, repeat=True, progress="Idle"):
        self.state="Idle"; self.status_text="Готов"; self.progress_state=progress; self.can_repeat=repeat
        self.stop_requested=False; self.deadline=0.0; self.update_readiness(); self.updated.emit()

    def safe_stop(self, reason: str, status="Готов", progress="Idle", repeat=True, log=True):
        self.stop_requested=True
        self.programmer.stop(); self.external.stop(); self.power.output(False)
        self.state="Idle"; self.status_text=status; self.progress_state=progress; self.can_repeat=repeat; self.deadline=0.0
        if log and reason: self.logger.write(reason)
        self.update_readiness(); self.updated.emit()

    def stop_cycle(self):
        if self.state != "Idle" or self._busy:
            self.safe_stop("Процесс остановлен оператором.", "Готов", "Idle", True)

    def switch_rigol_mode(self):
        if not self.rigol_connected: return
        target = "RTSA" if self.rigol_mode == "GPSA" else "GPSA"
        self.rigol_live.invalidate()
        try:
            self.rigol.set_mode(target); self.rigol_mode = target; self.logger.write(f"Rigol: режим {target}.")
        except Exception as e:
            self.rigol_connected=False; self.rigol_error=str(e)
        self.updated.emit()

    def tick(self):
        now = time.monotonic()
        if self.state == "Idle" and not self._power_probe_pending and now >= self._next_power_probe:
            self._power_probe_pending = True; self._submit(self._probe_power, self._power_probe_done)
        if not self._rigol_probe_pending and now >= self._next_rigol_probe:
            self._rigol_probe_pending = True; self._submit(self._probe_rigol, self._rigol_probe_done)
        if self.state == "PowerDelay" and now >= self.deadline:
            self.state = "CurrentCheck"; self._start_current_check()
        elif self.state == "Programming":
            code = self.programmer.poll()
            if code is not None:
                self._programmer_finished(code)
        elif self.state == "ExternalProgram":
            if self.external.process is None:
                self.safe_stop("Процесс сторонней программы потерян.", "Ошибка программы", "Error", False)
            elif self.external.poll() is not None:
                self.external.process = None
                self.power.output(False); self.logger.write("Сторонняя программа закрыта. Источник отключен.")
                p = self.config.get("Pulse", {})
                if p.get("Enabled", False):
                    self.state="PulsePause"; self.status_text="Пауза"; self.deadline=now+float(p.get("PauseSeconds",1)); self.logger.write(f"Импульс: пауза {float(p.get('PauseSeconds',1)):.1f} с.")
                else: self.set_idle(True,"Success")
        elif self.state == "PulsePause" and now >= self.deadline:
            if self.power.output(True):
                p=self.config.get("Pulse",{}); self.state="PulseOn"; self.status_text="Импульс"; self.deadline=now+float(p.get("OnSeconds",3)); self.logger.write(f"Источник включён импульсом на {float(p.get('OnSeconds',3)):.1f} с.")
            else: self.safe_stop("Не удалось включить источник для импульса.","Ошибка источника","Error",False)
        elif self.state == "PulseOn" and now >= self.deadline:
            self.power.output(False); self.logger.write("Импульс завершён. Источник отключен."); self.set_idle(True,"Success")
        self.updated.emit()

    def close(self):
        self.rigol_live.close()
        self.timer.stop(); self.stop_requested=True
        self.programmer.stop(); self.external.stop(); self.power.output(False); self.power.close(); self.rigol.close()
        self._executor.shutdown(wait=False, cancel_futures=True)
