from __future__ import annotations

import os
import re
import subprocess
from datetime import datetime
from pathlib import Path

from .config import resolve_path
from .logger import SewerLogger

_PERCENT_RE = re.compile(r"(?<!\d)(100|[1-9]?\d)\s*%")


class ProgrammerProcess:
    def __init__(self, root: Path, temp_dir: Path, config: dict, logger: SewerLogger):
        self.root = root
        self.temp_dir = temp_dir
        self.config = config
        self.logger = logger
        self.process: subprocess.Popen | None = None
        self.log_path: Path | None = None
        self.stdout_path: Path | None = None
        self.stderr_path: Path | None = None
        self.progress = 0
        self.last_error = ""
        self._out_handle = None
        self._err_handle = None

    def reconfigure(self, config: dict) -> None:
        self.config = config

    def paths(self) -> tuple[Path, Path, str]:
        exe = resolve_path(str(self.config.get("ExecutablePath", "")), self.root)
        fw = resolve_path(str(self.config.get("FirmwarePath", "")), self.root)
        args = str(self.config.get("Arguments", "")).replace("{FW}", str(fw))
        return exe, fw, args

    def configuration_error(self) -> str | None:
        exe, fw, _ = self.paths()
        if not exe.is_file():
            return "Programmer не найден."
        if not fw.is_file():
            return "Прошивка не найдена."
        return None

    def start(self) -> bool:
        if self.process and self.process.poll() is None:
            return False
        error = self.configuration_error()
        if error:
            self.logger.write(error)
            return False
        exe, fw, args = self.paths()
        self.log_path, self.stdout_path, self.stderr_path = self.logger.programmer_paths(self.temp_dir)
        self.progress = 0
        self.last_error = ""
        self.log_path.write_text(
            "\n".join([
                "=== Programmer diagnostic log ===",
                f"Дата запуска: {datetime.now():%Y-%m-%d %H:%M:%S.%f}",
                f"Исполняемый файл: {exe}",
                f"Рабочая папка: {exe.parent}",
                f"Аргументы после подстановки: {args}",
                f'Команда: "{exe}" {args}',
                "Состояние: подготовка к запуску",
                "",
            ]),
            encoding="utf-8-sig",
        )
        self._out_handle = self.stdout_path.open("wb")
        self._err_handle = self.stderr_path.open("wb")
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            command = f'"{exe}" {args}'
            self.process = subprocess.Popen(
                command,
                cwd=str(exe.parent),
                stdout=self._out_handle,
                stderr=self._err_handle,
                shell=False,
                creationflags=creationflags,
            )
            with self.log_path.open("a", encoding="utf-8-sig") as f:
                f.write(f"Состояние: процесс запущен, PID={self.process.pid}\n")
            self.logger.write("Programmer запущен.")
            return True
        except Exception as e:
            self._close_handles()
            self.process = None
            self.last_error = str(e)
            self.logger.write(f"Ошибка запуска Programmer: {e}")
            return False

    def _read_text(self, path: Path | None) -> str:
        if not path or not path.exists():
            return ""
        try:
            return path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            return ""

    def update_progress(self) -> int:
        combined = self._read_text(self.stdout_path) + "\n" + self._read_text(self.stderr_path)
        matches = _PERCENT_RE.findall(combined)
        if matches:
            self.progress = max(self.progress, min(100, max(0, int(matches[-1]))))
        return self.progress

    def poll(self) -> int | None:
        if not self.process:
            return None
        self.update_progress()
        return self.process.poll()

    def complete_log(self, exit_code: int) -> None:
        self._close_handles()
        stdout = self._read_text(self.stdout_path)
        stderr = self._read_text(self.stderr_path)
        source = stderr.strip() or stdout.strip()
        self.last_error = source.splitlines()[0] if source else ""
        if self.log_path:
            try:
                with self.log_path.open("a", encoding="utf-8-sig") as f:
                    f.write("\n=== Результат ===\n")
                    f.write(f"Дата завершения: {datetime.now():%Y-%m-%d %H:%M:%S.%f}\n")
                    f.write(f"Код завершения: {exit_code}\n\n=== STDOUT ===\n")
                    f.write(stdout or "(пусто)")
                    f.write("\n\n=== STDERR ===\n")
                    f.write(stderr or "(пусто)")
            except OSError:
                pass
        for p in (self.stdout_path, self.stderr_path):
            if p:
                p.unlink(missing_ok=True)

    def _close_handles(self) -> None:
        for h in (self._out_handle, self._err_handle):
            try:
                if h:
                    h.close()
            except Exception:
                pass
        self._out_handle = None
        self._err_handle = None

    def stop(self) -> None:
        if not self.process:
            return
        try:
            if self.process.poll() is None:
                if os.name == "nt":
                    subprocess.run(
                        ["taskkill", "/PID", str(self.process.pid), "/T", "/F"],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                        timeout=3,
                    )
                else:
                    self.process.kill()
        except Exception:
            pass
        finally:
            self._close_handles()
            self.process = None
