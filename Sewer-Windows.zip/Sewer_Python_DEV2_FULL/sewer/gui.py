from __future__ import annotations

import time
from pathlib import Path

from PySide6 import QtCore, QtGui, QtWidgets
import pyqtgraph as pg

from .config import clone_config, save_config
from .themes import (theme_from_config, normalize_theme, set_current_theme, theme_color, mapped_color,
                     action_text, set_theme_style, apply_widget_theme, ThemeHeader, draw_card_decoration)
from .controller import SewerController
from .rigol_live import RigolLive
from .rigol_marker_panel import MarkerPanel
from .rigol_diagnostic import save_diagnostic
from .number_input import NumberInput
from .settings import SettingsPage
from .runtime import asset_path

BW = [
    ("1 Hz",1),("3 Hz",3),("10 Hz",10),("30 Hz",30),("100 Hz",100),("300 Hz",300),
    ("1 kHz",1e3),("3 kHz",3e3),("10 kHz",1e4),("30 kHz",3e4),("100 kHz",1e5),
    ("300 kHz",3e5),("1 MHz",1e6),("3 MHz",3e6),("10 MHz",1e7),
]


class ReverseWheelCombo(QtWidgets.QComboBox):
    def wheelEvent(self, event):
        if not self.isEnabled() or self.count() == 0:
            event.ignore(); return
        delta = event.angleDelta().y()
        if delta == 0:
            event.ignore(); return
        step = 1 if delta > 0 else -1
        self.setCurrentIndex(max(0, min(self.count()-1, self.currentIndex()+step)))
        event.accept()


class StatusBadge(QtWidgets.QFrame):
    TITLES = {"COM": "Источник питания", "FW": "Файл прошивки", "PRG": "Программатор", "RIG": "Rigol"}

    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.kind = title
        self.ok = None
        self.setFixedSize(46, 46)
        self.setAccessibleName(self.TITLES[title])

    def set_status(self, text: str, ok: bool | None):
        self.ok = ok
        state = "Готов" if ok else "Не готов"
        self.setToolTip(f"{self.TITLES[self.kind]}: {state} · {text}")
        self.setAccessibleDescription(self.toolTip())
        self.update()

    def paintEvent(self, event):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        p.scale(self.width()/46, self.height()/46)
        color = theme_color("#d3e1ef" if getattr(self,"monochrome",False) else "#73cfa6" if self.ok else "#eb8585")
        p.setPen(QtGui.QPen(theme_color("#343d46"), 1))
        p.setBrush(theme_color("#232b33"))
        if not getattr(self,"monochrome",False): p.drawRoundedRect(QtCore.QRectF(0.5, 0.5, 45, 45), 4, 4)
        p.setPen(QtGui.QPen(color, 1.7))
        p.setBrush(QtCore.Qt.NoBrush)
        if self.kind == "COM":
            p.drawRoundedRect(QtCore.QRectF(15, 16, 16, 12), 3, 3)
            p.drawLine(19, 11, 19, 16); p.drawLine(27, 11, 27, 16)
            p.drawLine(23, 28, 23, 35)
        elif self.kind == "FW":
            p.drawRoundedRect(QtCore.QRectF(16, 11, 15, 23), 2, 2)
            p.drawLine(20, 19, 27, 19); p.drawLine(20, 24, 27, 24)
            p.drawLine(20, 29, 25, 29)
        elif self.kind == "PRG":
            p.drawRoundedRect(QtCore.QRectF(15, 15, 16, 16), 2, 2)
            for n in (18, 23, 28):
                p.drawLine(n, 11, n, 15); p.drawLine(n, 31, n, 35)
                p.drawLine(11, n, 15, n); p.drawLine(31, n, 35, n)
        else:
            p.drawLine(12, 33, 34, 33)
            path = QtGui.QPainterPath(QtCore.QPointF(12, 28))
            for x, y in ((17,28),(21,14),(25,29),(29,23),(34,28)):
                path.lineTo(x, y)
            p.drawPath(path)
        p.end()


class ActionButton(QtWidgets.QPushButton):
    def __init__(self, label, shortcut, symbol, parent=None):
        super().__init__(parent)
        self.label, self.shortcut, self.symbol = label, shortcut, symbol
        self.setAccessibleName(f"{label}, {shortcut}")
        self.setToolTip(f"{label} · {shortcut}")
        self.setMinimumSize(205, 42)
        self.setCursor(QtCore.Qt.PointingHandCursor)

    def paintEvent(self, event):
        super().paintEvent(event)
        p = QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing)
        enabled = self.isEnabled()
        color = action_text(self.objectName()=="StartButton", enabled)
        p.setPen(QtGui.QPen(color, 2.4)); p.setBrush(QtCore.Qt.NoBrush)
        cy = self.height()/2
        if self.symbol == "▶":
            p.setPen(QtCore.Qt.NoPen); p.setBrush(color)
            p.drawPolygon(QtGui.QPolygonF([QtCore.QPointF(19,cy-10),QtCore.QPointF(19,cy+10),QtCore.QPointF(34,cy)]))
        elif self.symbol == "■":
            p.setPen(QtCore.Qt.NoPen); p.setBrush(theme_color("#f27979" if enabled else "#926a70"))
            p.drawRoundedRect(QtCore.QRectF(17,cy-10,20,20),2,2)
        elif self.symbol == "↻":
            p.drawArc(QtCore.QRectF(17,cy-11,22,22),40*16,285*16)
            p.drawLine(QtCore.QPointF(37,cy-12),QtCore.QPointF(37,cy-3))
            p.drawLine(QtCore.QPointF(37,cy-3),QtCore.QPointF(28,cy-3))
        else:
            p.drawLine(QtCore.QPointF(17,cy-11),QtCore.QPointF(17,cy+11))
            p.drawLine(QtCore.QPointF(17,cy-11),QtCore.QPointF(27,cy-11))
            p.drawLine(QtCore.QPointF(17,cy+11),QtCore.QPointF(27,cy+11))
            p.drawLine(QtCore.QPointF(24,cy),QtCore.QPointF(40,cy))
            p.drawLine(QtCore.QPointF(34,cy-6),QtCore.QPointF(40,cy))
            p.drawLine(QtCore.QPointF(34,cy+6),QtCore.QPointF(40,cy))
        p.setPen(color)
        font=self.font(); font.setPixelSize(17); font.setBold(True); p.setFont(font)
        p.drawText(QtCore.QRect(50,0,self.width()-108,self.height()),QtCore.Qt.AlignVCenter,self.label)
        font.setPixelSize(11); font.setBold(False); p.setFont(font)
        p.setPen(action_text(self.objectName()=="StartButton", enabled, shortcut=True))
        p.drawText(QtCore.QRect(self.width()-58,0,48,self.height()),QtCore.Qt.AlignRight|QtCore.Qt.AlignVCenter,self.shortcut)
        p.end()


class PanelIcon(StatusBadge):
    def __init__(self, kind, parent=None):
        super().__init__(kind,parent)
        self.ok=True
        self.monochrome=True
        set_theme_style(self, "background:transparent;border:none;")
        self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents)


class InstrumentIconButton(QtWidgets.QPushButton):
    def __init__(self, kind, parent=None):
        super().__init__(parent)
        self.kind = kind
        self.active = False
        self.setFixedSize(40, 32)
        self.setCursor(QtCore.Qt.PointingHandCursor)

    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.translate((self.width() - 24) / 2, (self.height() - 24) / 2)
        color = theme_color("#73cfa6") if self.active else action_text(False, self.isEnabled())
        pen = QtGui.QPen(color, 1.8, QtCore.Qt.SolidLine, QtCore.Qt.RoundCap, QtCore.Qt.RoundJoin)
        painter.setPen(pen)
        painter.setBrush(QtCore.Qt.NoBrush)
        if self.kind == "power":
            painter.drawArc(QtCore.QRectF(4.5, 5, 15, 15), 130 * 16, 280 * 16)
            painter.drawLine(QtCore.QPointF(12, 2.8), QtCore.QPointF(12, 10))
        else:
            outline = QtGui.QPainterPath(QtCore.QPointF(3, 8))
            for x, y in ((7, 8), (9, 5), (15, 5), (17, 8), (21, 8), (21, 20), (3, 20)):
                outline.lineTo(x, y)
            outline.closeSubpath()
            painter.drawPath(outline)
            painter.drawEllipse(QtCore.QRectF(8.5, 10, 7, 7))
        painter.end()


class MetricCard(QtWidgets.QFrame):
    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.setObjectName("InstrumentCard")
        self.setFixedHeight(158)
        self.grid=QtWidgets.QGridLayout(self)
        self.grid.setContentsMargins(12,12,12,12); self.grid.setSpacing(8)
        self.grid.setColumnStretch(0,1); self.grid.setColumnStretch(1,1)
        header_widget=QtWidgets.QWidget(); set_theme_style(header_widget, "background:transparent;"); header_widget.setFixedHeight(46)
        header=QtWidgets.QHBoxLayout(header_widget); header.setContentsMargins(0,0,0,0); header.setSpacing(9)
        kind={"Источник питания":"COM","Состояние выхода":"RIG","Программатор":"PRG","Rigol":"RIG"}[title]
        header.addWidget(PanelIcon(kind))
        labels=QtWidgets.QVBoxLayout(); labels.setSpacing(3)
        heading=QtWidgets.QLabel(title); heading._theme_heading=True; set_theme_style(heading, "font-size:18px;font-weight:700;color:#e9f1f8;")
        self.status=QtWidgets.QLabel("—")
        labels.addWidget(heading); labels.addWidget(self.status); header.addLayout(labels,1)
        self.grid.addWidget(header_widget,0,0,1,2)
        self.rows={}
        self.is_measurement=title in ("Источник питания","Состояние выхода")

    def paintEvent(self, event):
        super().paintEvent(event)
        draw_card_decoration(self)

    def add_metric(self, row: int, label: str):
        if self.is_measurement:
            cell=QtWidgets.QFrame(); cell.setObjectName("MeasurementCell")
            layout=QtWidgets.QVBoxLayout(cell); layout.setContentsMargins(10,8,8,8); layout.setSpacing(5)
            caption=QtWidgets.QLabel(label); set_theme_style(caption, "color:#afbdcb;font-size:12px;")
            value=QtWidgets.QLabel("—"); value.setAlignment(QtCore.Qt.AlignLeft|QtCore.Qt.AlignVCenter)
            set_theme_style(value, "font-family:Consolas;font-size:34px;font-weight:700;color:#f3f7fc;")
            layout.addWidget(caption); layout.addWidget(value,1)
            self.grid.addWidget(cell,1,row-1,2,1)
        else:
            caption=QtWidgets.QLabel(label); set_theme_style(caption, "color:#afbdcb;font-size:14px;")
            value=QtWidgets.QLabel("—"); value.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignVCenter)
            set_theme_style(value, "font-family:Consolas;font-size:22px;font-weight:600;color:#eef4f7;")
            self.grid.addWidget(caption,row,0); self.grid.addWidget(value,row,1)
        self.rows[label]=value
        return value

    def set_status(self, text: str, ok: bool | None):
        self.status.setText("●  "+text)
        color="#73cfa6" if ok is True else "#eb8585" if ok is False else "#d9bb79"
        set_theme_style(self.status, f"font-size:13px;font-weight:600;color:{color};")


class RigolControlDialog(QtWidgets.QDialog):
    def __init__(self, controller: SewerController, parent=None):
        super().__init__(parent)
        self.controller=controller; self.rigol=controller.rigol
        self.setWindowTitle("Rigol — управление")
        self.resize(1260,780)
        self.setModal(False)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        self.live_reader=RigolLive(self.rigol, controller.config.get("Rigol",{}).get("LiveIntervalMs",300), self)
        self.live_timer=self.live_reader.timer
        self._plot_axis=("Frequency", "MHz", "dBm")
        self._plot_range=None
        self._choose_visible_trace=True
        self._build()
        self.apply_plot_theme()
        self.live_reader.changed.connect(self._live_state)
        self.live_reader.frame_ready.connect(self._show_live_frame)
        self.controller.rigol_access_changed.connect(self._access_changed)
        self.controller.updated.connect(self._connection_status)
        self._live_state()

    def apply_plot_theme(self):
        self.plot.setBackground(mapped_color("#171d23"))
        self.curve.setPen(pg.mkPen(mapped_color("#399ce8"),width=1.5))
        for side in ("bottom","left"):
            axis=self.plot.getAxis(side); axis.setPen(theme_color("#afbdcb")); axis.setTextPen(theme_color("#afbdcb"))
            axis.enableAutoSIPrefix(False)
        label,x_unit,y_unit=self._plot_axis
        self.plot.setLabel("bottom",label,x_unit,color=mapped_color("#afbdcb"))
        self.plot.setLabel("left","Level",y_unit,color=mapped_color("#afbdcb"))
        if hasattr(self,"markers"):
            self.markers.show_snapshot(self.markers.reader.snapshot)

    def _build(self):
        root=QtWidgets.QVBoxLayout(self)
        top=QtWidgets.QHBoxLayout(); root.addLayout(top)
        self.resource=QtWidgets.QLineEdit(self.controller.config.get("Rigol",{}).get("Resource","")); top.addWidget(self.resource,1)
        self.connect_btn=QtWidgets.QPushButton("Подключить"); self.connect_btn.clicked.connect(self.connect_rigol); top.addWidget(self.connect_btn)
        self.mode=QtWidgets.QComboBox(); self.mode.addItems(["GPSA","RTSA"]); top.addWidget(self.mode)
        self.mode_btn=QtWidgets.QPushButton("Режим"); self.mode_btn.clicked.connect(self.apply_mode); top.addWidget(self.mode_btn)
        self.status=QtWidgets.QLabel("Не подключен"); top.addWidget(self.status)
        self.status.setMaximumWidth(320)
        self.status.setWordWrap(True)
        self.status.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)

        body=QtWidgets.QHBoxLayout(); root.addLayout(body,1)
        self.control_tabs=QtWidgets.QTabWidget()
        self.control_tabs.setMinimumWidth(390)
        self.control_tabs.setMaximumWidth(430)
        body.addWidget(self.control_tabs,0)
        scroll=QtWidgets.QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        controls=QtWidgets.QWidget(); left=QtWidgets.QVBoxLayout(controls)
        left.setContentsMargins(6,6,6,6)
        scroll.setWidget(controls)
        self.control_tabs.addTab(scroll,"Параметры")

        self.center=self._dspin(0,6500,1,6,"MHz")
        self.span=self._dspin(0,6500,1,6,"MHz")
        left.addWidget(self._group("Frequency",[("Center",self.center,self.apply_center),("Span",self.span,self.apply_span)]))

        self.ref=self._dspin(-99,99,1,1," dBm")
        self.off=self._dspin(-300,300,1,1," dB")
        self.scale=QtWidgets.QSpinBox(); self.scale.setButtonSymbols(QtWidgets.QAbstractSpinBox.NoButtons); self.scale.setRange(1,20); self.scale.setSingleStep(1); self.scale.unit="dB/div"; self.scale.setKeyboardTracking(False)
        self.att=self._dspin(0,70,1,0," dB")
        left.addWidget(self._group("Amplitude",[("Ref Level",self.ref,self.apply_ref),("Ref Offset",self.off,self.apply_off),("Scale/Div",self.scale,self.apply_scale),("Attenuation",self.att,self.apply_att)]))

        gbw=QtWidgets.QGroupBox("BW"); gl=QtWidgets.QGridLayout(gbw)
        self.rbw=ReverseWheelCombo(); self.vbw=ReverseWheelCombo()
        for n,v in BW: self.rbw.addItem(n,v); self.vbw.addItem(n,v)
        self.rbwa=QtWidgets.QCheckBox("Auto"); self.vbwa=QtWidgets.QCheckBox("Auto")
        gl.addWidget(QtWidgets.QLabel("RBW"),0,0); gl.addWidget(self.rbw,0,1); gl.addWidget(self.rbwa,0,2)
        gl.addWidget(QtWidgets.QLabel("VBW"),1,0); gl.addWidget(self.vbw,1,1); gl.addWidget(self.vbwa,1,2)
        br=QtWidgets.QPushButton("Применить BW"); br.clicked.connect(self.apply_bw); gl.addWidget(br,2,0,1,3)
        left.addWidget(gbw)

        gs=QtWidgets.QGroupBox("Sweep"); sl=QtWidgets.QGridLayout(gs)
        self.sweept=self._dspin(1,4000000,1,0," ms"); self.sweepa=QtWidgets.QCheckBox("Auto")
        self.points=QtWidgets.QSpinBox(); self.points.setButtonSymbols(QtWidgets.QAbstractSpinBox.NoButtons); self.points.setRange(101,10001); self.points.setSingleStep(1); self.points.setKeyboardTracking(False)
        bc=QtWidgets.QPushButton("Continuous"); bc.clicked.connect(lambda:self._safe(lambda:self.rigol.continuous(True)))
        bs=QtWidgets.QPushButton("Single"); bs.clicked.connect(lambda:self._safe(self.rigol.single))
        sl.addWidget(bc,0,0); sl.addWidget(bs,0,1)
        sl.addWidget(QtWidgets.QLabel("Sweep Time"),1,0); sl.addWidget(self._with_unit(self.sweept),1,1); sl.addWidget(self.sweepa,1,2)
        sl.addWidget(QtWidgets.QLabel("Points"),2,0); sl.addWidget(self.points,2,1)
        ba=QtWidgets.QPushButton("Применить Sweep"); ba.clicked.connect(self.apply_sweep); sl.addWidget(ba,3,0,1,3)
        left.addWidget(gs)
        self._watch_numeric(self.sweept,self.apply_sweep)
        self._watch_numeric(self.points,self.apply_sweep)

        gt=QtWidgets.QGroupBox("Trace"); tl=QtWidgets.QGridLayout(gt)
        self.tr=QtWidgets.QComboBox(); self.tr.addItems([str(i) for i in range(1,7)])
        self.tr.currentIndexChanged.connect(lambda index:self.live_reader.set_trace(index+1))
        self.tr.currentIndexChanged.connect(self.refresh_trace_metadata)
        tl.addWidget(QtWidgets.QLabel("Trace"),0,0); tl.addWidget(self.tr,0,1)
        for i,(txt,typ) in enumerate([("Clear/Write","WRITe"),("Max Hold","MAXHold"),("Average","AVERage"),("Min Hold","MINHold")]):
            b=QtWidgets.QPushButton(txt); b.clicked.connect(lambda _,t=typ:self.set_trace(t)); tl.addWidget(b,1+i//2,i%2)
        self.live=QtWidgets.QCheckBox(f"Live {self.live_timer.interval()} ms")
        self.live.setChecked(True)
        self.live.toggled.connect(self.live_reader.set_enabled)
        self.live_refresh=QtWidgets.QPushButton("Обновить")
        self.live_refresh.clicked.connect(self.refresh_live)
        self.trace_display=QtWidgets.QCheckBox("Display")
        self.trace_update=QtWidgets.QCheckBox("Update")
        self.trace_display.setToolTip("Видимость выбранной трассы на Rigol")
        self.trace_update.setToolTip("Обновление выбранной трассы на Rigol")
        self.trace_display.clicked.connect(lambda on:self.set_trace_flag("display",on))
        self.trace_update.clicked.connect(lambda on:self.set_trace_flag("update",on))
        tl.addWidget(self.trace_display,3,0); tl.addWidget(self.trace_update,3,1)
        tl.addWidget(self.live,4,0); tl.addWidget(self.live_refresh,4,1); left.addWidget(gt); left.addStretch()

        graph=QtWidgets.QVBoxLayout(); body.addLayout(graph,1)
        graph_tools=QtWidgets.QHBoxLayout(); graph.addLayout(graph_tools)
        self.auto_y=QtWidgets.QCheckBox("Автомасштаб Y")
        self.auto_y.setChecked(True)
        self.auto_y.setToolTip("Выключено: шкала Ref Level / Scale/Div прибора для dBm, LOG. Включено: масштаб по данным.")
        self.auto_y.toggled.connect(self._rescale_live)
        graph_tools.addWidget(self.auto_y); graph_tools.addStretch()
        self.diagnostic_save=QtWidgets.QPushButton("Сохранить диагностику…")
        self.diagnostic_save.setToolTip("Сохранить последний ответ Rigol, параметры и снимок окна в ZIP")
        self.diagnostic_save.clicked.connect(self.export_diagnostic)
        graph_tools.addWidget(self.diagnostic_save)
        self.plot=pg.PlotWidget(); graph.addWidget(self.plot,1)
        self.curve=self.plot.plot(); self.plot.showGrid(x=True,y=True)
        self.plot.setLabel("bottom","Frequency","MHz"); self.plot.setLabel("left","Level","dBm")
        self.markers=MarkerPanel(self)
        marker_scroll=QtWidgets.QScrollArea(); marker_scroll.setWidgetResizable(True)
        marker_scroll.setWidget(self.markers)
        self.control_tabs.addTab(marker_scroll,"Маркеры")
        self.show_markers=QtWidgets.QCheckBox("Маркеры")
        self.show_markers.setChecked(True)
        self.show_markers.setToolTip("Показывать и опрашивать маркеры Rigol; сам прибор этот флажок не изменяет")
        self.show_markers.toggled.connect(self.markers.reader.set_enabled)
        self.show_markers.toggled.connect(self.markers.table.setVisible)
        graph_tools.insertWidget(1,self.show_markers)
        marker_read=QtWidgets.QPushButton("Прочитать маркеры")
        marker_read.clicked.connect(lambda:self.markers.reader.refresh(force=True))
        self.show_markers.toggled.connect(marker_read.setEnabled)
        graph_tools.insertWidget(2,marker_read)
        graph.addWidget(self.markers.table)
        graph.addWidget(self.markers.status)
        self.live.toggled.connect(lambda on:setattr(self.markers.reader,"live",on))
        self.live_status=QtWidgets.QLabel()
        self.live_status.setWordWrap(True)
        graph.addWidget(self.live_status)
        self.diagnostic_status=QtWidgets.QLabel()
        self.diagnostic_status.setWordWrap(True)
        self.diagnostic_status.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        graph.addWidget(self.diagnostic_status)
        for button in self.findChildren(QtWidgets.QPushButton):
            button.setAutoDefault(False)
            button.setDefault(False)

    def _dspin(self,a,b,step,dec,unit):
        x=NumberInput(); x.setDecimals(dec); x.setRange(a,b); x.setSingleStep(step); x.unit=unit.strip(); return x

    def _with_unit(self, editor):
        row=QtWidgets.QWidget()
        row.setObjectName("NumericUnitRow")
        set_theme_style(row,"QWidget#NumericUnitRow{background:transparent;}")
        layout=QtWidgets.QHBoxLayout(row); layout.setContentsMargins(0,0,0,0); layout.setSpacing(6)
        layout.addWidget(editor,1)
        editor.unit_label=QtWidgets.QLabel(editor.unit)
        editor.unit_label.setMinimumWidth(42)
        layout.addWidget(editor.unit_label)
        return row

    def _watch_numeric(self, editor, apply):
        editor._user_edited=False
        editor._readback=editor.value()
        editor.lineEdit().textEdited.connect(lambda _:setattr(editor,"_user_edited",True))
        editor.valueChanged.connect(lambda _:setattr(editor,"_user_edited",True))
        editor.editingFinished.connect(lambda:self._apply_if_edited(editor,apply))

    def _apply_if_edited(self, editor, apply):
        if editor._user_edited and editor.hasAcceptableInput() and editor.value()!=editor._readback:
            apply()
        elif editor.value()==editor._readback:
            editor._user_edited=False

    def _load_numeric(self, editor, value):
        blocker=QtCore.QSignalBlocker(editor)
        editor.setValue(int(round(value)) if isinstance(editor,QtWidgets.QSpinBox) else value)
        editor._readback=editor.value()
        editor._user_edited=False
        editor.lineEdit().setModified(False)
        del blocker

    def _apply_numeric(self, editor, setter, getter, factor=1):
        def f():
            editor.interpretText()
            setter(editor.value()*factor)
            self._load_numeric(editor,getter()/factor)
        self._safe(f)

    def _group(self,title,rows):
        g=QtWidgets.QGroupBox(title); l=QtWidgets.QGridLayout(g)
        for r,(name,w,fn) in enumerate(rows):
            l.addWidget(QtWidgets.QLabel(name),r,0); l.addWidget(self._with_unit(w),r,1)
            self._watch_numeric(w,fn)
            b=QtWidgets.QPushButton("Set"); b.clicked.connect(lambda checked=False,w=w,fn=fn:self._apply_if_edited(w,fn)); l.addWidget(b,r,2)
        return g

    def _safe(self, fn):
        if self.rigol.suspended or self.controller._rigol_connection_pending:
            self.status.setText("Управление приостановлено. Подключение: Alt+Ctrl+C.")
            return
        self.live_reader.invalidate()
        try: fn(); self.status.setText("OK"); self.live_reader.refresh()
        except Exception as e:
            self.status.setText(str(e))
            if not self.rigol.connected:
                self.controller.rigol_connected=False
                self.controller.rigol_error=str(e)
                self.controller.logger.write("Rigol: "+str(e))
                self.controller.updated.emit()

    def connect_rigol(self):
        self._choose_visible_trace=True
        self.controller.connect_rigol(self.resource.text().strip())

    def _connection_status(self):
        paused = self.rigol.suspended or self.controller._rigol_connection_pending
        self.connect_btn.setEnabled(not self.controller._rigol_action_pending and not self.controller.screenshot_busy)
        self.control_tabs.setEnabled(not paused)
        self.mode.setEnabled(not paused)
        self.mode_btn.setEnabled(not paused)
        self.live_refresh.setEnabled(not paused)
        self.show_markers.setEnabled(not paused)
        if paused:
            self.status.setText(self.controller.rigol_error or "Опрос остановлен · Alt+Ctrl+C — подключить")

    def _access_changed(self, enabled):
        self.live_reader.set_active(False)
        self.live_reader.invalidate()
        self.markers.reader.set_active(False)
        self.markers.reader.invalidate()
        self._connection_status()
        if enabled and self.isVisible():
            if self.rigol.connected:
                try:
                    self.refresh_all()
                except Exception as exc:
                    self.status.setText(str(exc))
            self.live_reader.set_active(True)
            self.markers.reader.set_active(True)

    def refresh_all(self):
        self.status.setText(self.rigol.idn or "Подключен")
        self.mode.setCurrentText(self.rigol.mode())
        self._load_numeric(self.center,self.rigol.center_hz()/1e6); self._load_numeric(self.span,self.rigol.span_hz()/1e6)
        self._load_numeric(self.ref,self.rigol.ref_level()); self._load_numeric(self.off,self.rigol.ref_offset())
        self._load_numeric(self.scale,self.rigol.scale_div()); self._load_numeric(self.att,self.rigol.attenuation())
        self._load_numeric(self.sweept,self.rigol.sweep_time()*1000); self._load_numeric(self.points,self.rigol.sweep_points())
        for combo,val in ((self.rbw,self.rigol.rbw()),(self.vbw,self.rigol.vbw())):
            idx=min(range(combo.count()), key=lambda i:abs(combo.itemData(i)-val)); combo.setCurrentIndex(idx)
        self.rbwa.setChecked(self.rigol.query_bool(":SENSe:BANDwidth:RESolution:AUTO?"))
        self.vbwa.setChecked(self.rigol.query_bool(":SENSe:BANDwidth:VIDeo:AUTO?"))
        self.sweepa.setChecked(self.rigol.query_bool(":SENSe:SWEep:TIME:AUTO?"))
        if self._choose_visible_trace:
            visible=self.rigol.visible_traces()
            if visible and int(self.tr.currentText()) not in visible:
                self.tr.setCurrentIndex(visible[0]-1)
            self._choose_visible_trace=False
        self.refresh_trace_metadata()
        try:
            self.rigol.query(":DISPlay:WINDow:TRACe:Y:SCALe:SPACing?")
        except Exception as exc:
            self.status.setText("Шкала не прочитана: "+str(exc))

    def refresh_trace_metadata(self):
        if not self.rigol.connected:
            return
        n=int(self.tr.currentText())
        try:
            self.rigol.trace_type(n)
            for widget,value in ((self.trace_display,self.rigol.trace_display(n)),(self.trace_update,self.rigol.trace_update(n))):
                with QtCore.QSignalBlocker(widget):
                    widget.setChecked(value)
        except Exception as exc:
            self.status.setText("Состояние Trace не прочитано: "+str(exc))

    def apply_mode(self):
        def f():
            self.rigol.set_mode(self.mode.currentText())
            self.controller.rigol_mode=self.mode.currentText()
            self.controller.updated.emit()
        self._safe(f)
    def apply_center(self): self._apply_numeric(self.center,self.rigol.set_center_hz,self.rigol.center_hz,1e6)
    def apply_span(self): self._apply_numeric(self.span,self.rigol.set_span_hz,self.rigol.span_hz,1e6)
    def apply_ref(self): self._apply_numeric(self.ref,self.rigol.set_ref_level,self.rigol.ref_level)
    def apply_off(self): self._apply_numeric(self.off,self.rigol.set_ref_offset,self.rigol.ref_offset)
    def apply_scale(self): self._apply_numeric(self.scale,self.rigol.set_scale_div,self.rigol.scale_div)
    def apply_att(self): self._apply_numeric(self.att,self.rigol.set_attenuation,self.rigol.attenuation)
    def apply_bw(self):
        def f():
            self.rigol.set_rbw_auto(self.rbwa.isChecked()); self.rigol.set_vbw_auto(self.vbwa.isChecked())
            if not self.rbwa.isChecked(): self.rigol.set_rbw(self.rbw.currentData())
            if not self.vbwa.isChecked(): self.rigol.set_vbw(self.vbw.currentData())
        self._safe(f)
    def apply_sweep(self):
        def f():
            self.sweept.interpretText(); self.points.interpretText()
            self.rigol.set_sweep_time_auto(self.sweepa.isChecked())
            if not self.sweepa.isChecked(): self.rigol.set_sweep_time(self.sweept.value()/1000)
            self.rigol.set_sweep_points(self.points.value())
            self._load_numeric(self.sweept,self.rigol.sweep_time()*1000)
            self._load_numeric(self.points,self.rigol.sweep_points())
        self._safe(f)
    def set_trace(self,t):
        def f():
            self.rigol.set_trace_type(int(self.tr.currentText()),t)
            self.refresh_trace_metadata()
        self._safe(f)

    def set_trace_flag(self,kind,on):
        def f():
            setter=self.rigol.set_trace_display if kind=="display" else self.rigol.set_trace_update
            setter(int(self.tr.currentText()),on)
            self.refresh_trace_metadata()
        self._safe(f)

    def refresh_live(self):
        self.live_reader.refresh(force=True)

    def _live_state(self):
        reader=self.live_reader
        with QtCore.QSignalBlocker(self.live):
            self.live.setChecked(reader.enabled)
        if reader.frame is None:
            self.curve.clear()
            self._plot_range=None
            self.markers.set_frame(None)
        self.live_status.setText(reader.status)
        self.live_status.setToolTip(reader.status)
        set_theme_style(self.live_status,"color:"+("#eb8585" if reader.error else "#afbdcb")+";")
        self.diagnostic_save.setEnabled(reader.frame is not None or self.rigol.last_capture is not None)
        if reader.error and not reader.enabled and getattr(self,"_logged_live_error",None)!=reader.status:
            self._logged_live_error=reader.status
            self.controller.logger.write("Rigol: "+reader.status)
            self.controller.rigol_connected=self.rigol.connected
            self.controller.rigol_error=self.rigol.last_error if not self.rigol.connected else ""
            self.controller.updated.emit()

    def _rescale_live(self):
        self._plot_range=None
        if self.live_reader.frame is not None:
            self._show_live_frame(self.live_reader.frame)

    def export_diagnostic(self):
        from datetime import datetime
        # Capture before opening the native file picker, whose nested event loop may receive new frames.
        frame=self.live_reader.frame
        capture=frame.diagnostic if frame is not None else self.rigol.last_capture
        if capture is None:
            self.diagnostic_status.setText("Сначала нажмите «Обновить» для получения ответа Rigol.")
            return
        display={"selected_trace":int(self.tr.currentText()), "frame_visible":frame is not None,
                 "live_status":self.live_status.text(), "auto_y":self.auto_y.isChecked(),
                 "view_range":self.plot.viewRange(), "markers":self.markers.diagnostic()}
        buffer=QtCore.QBuffer(); buffer.open(QtCore.QIODevice.WriteOnly)
        self.grab().save(buffer,"PNG"); png=bytes(buffer.data()); buffer.close()
        folder=QtCore.QStandardPaths.writableLocation(QtCore.QStandardPaths.DocumentsLocation)
        default=Path(folder)/datetime.now().strftime("Sewer-Rigol-Diagnostic-%Y%m%d-%H%M%S.zip")
        filename,_=QtWidgets.QFileDialog.getSaveFileName(self,"Сохранить диагностику Rigol",str(default),"ZIP (*.zip)")
        if not filename:
            return
        path=Path(filename)
        if path.suffix.lower()!=".zip":
            path=path.with_suffix(path.suffix+".zip")
        try:
            version=asset_path("version.txt").read_text(encoding="utf-8-sig").strip()
            save_diagnostic(path,capture,png,display,version)
            self.diagnostic_status.setText("Диагностика сохранена: "+str(path))
        except Exception as exc:
            self.diagnostic_status.setText("Не удалось сохранить диагностику: "+str(exc))

    @QtCore.Slot(object)
    def _show_live_frame(self, frame):
        axis=(frame.x_label, frame.x_unit, frame.y_unit)
        if axis!=self._plot_axis:
            self._plot_axis=axis
            self.apply_plot_theme()
        self.curve.setData(frame.x,frame.y)
        self.markers.set_frame(frame)
        y_limits=None if self.auto_y.isChecked() else frame.y_limits
        limits=(frame.trace,frame.mode,axis,float(frame.x[0]),float(frame.x[-1]),y_limits)
        if limits!=self._plot_range:
            self.plot.setXRange(float(frame.x[0]),float(frame.x[-1]),padding=0)
            if y_limits is None:
                self.plot.getAxis("left").setTickSpacing()
                self.plot.enableAutoRange(axis="y",enable=True)
            else:
                self.plot.enableAutoRange(axis="y",enable=False)
                self.plot.setYRange(*y_limits,padding=0)
                self.plot.getAxis("left").setTickSpacing(major=frame.scale_div,minor=frame.scale_div)
            self._plot_range=limits
        typ={"WRIT":"Clear/Write","MAXH":"Max Hold","MINH":"Min Hold","AVER":"Average"}.get((frame.trace_type or "").upper(),frame.trace_type or "тип не прочитан")
        display="видна на приборе" if frame.display_on is True else ("скрыта на приборе" if frame.display_on is False else "видимость не прочитана")
        update="обновляется" if frame.update_on is True else ("обновление выключено" if frame.update_on is False else "Update не прочитан")
        peak=int(frame.y.argmax())
        details=f"{frame.mode}/{frame.view} · Trace {frame.trace} · {typ} · {display} · {update} · {frame.y.size} точек"
        details+=f"\nCenter {frame.center_hz/1e6:g} MHz · Span {frame.span_hz/1e6:g} MHz · Макс. {frame.x[peak]:g} {frame.x_unit}: {frame.y[peak]:.2f} {frame.y_unit}"
        details+=(f"\nШкала Rigol: Ref {frame.ref_level:g} dBm · {frame.scale_div:g} dB/div" if y_limits is not None else "\nАвтомасштаб Y по данным")
        if frame.warnings:
            details+="\n"+" · ".join(frame.warnings)
        details+="\nТип, Display/Update и шкала — по последнему опросу управления."
        if frame.mode=="RTSA" and frame.view in ("DENS","DSPE"):
            details+=" · Показана Trace 1; карта Density не передаётся этим графиком."
        self.live_status.setText(details)
        self.live_status.setToolTip(details)
        self.diagnostic_save.setEnabled(True)
        if self.status.text() in ("Не подключен", "Нет связи. Нажмите «Подключить»."):
            self.status.setText(self.rigol.idn or "Подключен")

    def showEvent(self,e):
        super().showEvent(e)
        self._connection_status()
        active = not self.rigol.suspended and not self.controller._rigol_connection_pending
        self.live_reader.set_active(active)
        self.markers.reader.set_active(active)

    def hideEvent(self,e):
        self.live_reader.set_active(False)
        self.markers.reader.set_active(False)
        super().hideEvent(e)

    def done(self, result):
        self.markers.reader.close()
        self.live_reader.close()
        super().done(result)

    def closeEvent(self,e):
        self.markers.reader.close()
        self.live_reader.close(); super().closeEvent(e)


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, controller: SewerController):
        super().__init__(); self.c=controller; self.rigol_dialog=None; self.settings_page=None
        self.setWindowTitle("Sewer-P")
        self.resize(1040,740); self.setMinimumSize(1040,740)
        icon=asset_path("Resources","Hedgehog.png")
        if icon.exists(): self.setWindowIcon(QtGui.QIcon(str(icon)))
        set_current_theme(theme_from_config(controller.config))
        self._style(); self._build(); self._shortcuts()
        controller.log_line.connect(self.append_log); controller.updated.connect(self.refresh)
        controller.rigol_span_changed.connect(self._rigol_span_changed)
        controller.presets_changed.connect(self.reload_presets)
        controller.preset_finished.connect(self.preset_result)
        self.reload_presets()
        self.refresh()

    def _style(self):
        set_theme_style(self, '''
            QWidget{background:#171c24;color:#e5ebef;font-family:"Segoe UI";font-size:12px;}
            QMainWindow,QDialog{background:#171c24;}
            QFrame#InstrumentCard{background:#222a35;border:1px solid #3b4959;border-radius:5px;}
            QFrame#MeasurementCell{background:#19212b;border:1px solid #344253;border-radius:4px;}
            QGroupBox{background:#222a35;border:1px solid #343d46;border-radius:4px;margin-top:10px;padding-top:8px;font-weight:600;}
            QGroupBox::title{subcontrol-origin:margin;left:12px;padding:0 5px;color:#b9c6d0;}
            QLabel{background:transparent;}
            QTabWidget::pane{border:1px solid #343d46;border-radius:4px;}
            QTabBar::tab{background:#252e36;color:#aebdc8;border:1px solid #343d46;padding:8px 12px;}
            QTabBar::tab:selected{background:#243b54;color:#e5ebef;border-bottom:2px solid #399ce8;}
            QCheckBox{background:transparent;spacing:7px;}
            QPushButton{background:#2c353e;border:1px solid #414e59;border-radius:4px;padding:8px 10px;}
            QPushButton:hover{background:#36434e;border-color:#657b89;}
            QPushButton:pressed{background:#202a32;}
            QPushButton:focus{border-color:#399ce8;}
            QPushButton:disabled{color:#85909a;background:#252d34;border-color:#343d46;}
            QPushButton#StartButton{background:#1769b3;border-color:#348cd9;}
            QPushButton#StartButton:hover{background:#227dc9;}
            QPushButton#StartButton:disabled{background:#243447;border-color:#3a4c61;}
            QPushButton#StopButton{border-color:#785050;}
            QPushButton#StopButton:hover{background:#493236;}
            QLineEdit,QComboBox{background:#252e36;border:1px solid #46535f;border-radius:5px;padding:5px;selection-background-color:#1769b3;}
            /* Paint the inner editor; a styled spin-box border clips it with NoButtons on Qt 6.12. */
            QAbstractSpinBox{background:#252e36;min-height:25px;}
            QAbstractSpinBox QLineEdit{background:#252e36;padding:0px 5px;}
            QPlainTextEdit{background:#171d23;border:1px solid #303b45;border-radius:4px;padding:7px;font-family:Consolas;color:#c4d2dd;}
            QProgressBar{min-height:24px;border:1px solid #3c4954;border-radius:6px;background:#182128;text-align:center;color:#e5ebef;}
            QProgressBar::chunk{background:#1769b3;border-radius:5px;}
        ''')

    def _build(self):
        self.pages = QtWidgets.QStackedWidget()
        self.setCentralWidget(self.pages)
        self.dashboard = cw = QtWidgets.QWidget()
        self.pages.addWidget(cw)
        root=QtWidgets.QVBoxLayout(cw); root.setContentsMargins(12,10,12,10); root.setSpacing(8)
        header=QtWidgets.QHBoxLayout(); root.addLayout(header)
        t=QtWidgets.QLabel('<span style="color:#73cfa6;">S</span>ewer-<span style="color:#399ce8;">P</span>'); set_theme_style(t, "font-size:32px;font-weight:700;color:#f0f5f8;"); header.addWidget(t)
        self.theme_header=ThemeHeader(); header.addWidget(self.theme_header)
        header.addStretch(1)
        self.badge_com=StatusBadge("COM"); self.badge_fw=StatusBadge("FW"); self.badge_prg=StatusBadge("PRG"); self.badge_rig=StatusBadge("RIG")
        self.settings_btn=QtWidgets.QPushButton()
        self.settings_btn.setFixedSize(68,50)
        self.settings_btn.setIconSize(QtCore.QSize(60,44))
        self.settings_btn.setToolTip("Настройки")
        self.settings_btn.setAccessibleName("Настройки")
        self.settings_btn.setCursor(QtCore.Qt.PointingHandCursor)
        set_theme_style(self.settings_btn, "QPushButton,QPushButton:hover,QPushButton:pressed,QPushButton:focus{background:transparent;border:none;padding:2px;}")
        mascot=asset_path("Resources","Hedgehog.png")
        if mascot.exists(): self.settings_btn.setIcon(QtGui.QIcon(str(mascot)))
        else: self.settings_btn.setText("Настройки")
        self.settings_btn.clicked.connect(self.open_settings)
        header.addWidget(self.settings_btn)

        body=QtWidgets.QHBoxLayout(); body.setSpacing(12); root.addLayout(body)
        cards=QtWidgets.QGridLayout(); cards.setSpacing(8); cards.setColumnStretch(0,1); cards.setColumnStretch(1,1); body.addLayout(cards,1)
        self.card_ps=MetricCard("Источник питания"); self.ps_v=self.card_ps.add_metric(1,"Огр. напряжения"); self.ps_i=self.card_ps.add_metric(2,"Огр. тока"); cards.addWidget(self.card_ps,0,0)
        self.ps_power_btn = InstrumentIconButton("power")
        self.ps_power_btn.clicked.connect(self.c.toggle_manual_power)
        self.card_ps.grid.itemAtPosition(0,0).widget().layout().addWidget(
            self.ps_power_btn, alignment=QtCore.Qt.AlignTop)
        self.card_out=MetricCard("Состояние выхода"); self.out_v=self.card_out.add_metric(1,"Напряжение"); self.out_i=self.card_out.add_metric(2,"Ток"); cards.addWidget(self.card_out,0,1)
        self.card_prg=MetricCard("Программатор"); self.card_prg.grid.setRowStretch(1,1); self.progress=QtWidgets.QProgressBar(); self.progress.setRange(0,100); set_theme_style(self.progress, "min-height:34px;max-height:34px;"); self.progress.setFixedHeight(36); self.card_prg.grid.addWidget(self.progress,2,0,1,2); cards.addWidget(self.card_prg,1,0)
        self.card_rig=MetricCard("Rigol")
        self.card_rig.setFixedHeight(242); self.card_prg.setFixedHeight(242)
        span_row=QtWidgets.QHBoxLayout(); span_row.setSpacing(6)
        self.rig_mode=QtWidgets.QLabel("—")
        set_theme_style(self.rig_mode, "font-family:Consolas;font-size:22px;font-weight:600;color:#eef4f7;")
        self.card_rig.grid.itemAtPosition(0,0).widget().layout().addWidget(self.rig_mode)
        self.rig_screenshot_btn = InstrumentIconButton("camera")
        self.rig_screenshot_btn.setAccessibleName("Скриншот Rigol")
        self.rig_screenshot_btn.clicked.connect(self.c.take_rigol_screenshot)
        self.card_rig.grid.itemAtPosition(0,0).widget().layout().addWidget(self.rig_screenshot_btn)
        span_row.addWidget(QtWidgets.QLabel("Span"))
        self.rig_span_buttons={}
        for label,hz in (("250 кГц",250_000),("500 кГц",500_000),("750 кГц",750_000),("1 МГц",1_000_000),("1,5 МГц",1_500_000),("2 МГц",2_000_000)):
            button=QtWidgets.QPushButton(label)
            button.setFixedHeight(30)
            set_theme_style(button, "padding:4px 6px;")
            button.setAccessibleName("Span " + label)
            button.setToolTip(f"В режиме RTSA установить Span {label} и прочитать фактическое значение")
            button.clicked.connect(lambda checked=False,value=hz:self.c.set_rigol_rtsa_span(value))
            span_row.addWidget(button,1)
            self.rig_span_buttons[hz]=button
        self.rig_span_btn=self.rig_span_buttons[500_000]
        self.card_rig.grid.addLayout(span_row,1,0,1,2)
        rig_buttons=QtWidgets.QHBoxLayout(); rig_buttons.setSpacing(8)
        self.rig_mode_btn=QtWidgets.QPushButton("Режим")
        self.rig_mode_btn.setToolTip("GPSA ↔ RTSA · Alt+C")
        self.rig_mode_btn.clicked.connect(self.c.switch_rigol_mode)
        self.rig_control_btn=QtWidgets.QPushButton("Управление")
        self.rig_control_btn.clicked.connect(self.open_rigol)
        self.rig_access_btn=QtWidgets.QPushButton("Подключить")
        self.rig_access_btn.setToolTip("Освободить переднюю панель / подключить Rigol · Alt+Ctrl+C")
        self.rig_access_btn.clicked.connect(self.c.toggle_rigol_connection)
        for button in (self.rig_mode_btn,self.rig_access_btn,self.rig_control_btn):
            button.setFixedHeight(36)
            rig_buttons.addWidget(button)
        self.card_rig.grid.addLayout(rig_buttons,2,0,1,2); cards.addWidget(self.card_rig,1,1)

        preset_row=QtWidgets.QHBoxLayout(); preset_row.addWidget(QtWidgets.QLabel("Пресет"))
        self.preset_combo=QtWidgets.QComboBox(); self.preset_combo.setMinimumContentsLength(14)
        self.preset_combo.setSizeAdjustPolicy(QtWidgets.QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.preset_combo.setToolTip("Таблица: ёж → Настройки → Пресеты Rigol")
        preset_row.addWidget(self.preset_combo,1)
        self.preset_apply=QtWidgets.QPushButton("Применить")
        self.preset_apply.clicked.connect(self.apply_selected_preset); preset_row.addWidget(self.preset_apply)
        self.card_rig.grid.addLayout(preset_row,3,0,1,2)
        self.preset_status=QtWidgets.QLabel(""); self.preset_status.setWordWrap(True)
        self.card_rig.grid.addWidget(self.preset_status,4,0,1,2)

        bottom_widget=QtWidgets.QWidget(); bottom_widget.setFixedHeight(192); root.addWidget(bottom_widget)
        bottom=QtWidgets.QHBoxLayout(bottom_widget); bottom.setContentsMargins(0,0,0,0)
        logbox=QtWidgets.QFrame(); logbox.setObjectName("InstrumentCard"); ll=QtWidgets.QVBoxLayout(logbox); ll.setContentsMargins(12,12,12,12); ll.setSpacing(8); log_title=QtWidgets.QLabel("Журнал событий"); set_theme_style(log_title, "font-size:14px;font-weight:600;color:#cfdeeb;"); ll.addWidget(log_title); self.log=QtWidgets.QPlainTextEdit(); self.log.setReadOnly(True); self.log.document().setMaximumBlockCount(3000); ll.addWidget(self.log); bottom.addWidget(logbox,1)
        side=QtWidgets.QVBoxLayout(); side.setSpacing(8); bottom.setSpacing(8); bottom.addLayout(side)
        self.start_btn=ActionButton("Старт", "Enter", "▶"); self.start_btn.setObjectName("StartButton")
        self.repeat_btn=ActionButton("Повторить", "Пробел", "↻")
        self.stop_btn=ActionButton("Стоп", "Esc", "■"); self.stop_btn.setObjectName("StopButton")
        self.exit_btn=ActionButton("Выход", "Alt+X", "→")
        for b in (self.start_btn,self.repeat_btn,self.stop_btn,self.exit_btn): b.setFixedSize(235,42); side.addWidget(b)
        self.start_btn.clicked.connect(self.c.start_cycle); self.repeat_btn.clicked.connect(self.c.start_cycle); self.stop_btn.clicked.connect(self.c.stop_cycle); self.exit_btn.clicked.connect(self.close)
        footer_row=QtWidgets.QHBoxLayout(); footer_row.setSpacing(6); root.addLayout(footer_row)
        for badge in (self.badge_com,self.badge_fw,self.badge_prg,self.badge_rig):
            badge.setFixedSize(28,28); footer_row.addWidget(badge)
        footer_row.addSpacing(6)
        self.footer=QtWidgets.QLabel("Инициализация"); set_theme_style(self.footer, "color:#a6b5c1;padding-top:3px;"); footer_row.addWidget(self.footer,1)
        self.runtime=QtWidgets.QLabel("00:00:00"); self.runtime.setToolTip("Время работы Sewer-P"); footer_row.addWidget(self.runtime)
        footer_row.addSpacing(20); footer_row.addWidget(QtWidgets.QLabel("Успешных плат:"))
        self.success=QtWidgets.QLabel("0"); set_theme_style(self.success, "color:#73cfa6;font-weight:700;"); footer_row.addWidget(self.success)
        self.runtime_timer=QtCore.QTimer(self); self.runtime_timer.setInterval(1000); self.runtime_timer.timeout.connect(self.refresh_runtime); self.runtime_timer.start()

    def _shortcuts(self):
        self.dashboard_shortcuts = []
        for key, fn in (("Return",lambda:self.c.start_cycle() if self.start_btn.isEnabled() else None),("Space",lambda:self.c.start_cycle() if self.repeat_btn.isEnabled() else None)):
            q=QtGui.QShortcut(QtGui.QKeySequence(key),self); q.activated.connect(fn)
            self.dashboard_shortcuts.append(q)
        for key, fn in (("Esc",self._escape),("Alt+X",self.close)):
            q=QtGui.QShortcut(QtGui.QKeySequence(key),self); q.activated.connect(fn)
        for key,fn in (("Alt+C",self.c.switch_rigol_mode),("Alt+Z",self.c.power_on),("Ctrl+Alt+C",self.c.toggle_rigol_connection),("Ctrl+Alt+S",self.c.take_rigol_screenshot)):
            q=QtGui.QShortcut(QtGui.QKeySequence(key),self)
            q.setContext(QtCore.Qt.ApplicationShortcut)
            q.setAutoRepeat(False)
            q.activated.connect(fn)
            self.dashboard_shortcuts.append(q)
        self.card_ps.setToolTip("Ручное питание: кнопка ⏻ · Стоп / Esc — отключить")

    def _escape(self):
        # Stop retains priority if the output is on, including on an inner page.
        if self.settings_page is not None and not self.stop_btn.isEnabled():
            self.settings_page.go_back()
        else:
            self.c.stop_cycle()

    def append_log(self, line: str):
        self.log.appendPlainText(line); bar=self.log.verticalScrollBar(); bar.setValue(bar.maximum())

    def refresh_runtime(self):
        s=int(time.monotonic()-self.c.started_at); self.runtime.setText(f"{s//3600:02d}:{(s%3600)//60:02d}:{s%60:02d}")

    def refresh(self):
        cfg=self.c.config; ps=cfg["PowerSupply"]; snap=self.c.power.snapshot
        self.badge_com.set_status(str(ps.get("Port","COM")), snap.com_available and snap.responding)
        _,fw,_=self.c.programmer.paths(); self.badge_fw.set_status("ГОТОВ" if fw.is_file() else "НЕ ГОТОВ",fw.is_file())
        err=self.c.programmer.configuration_error(); self.badge_prg.set_status("ГОТОВ" if not err else "НЕ ГОТОВ",not bool(err))
        self.badge_rig.set_status(self.c.rigol_mode if self.c.rigol_connected else "НЕ ГОТОВ",self.c.rigol_connected)
        if self.c.rigol_error:
            self.badge_rig.setToolTip("Rigol: "+self.c.rigol_error)
        self.card_rig.setToolTip(self.c.rigol_error or self.c.rigol.idn)
        self.card_ps.set_status("ПОДКЛЮЧЕН" if snap.responding else "НЕ ПОДКЛЮЧЕН",snap.responding)
        power_action = "Выключить источник питания" if snap.output_on or self.c.state == "ManualPower" else "Включить источник питания"
        self.ps_power_btn.setAccessibleName(power_action)
        self.ps_power_btn.setToolTip(power_action)
        self.ps_power_btn.setEnabled(self.c.manual_power_available)
        if self.ps_power_btn.active != snap.output_on:
            self.ps_power_btn.active = snap.output_on
            self.ps_power_btn.update()
        self.ps_v.setText(f"{float(ps.get('Voltage',0)):.2f} В"); self.ps_i.setText(f"{float(ps.get('CurrentLimit',0)):.3f} А")
        self.card_out.set_status("ВКЛЮЧЕН" if snap.output_on else "ВЫКЛЮЧЕН",True if snap.output_on else False)
        self.out_v.setText(f"{snap.voltage:.2f} В"); self.out_i.setText(f"{snap.current*1000:.1f} мА")
        pst=self.c.progress_state; self.card_prg.set_status("Готов" if not err else "Не готов", not bool(err))
        self.progress.setValue(int(self.c.programmer.progress))
        if self.c._rigol_connection_pending:
            self.card_rig.set_status("ПОДОЖДИТЕ…",None)
        elif self.c.rigol.suspended:
            self.card_rig.set_status("ОПРОС ОСТАНОВЛЕН" if self.c.rigol_error else "ОСВОБОЖДЁН",None)
        else:
            self.card_rig.set_status("ПОДКЛЮЧЕН" if self.c.rigol_connected else "НЕТ СВЯЗИ",self.c.rigol_connected)
        self.rig_mode.setText("—" if self.c.rigol.suspended else self.c.rigol_mode)
        self.rig_access_btn.setText("Освободить" if self.c.rigol_connected and not self.c.rigol.suspended else "Подключить")
        self.rig_access_btn.setEnabled(not self.c._rigol_action_pending and not self.c.screenshot_busy)
        self.rig_screenshot_btn.setToolTip("Сохраняю скриншот Rigol…" if self.c.screenshot_busy else
                                          "Снимок экрана Rigol через Ethernet · Ctrl+Alt+S")
        self.rig_screenshot_btn.setEnabled(self.c.rigol_screenshot_available)
        self.rig_mode_btn.setEnabled(self.c.rigol_connected and not self.c._rigol_action_pending)
        for button in self.rig_span_buttons.values():
            button.setEnabled(self.c.rigol_connected and self.c.rigol_mode=="RTSA" and not self.c._rigol_action_pending)
        self.rig_control_btn.setEnabled(True)
        self.preset_apply.setEnabled(self.c.rigol_connected and not self.c._rigol_action_pending and self.preset_combo.count()>0 and not self.c.presets.error)
        self.preset_combo.setEnabled(not self.c._rigol_action_pending)
        idle=self.c.state=="Idle"; self.start_btn.setEnabled(idle and self.c.ready); self.repeat_btn.setEnabled(idle and self.c.ready and self.c.can_repeat); self.stop_btn.setEnabled(not idle or self.c._busy or snap.output_on); self.settings_btn.setEnabled(idle)
        if self.settings_page is not None:
            self.settings_page.stop_button.setEnabled(self.stop_btn.isEnabled())
        self.success.setText(str(self.c.successful_boards)); self.footer.setText("Готов к работе" if self.c.ready else f"Не готов: {self.c.readiness_reason}")
        if self.c.state=="ManualPower":
            self.footer.setText("Ручное питание · ⏻ или Стоп / Esc — отключить")

    def apply_theme(self, key):
        set_current_theme(normalize_theme(key))
        apply_widget_theme(self)
        if self.rigol_dialog is not None:
            self.rigol_dialog.apply_plot_theme()

    def reload_presets(self):
        selected=self.preset_combo.currentData()
        self.preset_combo.clear()
        for row in self.c.presets.rows:
            self.preset_combo.addItem(row['name'],row['id'])
        index=self.preset_combo.findData(selected)
        if index>=0:self.preset_combo.setCurrentIndex(index)
        self.preset_status.setText("Ошибка таблицы: "+self.c.presets.error if self.c.presets.error else "")
        self.refresh()

    def apply_selected_preset(self):
        token=self.preset_combo.currentData()
        row=next((r for r in self.c.presets.rows if r['id']==token),None)
        if row:
            self.preset_status.setText("Применение «"+row['name']+"»…")
            if not self.c.apply_rigol_preset(row):
                self.preset_status.setText("Rigol недоступен или занят")

    def preset_result(self,result,error):
        text=("Ошибка: "+str(error)) if error else ("Применён: "+result['name']+(" · прибор скорректировал значения (см. журнал)" if result.get('differences') else ""))
        self.preset_status.setText(text)
        self.preset_status.setToolTip(text if error else str(result['actual']))

    def _rigol_span_changed(self, hz):
        if self.rigol_dialog is not None:
            dialog = self.rigol_dialog
            dialog._load_numeric(dialog.span, hz / 1e6)
            dialog.live_reader.invalidate()
            dialog.refresh_live()

    def open_settings(self):
        if self.c.state != "Idle" or self.c._busy or self.settings_page is not None:
            return
        page = SettingsPage(clone_config(self.c.config), self)
        original_controls = page.controls_snapshot()
        self.settings_page = page
        page.theme_preview.connect(self.apply_theme)
        page.save_requested.connect(lambda: self._save_settings(page, original_controls))
        page.cancelled.connect(self._close_settings)
        self.pages.addWidget(page)
        self.pages.setCurrentWidget(page)
        for shortcut in self.dashboard_shortcuts:
            shortcut.setEnabled(False)
        page.stop_button.setEnabled(self.stop_btn.isEnabled())
        page.back_button.setFocus()

    def _save_settings(self, page, original_controls):
        try:
            controls = page.controls_snapshot()
            changes = {key for key, value in controls.items() if original_controls[key] != value}
            updated = page.result_config()
            if changes <= page.SCREENSHOT_CONTROLS:
                screenshot = updated["RigolScreenshot"]
                updated = clone_config(self.c.config)
                updated.setdefault("Application", {})["Theme"] = page.selected_theme
                if changes:
                    updated["RigolScreenshot"] = screenshot
                self.c.config = save_config(updated, self.c.config_path)
                self.c.updated.emit()
            else:
                self.c.apply_config(updated)
        except Exception as exc:
            page.show_error(f"Не удалось сохранить настройки: {exc}")
            return
        self._close_settings()

    def _close_settings(self):
        page, self.settings_page = self.settings_page, None
        if page is None:
            return
        self.pages.setCurrentWidget(self.dashboard)
        self.pages.removeWidget(page)
        page.deleteLater()
        for shortcut in self.dashboard_shortcuts:
            shortcut.setEnabled(True)
        self.apply_theme(theme_from_config(self.c.config))
        self.settings_btn.setFocus()

    def open_rigol(self):
        if self.rigol_dialog is None:
            self.rigol_dialog=RigolControlDialog(self.c,self); self.rigol_dialog.finished.connect(lambda _:setattr(self,'rigol_dialog',None))
        self.rigol_dialog.show(); self.rigol_dialog.raise_(); self.rigol_dialog.activateWindow()
        if self.c.rigol.connected:
            try: self.rigol_dialog.refresh_all()
            except Exception as e: self.rigol_dialog.status.setText(str(e))
        else:
            self.rigol_dialog.status.setText(self.c.rigol_error or self.c.rigol.last_error or "Нет связи. Нажмите «Подключить».")

    def closeEvent(self,e):
        if self.rigol_dialog is not None:
            self.rigol_dialog.close()
        self.runtime_timer.stop(); self.c.close(); super().closeEvent(e)
