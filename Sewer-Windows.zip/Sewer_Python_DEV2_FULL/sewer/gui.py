from __future__ import annotations

import time
from pathlib import Path

from PySide6 import QtCore, QtGui, QtWidgets
import pyqtgraph as pg

from .config import clone_config, save_config
from .themes import (theme_from_config, normalize_theme, set_current_theme, theme_color, mapped_color,
                     action_text, set_theme_style, apply_widget_theme, ThemeHeader, draw_card_decoration)
from .controller import SewerController
from .rigol_live import RigolLive
from .rigol_diagnostic import save_diagnostic
from .number_input import NumberInput
from .settings import SettingsDialog

BW = [
    ("1 Hz",1),("3 Hz",3),("10 Hz",10),("30 Hz",30),("100 Hz",100),("300 Hz",300),
    ("1 kHz",1e3),("3 kHz",3e3),("10 kHz",1e4),("30 kHz",3e4),("100 kHz",1e5),
    ("300 kHz",3e5),("1 MHz",1e6),("3 MHz",3e6),("10 MHz",1e7),
]


class ReverseWheelCombo(QtWidgets.QComboBox):
    def wheelEvent(self, event):
        if not self.isEnabled() or self.count() == 0:
            event.ignore(); return
        delta = event.angleDelta().y()
        if delta == 0:
            event.ignore(); return
        step = 1 if delta > 0 else -1
        self.setCurrentIndex(max(0, min(self.count()-1, self.currentIndex()+step)))
        event.accept()


class StatusBadge(QtWidgets.QFrame):
    TITLES = {"COM": "Источник питания", "FW": "Файл прошивки", "PRG": "Программатор", "RIG": "Rigol"}

    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.kind = title
        self.ok = None
        self.setFixedSize(46, 46)
        self.setAccessibleName(self.TITLES[title])

    def set_status(self, text: str, ok: bool | None):
        self.ok = ok
        state = "Готов" if ok else "Не готов"
        self.setToolTip(f"{self.TITLES[self.kind]}: {state} · {text}")
        self.setAccessibleDescription(self.toolTip())
        self.update()

    def paintEvent(self, event):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        p.scale(self.width()/46, self.height()/46)
        color = theme_color("#d3e1ef" if getattr(self,"monochrome",False) else "#73cfa6" if self.ok else "#eb8585")
        p.setPen(QtGui.QPen(theme_color("#343d46"), 1))
        p.setBrush(theme_color("#232b33"))
        if not getattr(self,"monochrome",False): p.drawRoundedRect(QtCore.QRectF(0.5, 0.5, 45, 45), 4, 4)
        p.setPen(QtGui.QPen(color, 1.7))
        p.setBrush(QtCore.Qt.NoBrush)
        if self.kind == "COM":
            p.drawRoundedRect(QtCore.QRectF(15, 16, 16, 12), 3, 3)
            p.drawLine(19, 11, 19, 16); p.drawLine(27, 11, 27, 16)
            p.drawLine(23, 28, 23, 35)
        elif self.kind == "FW":
            p.drawRoundedRect(QtCore.QRectF(16, 11, 15, 23), 2, 2)
            p.drawLine(20, 19, 27, 19); p.drawLine(20, 24, 27, 24)
            p.drawLine(20, 29, 25, 29)
        elif self.kind == "PRG":
            p.drawRoundedRect(QtCore.QRectF(15, 15, 16, 16), 2, 2)
            for n in (18, 23, 28):
                p.drawLine(n, 11, n, 15); p.drawLine(n, 31, n, 35)
                p.drawLine(11, n, 15, n); p.drawLine(31, n, 35, n)
        else:
            p.drawLine(12, 33, 34, 33)
            path = QtGui.QPainterPath(QtCore.QPointF(12, 28))
            for x, y in ((17,28),(21,14),(25,29),(29,23),(34,28)):
                path.lineTo(x, y)
            p.drawPath(path)
        p.end()


class ActionButton(QtWidgets.QPushButton):
    def __init__(self, label, shortcut, symbol, parent=None):
        super().__init__(parent)
        self.label, self.shortcut, self.symbol = label, shortcut, symbol
        self.setAccessibleName(f"{label}, {shortcut}")
        self.setToolTip(f"{label} · {shortcut}")
        self.setMinimumSize(205, 42)
        self.setCursor(QtCore.Qt.PointingHandCursor)

    def paintEvent(self, event):
        super().paintEvent(event)
        p = QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing)
        enabled = self.isEnabled()
        color = action_text(self.objectName()=="StartButton", enabled)
        p.setPen(QtGui.QPen(color, 2.4)); p.setBrush(QtCore.Qt.NoBrush)
        cy = self.height()/2
        if self.symbol == "▶":
            p.setPen(QtCore.Qt.NoPen); p.setBrush(color)
            p.drawPolygon(QtGui.QPolygonF([QtCore.QPointF(19,cy-10),QtCore.QPointF(19,cy+10),QtCore.QPointF(34,cy)]))
        elif self.symbol == "■":
            p.setPen(QtCore.Qt.NoPen); p.setBrush(theme_color("#f27979" if enabled else "#926a70"))
            p.drawRoundedRect(QtCore.QRectF(17,cy-10,20,20),2,2)
        elif self.symbol == "↻":
            p.drawArc(QtCore.QRectF(17,cy-11,22,22),40*16,285*16)
            p.drawLine(QtCore.QPointF(37,cy-12),QtCore.QPointF(37,cy-3))
            p.drawLine(QtCore.QPointF(37,cy-3),QtCore.QPointF(28,cy-3))
        else:
            p.drawLine(QtCore.QPointF(17,cy-11),QtCore.QPointF(17,cy+11))
            p.drawLine(QtCore.QPointF(17,cy-11),QtCore.QPointF(27,cy-11))
            p.drawLine(QtCore.QPointF(17,cy+11),QtCore.QPointF(27,cy+11))
            p.drawLine(QtCore.QPointF(24,cy),QtCore.QPointF(40,cy))
            p.drawLine(QtCore.QPointF(34,cy-6),QtCore.QPointF(40,cy))
            p.drawLine(QtCore.QPointF(34,cy+6),QtCore.QPointF(40,cy))
        p.setPen(color)
        font=self.font(); font.setPixelSize(17); font.setBold(True); p.setFont(font)
        p.drawText(QtCore.QRect(50,0,self.width()-108,self.height()),QtCore.Qt.AlignVCenter,self.label)
        font.setPixelSize(11); font.setBold(False); p.setFont(font)
        p.setPen(action_text(self.objectName()=="StartButton", enabled, shortcut=True))
        p.drawText(QtCore.QRect(self.width()-58,0,48,self.height()),QtCore.Qt.AlignRight|QtCore.Qt.AlignVCenter,self.shortcut)
        p.end()


class PanelIcon(StatusBadge):
    def __init__(self, kind, parent=None):
        super().__init__(kind,parent)
        self.ok=True
        self.monochrome=True
        set_theme_style(self, "background:transparent;border:none;")
        self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents)


class MetricCard(QtWidgets.QFrame):
    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.setObjectName("InstrumentCard")
        self.setFixedHeight(158)
        self.grid=QtWidgets.QGridLayout(self)
        self.grid.setContentsMargins(12,12,12,12); self.grid.setSpacing(8)
        self.grid.setColumnStretch(0,1); self.grid.setColumnStretch(1,1)
        header_widget=QtWidgets.QWidget(); set_theme_style(header_widget, "background:transparent;"); header_widget.setFixedHeight(46)
        header=QtWidgets.QHBoxLayout(header_widget); header.setContentsMargins(0,0,0,0); header.setSpacing(9)
        kind={"Источник питания":"COM","Состояние выхода":"RIG","Программатор":"PRG","Rigol":"RIG"}[title]
        header.addWidget(PanelIcon(kind))
        labels=QtWidgets.QVBoxLayout(); labels.setSpacing(3)
        heading=QtWidgets.QLabel(title); heading._theme_heading=True; set_theme_style(heading, "font-size:18px;font-weight:700;color:#e9f1f8;")
        self.status=QtWidgets.QLabel("—")
        labels.addWidget(heading); labels.addWidget(self.status); header.addLayout(labels,1)
        self.grid.addWidget(header_widget,0,0,1,2)
        self.rows={}
        self.is_measurement=title in ("Источник питания","Состояние выхода")

    def paintEvent(self, event):
        super().paintEvent(event)
        draw_card_decoration(self)

    def add_metric(self, row: int, label: str):
        if self.is_measurement:
            cell=QtWidgets.QFrame(); cell.setObjectName("MeasurementCell")
            layout=QtWidgets.QVBoxLayout(cell); layout.setContentsMargins(10,8,8,8); layout.setSpacing(5)
            caption=QtWidgets.QLabel(label); set_theme_style(caption, "color:#afbdcb;font-size:12px;")
            value=QtWidgets.QLabel("—"); value.setAlignment(QtCore.Qt.AlignLeft|QtCore.Qt.AlignVCenter)
            set_theme_style(value, "font-family:Consolas;font-size:34px;font-weight:700;color:#f3f7fc;")
            layout.addWidget(caption); layout.addWidget(value,1)
            self.grid.addWidget(cell,1,row-1,2,1)
        else:
            caption=QtWidgets.QLabel(label); set_theme_style(caption, "color:#afbdcb;font-size:14px;")
            value=QtWidgets.QLabel("—"); value.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignVCenter)
            set_theme_style(value, "font-family:Consolas;font-size:22px;font-weight:600;color:#eef4f7;")
            self.grid.addWidget(caption,row,0); self.grid.addWidget(value,row,1)
        self.rows[label]=value
        return value

    def set_status(self, text: str, ok: bool | None):
        self.status.setText("●  "+text)
        color="#73cfa6" if ok is True else "#eb8585" if ok is False else "#d9bb79"
        set_theme_style(self.status, f"font-size:13px;font-weight:600;color:{color};")


class RigolControlDialog(QtWidgets.QDialog):
    def __init__(self, controller: SewerController, parent=None):
        super().__init__(parent)
        self.controller=controller; self.rigol=controller.rigol
        self.setWindowTitle("Rigol — управление")
        self.resize(1260,780)
        self.setModal(False)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        self.live_reader=RigolLive(self.rigol, controller.config.get("Rigol",{}).get("LiveIntervalMs",300), self)
        self.live_timer=self.live_reader.timer
        self._plot_axis=("Frequency", "MHz", "dBm")
        self._plot_range=None
        self._choose_visible_trace=True
        self._build()
        self.apply_plot_theme()
        self.live_reader.changed.connect(self._live_state)
        self.live_reader.frame_ready.connect(self._show_live_frame)
        self._live_state()

    def apply_plot_theme(self):
        self.plot.setBackground(mapped_color("#171d23"))
        self.curve.setPen(pg.mkPen(mapped_color("#399ce8"),width=1.5))
        for side in ("bottom","left"):
            axis=self.plot.getAxis(side); axis.setPen(theme_color("#afbdcb")); axis.setTextPen(theme_color("#afbdcb"))
            axis.enableAutoSIPrefix(False)
        label,x_unit,y_unit=self._plot_axis
        self.plot.setLabel("bottom",label,x_unit,color=mapped_color("#afbdcb"))
        self.plot.setLabel("left","Level",y_unit,color=mapped_color("#afbdcb"))

    def _build(self):
        root=QtWidgets.QVBoxLayout(self)
        top=QtWidgets.QHBoxLayout(); root.addLayout(top)
        self.resource=QtWidgets.QLineEdit(self.controller.config.get("Rigol",{}).get("Resource","")); top.addWidget(self.resource,1)
        b=QtWidgets.QPushButton("Подключить"); b.clicked.connect(self.connect_rigol); top.addWidget(b)
        self.mode=QtWidgets.QComboBox(); self.mode.addItems(["GPSA","RTSA"]); top.addWidget(self.mode)
        bm=QtWidgets.QPushButton("Режим"); bm.clicked.connect(self.apply_mode); top.addWidget(bm)
        self.status=QtWidgets.QLabel("Не подключен"); top.addWidget(self.status)
        self.status.setMaximumWidth(320)
        self.status.setWordWrap(True)
        self.status.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)

        body=QtWidgets.QHBoxLayout(); root.addLayout(body,1)
        left=QtWidgets.QVBoxLayout(); body.addLayout(left,0)

        self.center=self._dspin(0,6500,1,6,"MHz")
        self.span=self._dspin(0,6500,1,6,"MHz")
        left.addWidget(self._group("Frequency",[("Center",self.center,self.apply_center),("Span",self.span,self.apply_span)]))

        self.ref=self._dspin(-99,99,1,1," dBm")
        self.off=self._dspin(-300,300,1,1," dB")
        self.scale=QtWidgets.QSpinBox(); self.scale.setButtonSymbols(QtWidgets.QAbstractSpinBox.NoButtons); self.scale.setRange(1,20); self.scale.setSingleStep(1); self.scale.unit="dB/div"; self.scale.setKeyboardTracking(False)
        self.att=self._dspin(0,70,1,0," dB")
        left.addWidget(self._group("Amplitude",[("Ref Level",self.ref,self.apply_ref),("Ref Offset",self.off,self.apply_off),("Scale/Div",self.scale,self.apply_scale),("Attenuation",self.att,self.apply_att)]))

        gbw=QtWidgets.QGroupBox("BW"); gl=QtWidgets.QGridLayout(gbw)
        self.rbw=ReverseWheelCombo(); self.vbw=ReverseWheelCombo()
        for n,v in BW: self.rbw.addItem(n,v); self.vbw.addItem(n,v)
        self.rbwa=QtWidgets.QCheckBox("Auto"); self.vbwa=QtWidgets.QCheckBox("Auto")
        gl.addWidget(QtWidgets.QLabel("RBW"),0,0); gl.addWidget(self.rbw,0,1); gl.addWidget(self.rbwa,0,2)
        gl.addWidget(QtWidgets.QLabel("VBW"),1,0); gl.addWidget(self.vbw,1,1); gl.addWidget(self.vbwa,1,2)
        br=QtWidgets.QPushButton("Применить BW"); br.clicked.connect(self.apply_bw); gl.addWidget(br,2,0,1,3)
        left.addWidget(gbw)

        gs=QtWidgets.QGroupBox("Sweep"); sl=QtWidgets.QGridLayout(gs)
        self.sweept=self._dspin(1,4000000,1,0," ms"); self.sweepa=QtWidgets.QCheckBox("Auto")
        self.points=QtWidgets.QSpinBox(); self.points.setButtonSymbols(QtWidgets.QAbstractSpinBox.NoButtons); self.points.setRange(101,10001); self.points.setSingleStep(1); self.points.setKeyboardTracking(False)
        bc=QtWidgets.QPushButton("Continuous"); bc.clicked.connect(lambda:self._safe(lambda:self.rigol.continuous(True)))
        bs=QtWidgets.QPushButton("Single"); bs.clicked.connect(lambda:self._safe(self.rigol.single))
        sl.addWidget(bc,0,0); sl.addWidget(bs,0,1)
        sl.addWidget(QtWidgets.QLabel("Sweep Time"),1,0); sl.addWidget(self._with_unit(self.sweept),1,1); sl.addWidget(self.sweepa,1,2)
        sl.addWidget(QtWidgets.QLabel("Points"),2,0); sl.addWidget(self.points,2,1)
        ba=QtWidgets.QPushButton("Применить Sweep"); ba.clicked.connect(self.apply_sweep); sl.addWidget(ba,3,0,1,3)
        left.addWidget(gs)
        self._watch_numeric(self.sweept,self.apply_sweep)
        self._watch_numeric(self.points,self.apply_sweep)

        gt=QtWidgets.QGroupBox("Trace"); tl=QtWidgets.QGridLayout(gt)
        self.tr=QtWidgets.QComboBox(); self.tr.addItems([str(i) for i in range(1,7)])
        self.tr.currentIndexChanged.connect(lambda index:self.live_reader.set_trace(index+1))
        self.tr.currentIndexChanged.connect(self.refresh_trace_metadata)
        tl.addWidget(QtWidgets.QLabel("Trace"),0,0); tl.addWidget(self.tr,0,1)
        for i,(txt,typ) in enumerate([("Clear/Write","WRITe"),("Max Hold","MAXHold"),("Average","AVERage"),("Min Hold","MINHold")]):
            b=QtWidgets.QPushButton(txt); b.clicked.connect(lambda _,t=typ:self.set_trace(t)); tl.addWidget(b,1+i//2,i%2)
        self.live=QtWidgets.QCheckBox(f"Live {self.live_timer.interval()} ms")
        self.live.setChecked(True)
        self.live.toggled.connect(self.live_reader.set_enabled)
        self.live_refresh=QtWidgets.QPushButton("Обновить")
        self.live_refresh.clicked.connect(self.refresh_live)
        tl.addWidget(self.live,3,0); tl.addWidget(self.live_refresh,3,1); left.addWidget(gt); left.addStretch()

        graph=QtWidgets.QVBoxLayout(); body.addLayout(graph,1)
        graph_tools=QtWidgets.QHBoxLayout(); graph.addLayout(graph_tools)
        self.auto_y=QtWidgets.QCheckBox("Автомасштаб Y")
        self.auto_y.setChecked(True)
        self.auto_y.setToolTip("Выключено: шкала Ref Level / Scale/Div прибора для dBm, LOG. Включено: масштаб по данным.")
        self.auto_y.toggled.connect(self._rescale_live)
        graph_tools.addWidget(self.auto_y); graph_tools.addStretch()
        self.diagnostic_save=QtWidgets.QPushButton("Сохранить диагностику…")
        self.diagnostic_save.setToolTip("Сохранить последний ответ Rigol, параметры и снимок окна в ZIP")
        self.diagnostic_save.clicked.connect(self.export_diagnostic)
        graph_tools.addWidget(self.diagnostic_save)
        self.plot=pg.PlotWidget(); graph.addWidget(self.plot,1)
        self.curve=self.plot.plot(); self.plot.showGrid(x=True,y=True)
        self.plot.setLabel("bottom","Frequency","MHz"); self.plot.setLabel("left","Level","dBm")
        self.live_status=QtWidgets.QLabel()
        self.live_status.setWordWrap(True)
        graph.addWidget(self.live_status)
        self.diagnostic_status=QtWidgets.QLabel()
        self.diagnostic_status.setWordWrap(True)
        self.diagnostic_status.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        graph.addWidget(self.diagnostic_status)
        for button in self.findChildren(QtWidgets.QPushButton):
            button.setAutoDefault(False)
            button.setDefault(False)

    def _dspin(self,a,b,step,dec,unit):
        x=NumberInput(); x.setDecimals(dec); x.setRange(a,b); x.setSingleStep(step); x.unit=unit.strip(); return x

    def _with_unit(self, editor):
        row=QtWidgets.QWidget()
        set_theme_style(row,"background:transparent;")
        layout=QtWidgets.QHBoxLayout(row); layout.setContentsMargins(0,0,0,0); layout.setSpacing(6)
        layout.addWidget(editor,1)
        editor.unit_label=QtWidgets.QLabel(editor.unit)
        editor.unit_label.setMinimumWidth(42)
        layout.addWidget(editor.unit_label)
        return row

    def _watch_numeric(self, editor, apply):
        editor._user_edited=False
        editor._readback=editor.value()
        editor.lineEdit().textEdited.connect(lambda _:setattr(editor,"_user_edited",True))
        editor.valueChanged.connect(lambda _:setattr(editor,"_user_edited",True))
        editor.editingFinished.connect(lambda:self._apply_if_edited(editor,apply))

    def _apply_if_edited(self, editor, apply):
        if editor._user_edited and editor.hasAcceptableInput() and editor.value()!=editor._readback:
            apply()
        elif editor.value()==editor._readback:
            editor._user_edited=False

    def _load_numeric(self, editor, value):
        blocker=QtCore.QSignalBlocker(editor)
        editor.setValue(int(round(value)) if isinstance(editor,QtWidgets.QSpinBox) else value)
        editor._readback=editor.value()
        editor._user_edited=False
        editor.lineEdit().setModified(False)
        del blocker

    def _apply_numeric(self, editor, setter, getter, factor=1):
        def f():
            editor.interpretText()
            setter(editor.value()*factor)
            self._load_numeric(editor,getter()/factor)
        self._safe(f)

    def _group(self,title,rows):
        g=QtWidgets.QGroupBox(title); l=QtWidgets.QGridLayout(g)
        for r,(name,w,fn) in enumerate(rows):
            l.addWidget(QtWidgets.QLabel(name),r,0); l.addWidget(self._with_unit(w),r,1)
            self._watch_numeric(w,fn)
            b=QtWidgets.QPushButton("Set"); b.clicked.connect(lambda checked=False,w=w,fn=fn:self._apply_if_edited(w,fn)); l.addWidget(b,r,2)
        return g

    def _safe(self, fn):
        self.live_reader.invalidate()
        try: fn(); self.status.setText("OK"); self.live_reader.refresh()
        except Exception as e:
            self.status.setText(str(e))
            if not self.rigol.connected:
                self.controller.rigol_connected=False
                self.controller.rigol_error=str(e)
                self.controller.logger.write("Rigol: "+str(e))
                self.controller.updated.emit()

    def connect_rigol(self):
        def f():
            self._choose_visible_trace=True
            rc=self.controller.config.get("Rigol",{})
            self.rigol.reconfigure(self.resource.text().strip(), int(rc.get("TimeoutMs",2500)))
            self.rigol.connect(str(rc.get("ExpectedManufacturer","RIGOL")),str(rc.get("ExpectedModel","RSA5065N")))
            self.controller.rigol_connected=True
            self.controller.rigol_error=""
            self.controller.rigol_mode="—"
            try:
                self.controller.rigol_mode=self.rigol.mode()
                self.refresh_all()
            finally:
                self.controller.rigol_connected=self.rigol.connected
                self.controller.updated.emit()
        self._safe(f)

    def refresh_all(self):
        self.status.setText(self.rigol.idn or "Подключен")
        self.mode.setCurrentText(self.rigol.mode())
        self._load_numeric(self.center,self.rigol.center_hz()/1e6); self._load_numeric(self.span,self.rigol.span_hz()/1e6)
        self._load_numeric(self.ref,self.rigol.ref_level()); self._load_numeric(self.off,self.rigol.ref_offset())
        self._load_numeric(self.scale,self.rigol.scale_div()); self._load_numeric(self.att,self.rigol.attenuation())
        self._load_numeric(self.sweept,self.rigol.sweep_time()*1000); self._load_numeric(self.points,self.rigol.sweep_points())
        for combo,val in ((self.rbw,self.rigol.rbw()),(self.vbw,self.rigol.vbw())):
            idx=min(range(combo.count()), key=lambda i:abs(combo.itemData(i)-val)); combo.setCurrentIndex(idx)
        self.rbwa.setChecked(self.rigol.query_bool(":SENSe:BANDwidth:RESolution:AUTO?"))
        self.vbwa.setChecked(self.rigol.query_bool(":SENSe:BANDwidth:VIDeo:AUTO?"))
        self.sweepa.setChecked(self.rigol.query_bool(":SENSe:SWEep:TIME:AUTO?"))
        if self._choose_visible_trace:
            visible=self.rigol.visible_traces()
            if visible and int(self.tr.currentText()) not in visible:
                self.tr.setCurrentIndex(visible[0]-1)
            self._choose_visible_trace=False
        self.refresh_trace_metadata()
        try:
            self.rigol.query(":DISPlay:WINDow:TRACe:Y:SCALe:SPACing?")
        except Exception as exc:
            self.status.setText("Шкала не прочитана: "+str(exc))

    def refresh_trace_metadata(self):
        if not self.rigol.connected:
            return
        n=int(self.tr.currentText())
        try:
            self.rigol.trace_type(n)
            self.rigol.trace_display(n)
            self.rigol.trace_update(n)
        except Exception as exc:
            self.status.setText("Состояние Trace не прочитано: "+str(exc))

    def apply_mode(self):
        def f():
            self.rigol.set_mode(self.mode.currentText())
            self.controller.rigol_mode=self.mode.currentText()
            self.controller.updated.emit()
        self._safe(f)
    def apply_center(self): self._apply_numeric(self.center,self.rigol.set_center_hz,self.rigol.center_hz,1e6)
    def apply_span(self): self._apply_numeric(self.span,self.rigol.set_span_hz,self.rigol.span_hz,1e6)
    def apply_ref(self): self._apply_numeric(self.ref,self.rigol.set_ref_level,self.rigol.ref_level)
    def apply_off(self): self._apply_numeric(self.off,self.rigol.set_ref_offset,self.rigol.ref_offset)
    def apply_scale(self): self._apply_numeric(self.scale,self.rigol.set_scale_div,self.rigol.scale_div)
    def apply_att(self): self._apply_numeric(self.att,self.rigol.set_attenuation,self.rigol.attenuation)
    def apply_bw(self):
        def f():
            self.rigol.set_rbw_auto(self.rbwa.isChecked()); self.rigol.set_vbw_auto(self.vbwa.isChecked())
            if not self.rbwa.isChecked(): self.rigol.set_rbw(self.rbw.currentData())
            if not self.vbwa.isChecked(): self.rigol.set_vbw(self.vbw.currentData())
        self._safe(f)
    def apply_sweep(self):
        def f():
            self.sweept.interpretText(); self.points.interpretText()
            self.rigol.set_sweep_time_auto(self.sweepa.isChecked())
            if not self.sweepa.isChecked(): self.rigol.set_sweep_time(self.sweept.value()/1000)
            self.rigol.set_sweep_points(self.points.value())
            self._load_numeric(self.sweept,self.rigol.sweep_time()*1000)
            self._load_numeric(self.points,self.rigol.sweep_points())
        self._safe(f)
    def set_trace(self,t):
        def f():
            self.rigol.set_trace_type(int(self.tr.currentText()),t)
            self.refresh_trace_metadata()
        self._safe(f)

    def refresh_live(self):
        self.live_reader.refresh(force=True)

    def _live_state(self):
        reader=self.live_reader
        with QtCore.QSignalBlocker(self.live):
            self.live.setChecked(reader.enabled)
        if reader.frame is None:
            self.curve.clear()
            self._plot_range=None
        self.live_status.setText(reader.status)
        self.live_status.setToolTip(reader.status)
        set_theme_style(self.live_status,"color:"+("#eb8585" if reader.error else "#afbdcb")+";")
        self.diagnostic_save.setEnabled(reader.frame is not None or self.rigol.last_capture is not None)
        if reader.error and not reader.enabled and getattr(self,"_logged_live_error",None)!=reader.status:
            self._logged_live_error=reader.status
            self.controller.logger.write("Rigol: "+reader.status)
            self.controller.rigol_connected=self.rigol.connected
            self.controller.rigol_error=self.rigol.last_error if not self.rigol.connected else ""
            self.controller.updated.emit()

    def _rescale_live(self):
        self._plot_range=None
        if self.live_reader.frame is not None:
            self._show_live_frame(self.live_reader.frame)

    def export_diagnostic(self):
        from datetime import datetime
        # Capture before opening the native file picker, whose nested event loop may receive new frames.
        frame=self.live_reader.frame
        capture=frame.diagnostic if frame is not None else self.rigol.last_capture
        if capture is None:
            self.diagnostic_status.setText("Сначала нажмите «Обновить» для получения ответа Rigol.")
            return
        display={"selected_trace":int(self.tr.currentText()), "frame_visible":frame is not None,
                 "live_status":self.live_status.text(), "auto_y":self.auto_y.isChecked(),
                 "view_range":self.plot.viewRange()}
        buffer=QtCore.QBuffer(); buffer.open(QtCore.QIODevice.WriteOnly)
        self.grab().save(buffer,"PNG"); png=bytes(buffer.data()); buffer.close()
        folder=QtCore.QStandardPaths.writableLocation(QtCore.QStandardPaths.DocumentsLocation)
        default=Path(folder)/datetime.now().strftime("Sewer-Rigol-Diagnostic-%Y%m%d-%H%M%S.zip")
        filename,_=QtWidgets.QFileDialog.getSaveFileName(self,"Сохранить диагностику Rigol",str(default),"ZIP (*.zip)")
        if not filename:
            return
        path=Path(filename)
        if path.suffix.lower()!=".zip":
            path=path.with_suffix(path.suffix+".zip")
        try:
            version=(self.controller.root/"version.txt").read_text(encoding="utf-8-sig").strip()
            save_diagnostic(path,capture,png,display,version)
            self.diagnostic_status.setText("Диагностика сохранена: "+str(path))
        except Exception as exc:
            self.diagnostic_status.setText("Не удалось сохранить диагностику: "+str(exc))

    @QtCore.Slot(object)
    def _show_live_frame(self, frame):
        axis=(frame.x_label, frame.x_unit, frame.y_unit)
        if axis!=self._plot_axis:
            self._plot_axis=axis
            self.apply_plot_theme()
        self.curve.setData(frame.x,frame.y)
        y_limits=None if self.auto_y.isChecked() else frame.y_limits
        limits=(frame.trace,frame.mode,axis,float(frame.x[0]),float(frame.x[-1]),y_limits)
        if limits!=self._plot_range:
            self.plot.setXRange(float(frame.x[0]),float(frame.x[-1]),padding=0)
            if y_limits is None:
                self.plot.getAxis("left").setTickSpacing()
                self.plot.enableAutoRange(axis="y",enable=True)
            else:
                self.plot.enableAutoRange(axis="y",enable=False)
                self.plot.setYRange(*y_limits,padding=0)
                self.plot.getAxis("left").setTickSpacing(major=frame.scale_div,minor=frame.scale_div)
            self._plot_range=limits
        typ={"WRIT":"Clear/Write","MAXH":"Max Hold","MINH":"Min Hold","AVER":"Average"}.get((frame.trace_type or "").upper(),frame.trace_type or "тип не прочитан")
        display="видна на приборе" if frame.display_on is True else ("скрыта на приборе" if frame.display_on is False else "видимость не прочитана")
        update="обновляется" if frame.update_on is True else ("обновление выключено" if frame.update_on is False else "Update не прочитан")
        peak=int(frame.y.argmax())
        details=f"{frame.mode}/{frame.view} · Trace {frame.trace} · {typ} · {display} · {update} · {frame.y.size} точек"
        details+=f"\nCenter {frame.center_hz/1e6:g} MHz · Span {frame.span_hz/1e6:g} MHz · Макс. {frame.x[peak]:g} {frame.x_unit}: {frame.y[peak]:.2f} {frame.y_unit}"
        details+=(f"\nШкала Rigol: Ref {frame.ref_level:g} dBm · {frame.scale_div:g} dB/div" if y_limits is not None else "\nАвтомасштаб Y по данным")
        if frame.warnings:
            details+="\n"+" · ".join(frame.warnings)
        details+="\nТип, Display/Update и шкала — по последнему опросу управления."
        if frame.mode=="RTSA" and frame.view in ("DENS","DSPE"):
            details+=" · Показана Trace 1; карта Density не передаётся этим графиком."
        self.live_status.setText(details)
        self.live_status.setToolTip(details)
        self.diagnostic_save.setEnabled(True)
        if self.status.text() in ("Не подключен", "Нет связи. Нажмите «Подключить»."):
            self.status.setText(self.rigol.idn or "Подключен")

    def showEvent(self,e):
        super().showEvent(e)
        self.live_reader.set_active(True)

    def hideEvent(self,e):
        self.live_reader.set_active(False)
        super().hideEvent(e)

    def done(self, result):
        self.live_reader.close()
        super().done(result)

    def closeEvent(self,e):
        self.live_reader.close(); super().closeEvent(e)


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, controller: SewerController):
        super().__init__(); self.c=controller; self.rigol_dialog=None
        self.setWindowTitle("Sewer-P")
        self.resize(1040,640); self.setMinimumSize(1040,640)
        icon=controller.root/"Resources/Hedgehog.png"
        if icon.exists(): self.setWindowIcon(QtGui.QIcon(str(icon)))
        set_current_theme(theme_from_config(controller.config))
        self._style(); self._build(); self._shortcuts()
        controller.log_line.connect(self.append_log); controller.updated.connect(self.refresh)
        self.refresh()

    def _style(self):
        set_theme_style(self, '''
            QWidget{background:#171c24;color:#e5ebef;font-family:"Segoe UI";font-size:12px;}
            QMainWindow,QDialog{background:#171c24;}
            QFrame#InstrumentCard{background:#222a35;border:1px solid #3b4959;border-radius:5px;}
            QFrame#MeasurementCell{background:#19212b;border:1px solid #344253;border-radius:4px;}
            QGroupBox{background:#222a35;border:1px solid #343d46;border-radius:4px;margin-top:10px;padding-top:8px;font-weight:600;}
            QGroupBox::title{subcontrol-origin:margin;left:12px;padding:0 5px;color:#b9c6d0;}
            QLabel{background:transparent;}
            QTabWidget::pane{border:1px solid #343d46;border-radius:4px;}
            QTabBar::tab{background:#252e36;color:#aebdc8;border:1px solid #343d46;padding:8px 12px;}
            QTabBar::tab:selected{background:#243b54;color:#e5ebef;border-bottom:2px solid #399ce8;}
            QCheckBox{background:transparent;spacing:7px;}
            QPushButton{background:#2c353e;border:1px solid #414e59;border-radius:4px;padding:8px 10px;}
            QPushButton:hover{background:#36434e;border-color:#657b89;}
            QPushButton:pressed{background:#202a32;}
            QPushButton:focus{border-color:#399ce8;}
            QPushButton:disabled{color:#85909a;background:#252d34;border-color:#343d46;}
            QPushButton#StartButton{background:#1769b3;border-color:#348cd9;}
            QPushButton#StartButton:hover{background:#227dc9;}
            QPushButton#StartButton:disabled{background:#243447;border-color:#3a4c61;}
            QPushButton#StopButton{border-color:#785050;}
            QPushButton#StopButton:hover{background:#493236;}
            QLineEdit,QSpinBox,QDoubleSpinBox,QComboBox{background:#252e36;border:1px solid #46535f;border-radius:5px;padding:5px;selection-background-color:#1769b3;}
            QPlainTextEdit{background:#171d23;border:1px solid #303b45;border-radius:4px;padding:7px;font-family:Consolas;color:#c4d2dd;}
            QProgressBar{min-height:24px;border:1px solid #3c4954;border-radius:6px;background:#182128;text-align:center;color:#e5ebef;}
            QProgressBar::chunk{background:#1769b3;border-radius:5px;}
        ''')

    def _build(self):
        cw=QtWidgets.QWidget(); self.setCentralWidget(cw); root=QtWidgets.QVBoxLayout(cw); root.setContentsMargins(12,10,12,10); root.setSpacing(8)
        header=QtWidgets.QHBoxLayout(); root.addLayout(header)
        t=QtWidgets.QLabel('<span style="color:#73cfa6;">S</span>ewer-<span style="color:#399ce8;">P</span>'); set_theme_style(t, "font-size:32px;font-weight:700;color:#f0f5f8;"); header.addWidget(t)
        self.theme_header=ThemeHeader(); header.addWidget(self.theme_header)
        header.addStretch(1)
        self.badge_com=StatusBadge("COM"); self.badge_fw=StatusBadge("FW"); self.badge_prg=StatusBadge("PRG"); self.badge_rig=StatusBadge("RIG")
        self.settings_btn=QtWidgets.QPushButton()
        self.settings_btn.setFixedSize(68,50)
        self.settings_btn.setIconSize(QtCore.QSize(60,44))
        self.settings_btn.setToolTip("Настройки")
        self.settings_btn.setAccessibleName("Настройки")
        self.settings_btn.setCursor(QtCore.Qt.PointingHandCursor)
        set_theme_style(self.settings_btn, "QPushButton,QPushButton:hover,QPushButton:pressed,QPushButton:focus{background:transparent;border:none;padding:2px;}")
        mascot=self.c.root/"Resources/Hedgehog.png"
        if mascot.exists(): self.settings_btn.setIcon(QtGui.QIcon(str(mascot)))
        else: self.settings_btn.setText("Настройки")
        self.settings_btn.clicked.connect(self.open_settings)
        header.addWidget(self.settings_btn)

        body=QtWidgets.QHBoxLayout(); body.setSpacing(12); root.addLayout(body)
        cards=QtWidgets.QGridLayout(); cards.setSpacing(8); cards.setColumnStretch(0,1); cards.setColumnStretch(1,1); body.addLayout(cards,1)
        self.card_ps=MetricCard("Источник питания"); self.ps_v=self.card_ps.add_metric(1,"Огр. напряжения"); self.ps_i=self.card_ps.add_metric(2,"Огр. тока"); cards.addWidget(self.card_ps,0,0)
        self.card_out=MetricCard("Состояние выхода"); self.out_v=self.card_out.add_metric(1,"Напряжение"); self.out_i=self.card_out.add_metric(2,"Ток"); cards.addWidget(self.card_out,0,1)
        self.card_prg=MetricCard("Программатор"); self.card_prg.grid.setRowStretch(1,1); self.progress=QtWidgets.QProgressBar(); self.progress.setRange(0,100); set_theme_style(self.progress, "min-height:34px;max-height:34px;"); self.progress.setFixedHeight(36); self.card_prg.grid.addWidget(self.progress,2,0,1,2); cards.addWidget(self.card_prg,1,0)
        self.card_rig=MetricCard("Rigol"); self.rig_mode=self.card_rig.add_metric(1,"Режим"); rig_buttons=QtWidgets.QHBoxLayout(); rig_buttons.setSpacing(8); self.rig_mode_btn=QtWidgets.QPushButton("Режим"); self.rig_mode_btn.setFixedHeight(36); self.rig_mode_btn.setToolTip("GPSA ↔ RTSA · Alt+Пробел"); self.rig_mode_btn.clicked.connect(self.c.switch_rigol_mode); self.rig_control_btn=QtWidgets.QPushButton("Управление"); self.rig_control_btn.setFixedHeight(36); self.rig_control_btn.clicked.connect(self.open_rigol); rig_buttons.addWidget(self.rig_mode_btn); rig_buttons.addWidget(self.rig_control_btn); self.card_rig.grid.addLayout(rig_buttons,2,0,1,2); cards.addWidget(self.card_rig,1,1)

        bottom_widget=QtWidgets.QWidget(); bottom_widget.setFixedHeight(192); root.addWidget(bottom_widget)
        bottom=QtWidgets.QHBoxLayout(bottom_widget); bottom.setContentsMargins(0,0,0,0)
        logbox=QtWidgets.QFrame(); logbox.setObjectName("InstrumentCard"); ll=QtWidgets.QVBoxLayout(logbox); ll.setContentsMargins(12,12,12,12); ll.setSpacing(8); log_title=QtWidgets.QLabel("Журнал событий"); set_theme_style(log_title, "font-size:14px;font-weight:600;color:#cfdeeb;"); ll.addWidget(log_title); self.log=QtWidgets.QPlainTextEdit(); self.log.setReadOnly(True); self.log.document().setMaximumBlockCount(3000); ll.addWidget(self.log); bottom.addWidget(logbox,1)
        side=QtWidgets.QVBoxLayout(); side.setSpacing(8); bottom.setSpacing(8); bottom.addLayout(side)
        self.start_btn=ActionButton("Старт", "Enter", "▶"); self.start_btn.setObjectName("StartButton")
        self.repeat_btn=ActionButton("Повторить", "Пробел", "↻")
        self.stop_btn=ActionButton("Стоп", "Esc", "■"); self.stop_btn.setObjectName("StopButton")
        self.exit_btn=ActionButton("Выход", "Alt+X", "→")
        for b in (self.start_btn,self.repeat_btn,self.stop_btn,self.exit_btn): b.setFixedSize(235,42); side.addWidget(b)
        self.start_btn.clicked.connect(self.c.start_cycle); self.repeat_btn.clicked.connect(self.c.start_cycle); self.stop_btn.clicked.connect(self.c.stop_cycle); self.exit_btn.clicked.connect(self.close)
        footer_row=QtWidgets.QHBoxLayout(); footer_row.setSpacing(6); root.addLayout(footer_row)
        for badge in (self.badge_com,self.badge_fw,self.badge_prg,self.badge_rig):
            badge.setFixedSize(28,28); footer_row.addWidget(badge)
        footer_row.addSpacing(6)
        self.footer=QtWidgets.QLabel("Инициализация"); set_theme_style(self.footer, "color:#a6b5c1;padding-top:3px;"); footer_row.addWidget(self.footer,1)
        self.runtime=QtWidgets.QLabel("00:00:00"); self.runtime.setToolTip("Время работы Sewer-P"); footer_row.addWidget(self.runtime)
        footer_row.addSpacing(20); footer_row.addWidget(QtWidgets.QLabel("Успешных плат:"))
        self.success=QtWidgets.QLabel("0"); set_theme_style(self.success, "color:#73cfa6;font-weight:700;"); footer_row.addWidget(self.success)
        self.runtime_timer=QtCore.QTimer(self); self.runtime_timer.setInterval(1000); self.runtime_timer.timeout.connect(self.refresh_runtime); self.runtime_timer.start()

    def _shortcuts(self):
        for key, fn in (("Return",lambda:self.c.start_cycle() if self.start_btn.isEnabled() else None),("Space",lambda:self.c.start_cycle() if self.repeat_btn.isEnabled() else None),("Esc",self.c.stop_cycle),("Alt+X",self.close),("Alt+Space",self.c.switch_rigol_mode)):
            q=QtGui.QShortcut(QtGui.QKeySequence(key),self); q.activated.connect(fn)

    def append_log(self, line: str):
        self.log.appendPlainText(line); bar=self.log.verticalScrollBar(); bar.setValue(bar.maximum())

    def refresh_runtime(self):
        s=int(time.monotonic()-self.c.started_at); self.runtime.setText(f"{s//3600:02d}:{(s%3600)//60:02d}:{s%60:02d}")

    def refresh(self):
        cfg=self.c.config; ps=cfg["PowerSupply"]; snap=self.c.power.snapshot
        self.badge_com.set_status(str(ps.get("Port","COM")), snap.com_available and snap.responding)
        _,fw,_=self.c.programmer.paths(); self.badge_fw.set_status("ГОТОВ" if fw.is_file() else "НЕ ГОТОВ",fw.is_file())
        err=self.c.programmer.configuration_error(); self.badge_prg.set_status("ГОТОВ" if not err else "НЕ ГОТОВ",not bool(err))
        self.badge_rig.set_status(self.c.rigol_mode if self.c.rigol_connected else "НЕ ГОТОВ",self.c.rigol_connected)
        if self.c.rigol_error:
            self.badge_rig.setToolTip("Rigol: "+self.c.rigol_error)
        self.card_rig.setToolTip(self.c.rigol_error or self.c.rigol.idn)
        self.card_ps.set_status("ПОДКЛЮЧЕН" if snap.responding else "НЕ ПОДКЛЮЧЕН",snap.responding)
        self.ps_v.setText(f"{float(ps.get('Voltage',0)):.2f} В"); self.ps_i.setText(f"{float(ps.get('CurrentLimit',0)):.3f} А")
        self.card_out.set_status("ВКЛЮЧЕН" if snap.output_on else "ВЫКЛЮЧЕН",True if snap.output_on else False)
        self.out_v.setText(f"{snap.voltage:.2f} В"); self.out_i.setText(f"{snap.current*1000:.1f} мА")
        pst=self.c.progress_state; self.card_prg.set_status("Готов" if not err else "Не готов", not bool(err))
        self.progress.setValue(int(self.c.programmer.progress))
        self.card_rig.set_status("ПОДКЛЮЧЕН" if self.c.rigol_connected else "НЕТ СВЯЗИ",self.c.rigol_connected); self.rig_mode.setText(self.c.rigol_mode)
        self.rig_mode_btn.setEnabled(self.c.rigol_connected); self.rig_control_btn.setEnabled(True)
        idle=self.c.state=="Idle"; self.start_btn.setEnabled(idle and self.c.ready); self.repeat_btn.setEnabled(idle and self.c.ready and self.c.can_repeat); self.stop_btn.setEnabled(not idle or self.c._busy); self.settings_btn.setEnabled(idle)
        self.success.setText(str(self.c.successful_boards)); self.footer.setText("Готов к работе" if self.c.ready else f"Не готов: {self.c.readiness_reason}")

    def apply_theme(self, key):
        set_current_theme(normalize_theme(key))
        apply_widget_theme(self)
        if self.rigol_dialog is not None:
            self.rigol_dialog.apply_plot_theme()

    def open_settings(self):
        if self.c.state!="Idle": return
        dlg=SettingsDialog(clone_config(self.c.config),self)
        original_controls=dlg.controls_snapshot()
        dlg.theme_preview.connect(self.apply_theme)
        try:
            if dlg.exec()==QtWidgets.QDialog.Accepted:
                updated=dlg.result_config()
                if dlg.controls_snapshot()==original_controls:
                    # Appearance-only saves do not stop or reconfigure instruments.
                    updated=clone_config(self.c.config)
                    updated.setdefault("Application",{})["Theme"]=dlg.selected_theme
                    self.c.config=save_config(updated,self.c.config_path)
                    self.c.updated.emit()
                else:
                    self.c.apply_config(updated)
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self,"Настройки Sewer",f"Не удалось сохранить настройки.\n\n{exc}")
        finally:
            self.apply_theme(theme_from_config(self.c.config))
            dlg.deleteLater()

    def open_rigol(self):
        if self.rigol_dialog is None:
            self.rigol_dialog=RigolControlDialog(self.c,self); self.rigol_dialog.finished.connect(lambda _:setattr(self,'rigol_dialog',None))
        self.rigol_dialog.show(); self.rigol_dialog.raise_(); self.rigol_dialog.activateWindow()
        if self.c.rigol.connected:
            try: self.rigol_dialog.refresh_all()
            except Exception as e: self.rigol_dialog.status.setText(str(e))
        else:
            self.rigol_dialog.status.setText(self.c.rigol_error or self.c.rigol.last_error or "Нет связи. Нажмите «Подключить».")

    def closeEvent(self,e):
        if self.rigol_dialog is not None:
            self.rigol_dialog.close()
        self.runtime_timer.stop(); self.c.close(); super().closeEvent(e)
