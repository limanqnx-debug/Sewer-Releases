from __future__ import annotations

import time
from pathlib import Path

from PySide6 import QtCore, QtGui, QtWidgets
import pyqtgraph as pg

from .config import clone_config
from .controller import SewerController
from .settings import SettingsDialog

BW = [
    ("1 Hz",1),("3 Hz",3),("10 Hz",10),("30 Hz",30),("100 Hz",100),("300 Hz",300),
    ("1 kHz",1e3),("3 kHz",3e3),("10 kHz",1e4),("30 kHz",3e4),("100 kHz",1e5),
    ("300 kHz",3e5),("1 MHz",1e6),("3 MHz",3e6),("10 MHz",1e7),
]


class ReverseWheelCombo(QtWidgets.QComboBox):
    def wheelEvent(self, event):
        if not self.isEnabled() or self.count() == 0:
            event.ignore(); return
        delta = event.angleDelta().y()
        if delta == 0:
            event.ignore(); return
        step = 1 if delta > 0 else -1
        self.setCurrentIndex(max(0, min(self.count()-1, self.currentIndex()+step)))
        event.accept()


class StatusBadge(QtWidgets.QFrame):
    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.setObjectName("StatusBadge")
        lay=QtWidgets.QVBoxLayout(self); lay.setContentsMargins(10,5,10,5); lay.setSpacing(0)
        self.title=QtWidgets.QLabel(title); self.title.setStyleSheet("font-size:10px;color:#9aa3ab;")
        self.value=QtWidgets.QLabel("—"); self.value.setStyleSheet("font-size:13px;font-weight:700;color:#d6d9dc;")
        lay.addWidget(self.title); lay.addWidget(self.value)

    def set_status(self, text: str, ok: bool | None):
        self.value.setText(text)
        color = "#5bd66f" if ok is True else "#ff6262" if ok is False else "#d6d9dc"
        self.value.setStyleSheet(f"font-size:13px;font-weight:700;color:{color};")


class MetricCard(QtWidgets.QGroupBox):
    def __init__(self, title: str, parent=None):
        super().__init__(title, parent)
        self.setMinimumHeight(185)
        self.grid=QtWidgets.QGridLayout(self); self.grid.setContentsMargins(14,18,14,14); self.grid.setVerticalSpacing(9)
        self.status=QtWidgets.QLabel("—"); self.status.setStyleSheet("font-size:14px;font-weight:700;")
        self.grid.addWidget(self.status,0,0,1,2)
        self.rows={}

    def add_metric(self, row: int, label: str):
        l=QtWidgets.QLabel(label); l.setStyleSheet("color:#aeb5bb;")
        v=QtWidgets.QLabel("—"); v.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignVCenter); v.setStyleSheet("font-size:20px;font-weight:700;")
        self.grid.addWidget(l,row,0); self.grid.addWidget(v,row,1); self.rows[label]=v; return v

    def set_status(self, text: str, ok: bool | None):
        self.status.setText(text)
        color = "#5bd66f" if ok is True else "#ff6262" if ok is False else "#f0c95b"
        self.status.setStyleSheet(f"font-size:14px;font-weight:700;color:{color};")


class RigolControlDialog(QtWidgets.QDialog):
    def __init__(self, controller: SewerController, parent=None):
        super().__init__(parent)
        self.controller=controller; self.rigol=controller.rigol
        self.setWindowTitle("Rigol — управление")
        self.resize(1260,780)
        self.setModal(False)
        self.live_timer=QtCore.QTimer(self)
        self.live_timer.setInterval(int(controller.config.get("Rigol",{}).get("LiveIntervalMs",300)))
        self.live_timer.timeout.connect(self.refresh_live)
        self._build()

    def _build(self):
        root=QtWidgets.QVBoxLayout(self)
        top=QtWidgets.QHBoxLayout(); root.addLayout(top)
        self.resource=QtWidgets.QLineEdit(self.controller.config.get("Rigol",{}).get("Resource","")); top.addWidget(self.resource,1)
        b=QtWidgets.QPushButton("Подключить"); b.clicked.connect(self.connect_rigol); top.addWidget(b)
        self.mode=QtWidgets.QComboBox(); self.mode.addItems(["GPSA","RTSA"]); top.addWidget(self.mode)
        bm=QtWidgets.QPushButton("Режим"); bm.clicked.connect(self.apply_mode); top.addWidget(bm)
        self.status=QtWidgets.QLabel("Не подключен"); top.addWidget(self.status)

        body=QtWidgets.QHBoxLayout(); root.addLayout(body,1)
        left=QtWidgets.QVBoxLayout(); body.addLayout(left,0)

        self.center=self._dspin(0,6500,1,0," MHz")
        self.span=self._dspin(0,6500,1,0," MHz")
        left.addWidget(self._group("Frequency",[("Center",self.center,self.apply_center),("Span",self.span,self.apply_span)]))

        self.ref=self._dspin(-99,99,1,1," dBm")
        self.off=self._dspin(-300,300,1,1," dB")
        self.scale=QtWidgets.QSpinBox(); self.scale.setRange(1,20); self.scale.setSingleStep(1); self.scale.setSuffix(" dB/div"); self.scale.setKeyboardTracking(False)
        self.att=self._dspin(0,70,1,0," dB")
        left.addWidget(self._group("Amplitude",[("Ref Level",self.ref,self.apply_ref),("Ref Offset",self.off,self.apply_off),("Scale/Div",self.scale,self.apply_scale),("Attenuation",self.att,self.apply_att)]))

        gbw=QtWidgets.QGroupBox("BW"); gl=QtWidgets.QGridLayout(gbw)
        self.rbw=ReverseWheelCombo(); self.vbw=ReverseWheelCombo()
        for n,v in BW: self.rbw.addItem(n,v); self.vbw.addItem(n,v)
        self.rbwa=QtWidgets.QCheckBox("Auto"); self.vbwa=QtWidgets.QCheckBox("Auto")
        gl.addWidget(QtWidgets.QLabel("RBW"),0,0); gl.addWidget(self.rbw,0,1); gl.addWidget(self.rbwa,0,2)
        gl.addWidget(QtWidgets.QLabel("VBW"),1,0); gl.addWidget(self.vbw,1,1); gl.addWidget(self.vbwa,1,2)
        br=QtWidgets.QPushButton("Применить BW"); br.clicked.connect(self.apply_bw); gl.addWidget(br,2,0,1,3)
        left.addWidget(gbw)

        gs=QtWidgets.QGroupBox("Sweep"); sl=QtWidgets.QGridLayout(gs)
        self.sweept=self._dspin(1,4000000,1,0," ms"); self.sweepa=QtWidgets.QCheckBox("Auto")
        self.points=QtWidgets.QSpinBox(); self.points.setRange(101,10001); self.points.setSingleStep(1)
        bc=QtWidgets.QPushButton("Continuous"); bc.clicked.connect(lambda:self._safe(lambda:self.rigol.continuous(True)))
        bs=QtWidgets.QPushButton("Single"); bs.clicked.connect(lambda:self._safe(self.rigol.single))
        sl.addWidget(bc,0,0); sl.addWidget(bs,0,1)
        sl.addWidget(QtWidgets.QLabel("Sweep Time"),1,0); sl.addWidget(self.sweept,1,1); sl.addWidget(self.sweepa,1,2)
        sl.addWidget(QtWidgets.QLabel("Points"),2,0); sl.addWidget(self.points,2,1)
        ba=QtWidgets.QPushButton("Применить Sweep"); ba.clicked.connect(self.apply_sweep); sl.addWidget(ba,3,0,1,3)
        left.addWidget(gs)

        gt=QtWidgets.QGroupBox("Trace"); tl=QtWidgets.QGridLayout(gt)
        self.tr=QtWidgets.QComboBox(); self.tr.addItems([str(i) for i in range(1,7)])
        tl.addWidget(QtWidgets.QLabel("Trace"),0,0); tl.addWidget(self.tr,0,1)
        for i,(txt,typ) in enumerate([("Clear/Write","WRITe"),("Max Hold","MAXHold"),("Average","AVERage"),("Min Hold","MINHold")]):
            b=QtWidgets.QPushButton(txt); b.clicked.connect(lambda _,t=typ:self.set_trace(t)); tl.addWidget(b,1+i//2,i%2)
        self.live=QtWidgets.QCheckBox(f"Live {self.live_timer.interval()} ms")
        self.live.toggled.connect(lambda on:self.live_timer.start() if on else self.live_timer.stop())
        tl.addWidget(self.live,3,0,1,2); left.addWidget(gt); left.addStretch()

        self.plot=pg.PlotWidget(); body.addWidget(self.plot,1)
        self.curve=self.plot.plot(); self.plot.showGrid(x=True,y=True)
        self.plot.setLabel("bottom","Frequency","MHz"); self.plot.setLabel("left","Level","dBm")

    def _dspin(self,a,b,step,dec,suffix):
        x=QtWidgets.QDoubleSpinBox(); x.setRange(a,b); x.setSingleStep(step); x.setDecimals(dec); x.setSuffix(suffix); x.setKeyboardTracking(False); return x

    def _group(self,title,rows):
        g=QtWidgets.QGroupBox(title); l=QtWidgets.QGridLayout(g)
        for r,(name,w,fn) in enumerate(rows):
            l.addWidget(QtWidgets.QLabel(name),r,0); l.addWidget(w,r,1)
            b=QtWidgets.QPushButton("Set"); b.clicked.connect(fn); l.addWidget(b,r,2)
            if hasattr(w,"editingFinished"): w.editingFinished.connect(fn)
        return g

    def _safe(self, fn):
        try: fn(); self.status.setText("OK")
        except Exception as e: self.status.setText(str(e))

    def connect_rigol(self):
        def f():
            self.rigol.reconfigure(self.resource.text().strip(), int(self.controller.config.get("Rigol",{}).get("TimeoutMs",2500)))
            idn=self.rigol.connect(); self.controller.rigol_connected=True; self.controller.rigol_mode=self.rigol.mode(); self.status.setText(idn); self.refresh_all(); self.controller.updated.emit()
        self._safe(f)

    def refresh_all(self):
        self.mode.setCurrentText(self.rigol.mode())
        self.center.setValue(self.rigol.center_hz()/1e6); self.span.setValue(self.rigol.span_hz()/1e6)
        self.ref.setValue(self.rigol.ref_level()); self.off.setValue(self.rigol.ref_offset())
        self.scale.setValue(int(round(self.rigol.scale_div()))); self.att.setValue(self.rigol.attenuation())
        self.sweept.setValue(self.rigol.sweep_time()*1000); self.points.setValue(self.rigol.sweep_points())
        for combo,val in ((self.rbw,self.rigol.rbw()),(self.vbw,self.rigol.vbw())):
            idx=min(range(combo.count()), key=lambda i:abs(combo.itemData(i)-val)); combo.setCurrentIndex(idx)

    def apply_mode(self): self._safe(lambda:self.rigol.set_mode(self.mode.currentText()))
    def apply_center(self): self._safe(lambda:self.rigol.set_center_hz(self.center.value()*1e6))
    def apply_span(self): self._safe(lambda:self.rigol.set_span_hz(self.span.value()*1e6))
    def apply_ref(self): self._safe(lambda:self.rigol.set_ref_level(self.ref.value()))
    def apply_off(self): self._safe(lambda:self.rigol.set_ref_offset(self.off.value()))
    def apply_scale(self): self._safe(lambda:self.rigol.set_scale_div(self.scale.value()))
    def apply_att(self): self._safe(lambda:self.rigol.set_attenuation(self.att.value()))
    def apply_bw(self):
        def f():
            self.rigol.set_rbw_auto(self.rbwa.isChecked()); self.rigol.set_vbw_auto(self.vbwa.isChecked())
            if not self.rbwa.isChecked(): self.rigol.set_rbw(self.rbw.currentData())
            if not self.vbwa.isChecked(): self.rigol.set_vbw(self.vbw.currentData())
        self._safe(f)
    def apply_sweep(self):
        def f():
            self.rigol.set_sweep_time_auto(self.sweepa.isChecked())
            if not self.sweepa.isChecked(): self.rigol.set_sweep_time(self.sweept.value()/1000)
            self.rigol.set_sweep_points(self.points.value())
        self._safe(f)
    def set_trace(self,t): self._safe(lambda:self.rigol.set_trace_type(int(self.tr.currentText()),t))

    def refresh_live(self):
        if not self.rigol.connected: return
        try:
            y=self.rigol.trace_ascii(int(self.tr.currentText()))
            if y.size<2: return
            c=self.rigol.center_hz()/1e6; s=self.rigol.span_hz()/1e6
            x=[c-s/2+i*s/(len(y)-1) for i in range(len(y))]
            self.curve.setData(x,y); self.status.setText(f"Live: {len(y)} точек")
        except Exception as e: self.status.setText("Live error: "+str(e))

    def closeEvent(self,e):
        self.live_timer.stop(); super().closeEvent(e)


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, controller: SewerController):
        super().__init__(); self.c=controller; self.rigol_dialog=None
        self.setWindowTitle("Sewer — Python DEV2 Full")
        self.resize(1120,690); self.setMinimumSize(960,540)
        icon=controller.root/"Resources/Hedgehog.png"
        if icon.exists(): self.setWindowIcon(QtGui.QIcon(str(icon)))
        self._style(); self._build(); self._shortcuts()
        controller.log_line.connect(self.append_log); controller.updated.connect(self.refresh)
        self.refresh()

    def _style(self):
        self.setStyleSheet('''
            QMainWindow,QDialog,QWidget{background:#17191c;color:#e8eaed;font-family:"Segoe UI";font-size:12px;}
            QGroupBox{border:1px solid #363b40;border-radius:8px;margin-top:10px;padding-top:8px;font-weight:700;}
            QGroupBox::title{subcontrol-origin:margin;left:10px;padding:0 4px;color:#dce1e5;}
            QPushButton{background:#2a2e33;border:1px solid #41474e;border-radius:6px;padding:8px 12px;}
            QPushButton:hover{background:#343941;} QPushButton:disabled{color:#70777e;background:#24272b;}
            QLineEdit,QSpinBox,QDoubleSpinBox,QComboBox{background:#22262a;border:1px solid #41474e;border-radius:5px;padding:5px;}
            QPlainTextEdit{background:#0f1113;border:1px solid #34393e;border-radius:6px;font-family:Consolas;color:#dce1e5;}
            QProgressBar{border:1px solid #41474e;border-radius:5px;background:#202327;text-align:center;}
            QProgressBar::chunk{background:#4fbd68;border-radius:4px;}
            #StatusBadge{background:#202327;border:1px solid #33383e;border-radius:7px;}
        ''')

    def _build(self):
        cw=QtWidgets.QWidget(); self.setCentralWidget(cw); root=QtWidgets.QVBoxLayout(cw); root.setContentsMargins(12,10,12,10); root.setSpacing(9)
        header=QtWidgets.QHBoxLayout(); root.addLayout(header)
        titlebox=QtWidgets.QVBoxLayout(); t=QtWidgets.QLabel("Sewer"); t.setStyleSheet("font-size:27px;font-weight:800;"); sub=QtWidgets.QLabel("Python production tool"); sub.setStyleSheet("color:#7f8992;"); titlebox.addWidget(t); titlebox.addWidget(sub); header.addLayout(titlebox)
        header.addStretch(1)
        self.badge_com=StatusBadge("COM"); self.badge_fw=StatusBadge("FW"); self.badge_prg=StatusBadge("PRG"); self.badge_rig=StatusBadge("RIG")
        for b in (self.badge_com,self.badge_fw,self.badge_prg,self.badge_rig): header.addWidget(b)
        self.settings_btn=QtWidgets.QPushButton("⚙"); self.settings_btn.setFixedSize(44,44); self.settings_btn.clicked.connect(self.open_settings); header.addWidget(self.settings_btn)
        mascot=self.c.root/"Resources/Hedgehog.png"
        if mascot.exists():
            lab=QtWidgets.QLabel(); pix=QtGui.QPixmap(str(mascot)); lab.setPixmap(pix.scaled(68,58,QtCore.Qt.KeepAspectRatio,QtCore.Qt.SmoothTransformation)); header.addWidget(lab)

        cards=QtWidgets.QHBoxLayout(); root.addLayout(cards)
        self.card_ps=MetricCard("ИСТОЧНИК ПИТАНИЯ"); self.ps_v=self.card_ps.add_metric(1,"Огр. напряжения"); self.ps_i=self.card_ps.add_metric(2,"Огр. тока"); cards.addWidget(self.card_ps,1)
        self.card_out=MetricCard("СОСТОЯНИЕ ВЫХОДА"); self.out_v=self.card_out.add_metric(1,"Напряжение"); self.out_i=self.card_out.add_metric(2,"Ток"); cards.addWidget(self.card_out,1)
        self.card_prg=MetricCard("PROGRAMMER"); self.prg_text=self.card_prg.add_metric(1,"Прогресс"); self.progress=QtWidgets.QProgressBar(); self.progress.setRange(0,100); self.card_prg.grid.addWidget(self.progress,2,0,1,2); cards.addWidget(self.card_prg,1)
        self.card_rig=MetricCard("Rigol"); self.rig_mode=self.card_rig.add_metric(1,"Режим"); rig_buttons=QtWidgets.QHBoxLayout(); self.rig_mode_btn=QtWidgets.QPushButton("Режим"); self.rig_mode_btn.clicked.connect(self.c.switch_rigol_mode); self.rig_control_btn=QtWidgets.QPushButton("Управление"); self.rig_control_btn.clicked.connect(self.open_rigol); rig_buttons.addWidget(self.rig_mode_btn); rig_buttons.addWidget(self.rig_control_btn); self.card_rig.grid.addLayout(rig_buttons,2,0,1,2); cards.addWidget(self.card_rig,1)

        bottom=QtWidgets.QHBoxLayout(); root.addLayout(bottom,1)
        logbox=QtWidgets.QGroupBox("ЖУРНАЛ СОБЫТИЙ"); ll=QtWidgets.QVBoxLayout(logbox); self.log=QtWidgets.QPlainTextEdit(); self.log.setReadOnly(True); self.log.document().setMaximumBlockCount(3000); ll.addWidget(self.log); bottom.addWidget(logbox,1)
        side=QtWidgets.QVBoxLayout(); bottom.addLayout(side)
        self.start_btn=QtWidgets.QPushButton("▶  Старт     Enter"); self.repeat_btn=QtWidgets.QPushButton("↻  Повторить     Пробел"); self.stop_btn=QtWidgets.QPushButton("■  Стоп     Esc"); self.exit_btn=QtWidgets.QPushButton("Выход     Alt+X")
        self.start_btn.setStyleSheet("QPushButton{background:#2f8f45;font-weight:700;padding:12px;} QPushButton:disabled{background:#263229;color:#68736c;}")
        self.stop_btn.setStyleSheet("QPushButton{color:#ff6b6b;font-weight:700;padding:12px;}")
        for b in (self.start_btn,self.repeat_btn,self.stop_btn,self.exit_btn): b.setMinimumWidth(205); side.addWidget(b)
        self.start_btn.clicked.connect(self.c.start_cycle); self.repeat_btn.clicked.connect(self.c.start_cycle); self.stop_btn.clicked.connect(self.c.stop_cycle); self.exit_btn.clicked.connect(self.close)
        stats=QtWidgets.QGroupBox("СТАТИСТИКА"); sg=QtWidgets.QFormLayout(stats); self.success=QtWidgets.QLabel("0"); self.runtime=QtWidgets.QLabel("00:00:00"); sg.addRow("Успешно",self.success); sg.addRow("Время работы",self.runtime); side.addWidget(stats); side.addStretch()
        self.footer=QtWidgets.QLabel("Инициализация"); root.addWidget(self.footer)
        self.runtime_timer=QtCore.QTimer(self); self.runtime_timer.setInterval(1000); self.runtime_timer.timeout.connect(self.refresh_runtime); self.runtime_timer.start()

    def _shortcuts(self):
        for key, fn in (("Return",lambda:self.c.start_cycle() if self.start_btn.isEnabled() else None),("Space",lambda:self.c.start_cycle() if self.repeat_btn.isEnabled() else None),("Esc",self.c.stop_cycle),("Alt+X",self.close),("Alt+Space",self.c.switch_rigol_mode)):
            q=QtGui.QShortcut(QtGui.QKeySequence(key),self); q.activated.connect(fn)

    def append_log(self, line: str):
        self.log.appendPlainText(line); bar=self.log.verticalScrollBar(); bar.setValue(bar.maximum())

    def refresh_runtime(self):
        s=int(time.monotonic()-self.c.started_at); self.runtime.setText(f"{s//3600:02d}:{(s%3600)//60:02d}:{s%60:02d}")

    def refresh(self):
        cfg=self.c.config; ps=cfg["PowerSupply"]; snap=self.c.power.snapshot
        self.badge_com.set_status(str(ps.get("Port","COM")), snap.com_available and snap.responding)
        _,fw,_=self.c.programmer.paths(); self.badge_fw.set_status("ГОТОВ" if fw.is_file() else "НЕ ГОТОВ",fw.is_file())
        err=self.c.programmer.configuration_error(); self.badge_prg.set_status("ГОТОВ" if not err else "НЕ ГОТОВ",not bool(err))
        self.badge_rig.set_status(self.c.rigol_mode if self.c.rigol_connected else "НЕ ГОТОВ",self.c.rigol_connected)
        self.card_ps.set_status("ПОДКЛЮЧЕН" if snap.responding else "НЕ ПОДКЛЮЧЕН",snap.responding)
        self.ps_v.setText(f"{float(ps.get('Voltage',0)):.2f} В"); self.ps_i.setText(f"{float(ps.get('CurrentLimit',0)):.3f} А")
        self.card_out.set_status("ВКЛЮЧЕН" if snap.output_on else "ВЫКЛЮЧЕН",True if snap.output_on else False)
        self.out_v.setText(f"{snap.voltage:.2f} В"); self.out_i.setText(f"{snap.current*1000:.1f} мА")
        pst=self.c.progress_state; self.card_prg.set_status(self.c.status_text, True if pst=="Success" else False if pst=="Error" else None)
        self.progress.setValue(int(self.c.programmer.progress)); self.prg_text.setText(f"{int(self.c.programmer.progress)} %")
        self.card_rig.set_status("ПОДКЛЮЧЕН" if self.c.rigol_connected else "НЕТ СВЯЗИ",self.c.rigol_connected); self.rig_mode.setText(self.c.rigol_mode)
        self.rig_mode_btn.setEnabled(self.c.rigol_connected); self.rig_control_btn.setEnabled(True)
        idle=self.c.state=="Idle"; self.start_btn.setEnabled(idle and self.c.ready); self.repeat_btn.setEnabled(idle and self.c.ready and self.c.can_repeat); self.stop_btn.setEnabled(not idle or self.c._busy); self.settings_btn.setEnabled(idle)
        self.success.setText(str(self.c.successful_boards)); self.footer.setText("Готов к работе" if self.c.ready else f"Не готов: {self.c.readiness_reason}")

    def open_settings(self):
        if self.c.state!="Idle": return
        dlg=SettingsDialog(clone_config(self.c.config),self)
        if dlg.exec()==QtWidgets.QDialog.Accepted:
            self.c.apply_config(dlg.result_config())

    def open_rigol(self):
        if self.rigol_dialog is None:
            self.rigol_dialog=RigolControlDialog(self.c,self); self.rigol_dialog.finished.connect(lambda _:setattr(self,'rigol_dialog',None))
        self.rigol_dialog.show(); self.rigol_dialog.raise_(); self.rigol_dialog.activateWindow()
        if self.c.rigol.connected:
            try: self.rigol_dialog.refresh_all()
            except Exception as e: self.rigol_dialog.status.setText(str(e))
        else:
            self.rigol_dialog.status.setText("Нет связи. Нажмите «Подключить».")

    def closeEvent(self,e):
        self.runtime_timer.stop(); self.c.close(); super().closeEvent(e)
