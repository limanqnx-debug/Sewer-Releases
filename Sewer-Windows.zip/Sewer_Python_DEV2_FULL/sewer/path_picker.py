"""File and folder selection inside the settings page."""
from pathlib import Path

from PySide6 import QtCore, QtWidgets

from .themes import set_theme_style


class PathPicker(QtWidgets.QWidget):
    accepted = QtCore.Signal(str)
    rejected = QtCore.Signal()

    def __init__(self, initial: Path, file_filter=None, parent=None):
        super().__init__(parent)
        self.folder_only = file_filter is None
        self.directory = None
        self.model = QtWidgets.QFileSystemModel(self)
        self.model.setOption(QtWidgets.QFileSystemModel.DontUseCustomDirectoryIcons, True)
        flags = QtCore.QDir.AllDirs | QtCore.QDir.NoDotAndDotDot
        self.model.setFilter(flags if self.folder_only else flags | QtCore.QDir.Files)
        self.model.setNameFilterDisables(False)

        layout = QtWidgets.QVBoxLayout(self)
        nav = QtWidgets.QHBoxLayout()
        drives = QtWidgets.QPushButton("Диски")
        up = QtWidgets.QPushButton("На уровень выше")
        self.location = QtWidgets.QLabel()
        self.location.setTextFormat(QtCore.Qt.PlainText)
        self.location.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        nav.addWidget(drives)
        nav.addWidget(up)
        nav.addWidget(self.location, 1)
        layout.addLayout(nav)
        drives.clicked.connect(lambda: self.open_directory(None))
        up.clicked.connect(self.go_up)

        self.view = QtWidgets.QTreeView()
        self.view.setModel(self.model)
        self.view.setRootIsDecorated(False)
        self.view.setItemsExpandable(False)
        self.view.setHeaderHidden(True)
        for column in (1, 2, 3):
            self.view.hideColumn(column)
        self.view.clicked.connect(self.select_entry)
        self.view.doubleClicked.connect(self.open_entry)
        layout.addWidget(self.view, 1)

        form = QtWidgets.QFormLayout()
        self.path = QtWidgets.QLineEdit()
        self.path.returnPressed.connect(self.accept)
        form.addRow("Путь к папке" if self.folder_only else "Путь к файлу", self.path)
        if file_filter:
            filters = QtWidgets.QComboBox()
            for option in file_filter.split(";;"):
                patterns = option.rsplit("(", 1)[-1].rstrip(")").split()
                filters.addItem(option, patterns)
            filters.currentIndexChanged.connect(lambda: self.model.setNameFilters(filters.currentData()))
            self.model.setNameFilters(filters.currentData())
            form.addRow("Тип файлов", filters)
        layout.addLayout(form)
        self.error = QtWidgets.QLabel()
        self.error.setTextFormat(QtCore.Qt.PlainText)
        self.error.setWordWrap(True)
        set_theme_style(self.error, "color:#eb8585;")
        self.error.hide()
        layout.addWidget(self.error)
        actions = QtWidgets.QHBoxLayout()
        actions.addStretch(1)
        choose = QtWidgets.QPushButton("Выбрать")
        choose.clicked.connect(self.accept)
        cancel = QtWidgets.QPushButton("Отмена")
        cancel.clicked.connect(self.reject)
        actions.addWidget(choose)
        actions.addWidget(cancel)
        layout.addLayout(actions)

        directory = initial if initial.is_dir() else initial.parent
        self.open_directory(directory if directory.is_dir() else Path.home())
        if not self.folder_only and initial.is_file():
            self.path.setText(str(initial))

    def open_directory(self, directory):
        self.directory = directory
        value = str(directory) if directory is not None else ""
        self.view.setRootIndex(self.model.setRootPath(value))
        self.location.setText(value or "Диски")
        self.path.setText(value if self.folder_only else "")
        self.error.hide()

    def go_up(self):
        if self.directory is not None:
            parent = self.directory.parent
            self.open_directory(parent if parent != self.directory else None)

    def select_entry(self, index):
        self.path.setText(self.model.filePath(index))
        self.error.hide()

    def open_entry(self, index):
        self.select_entry(index)
        self.accept(navigate=True)

    def accept(self, navigate=False):
        value = self.path.text().strip()
        try:
            if value:
                path = Path(value).expanduser()
                if not path.is_absolute() and self.directory is not None:
                    path = self.directory / path
                if path.is_dir():
                    if navigate or not self.folder_only:
                        self.open_directory(path)
                    else:
                        self.accepted.emit(str(path))
                    return
                if not self.folder_only and path.is_file():
                    self.accepted.emit(str(path))
                    return
        except (OSError, RuntimeError):
            pass
        self.error.setText("Укажите существующую папку." if self.folder_only else "Укажите существующий файл.")
        self.error.show()

    def reject(self):
        self.rejected.emit()
