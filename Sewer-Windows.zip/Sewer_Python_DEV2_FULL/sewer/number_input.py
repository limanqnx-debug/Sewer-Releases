from PySide6 import QtCore, QtWidgets


class NumberInput(QtWidgets.QDoubleSpinBox):
    """Numeric editor with no units, accepting dot or comma as decimal separator."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setLocale(QtCore.QLocale.c())
        self.setGroupSeparatorShown(False)
        self.setButtonSymbols(QtWidgets.QAbstractSpinBox.NoButtons)
        self.setKeyboardTracking(False)

    def textFromValue(self, value):
        text = f"{value:.{self.decimals()}f}"
        return text.rstrip("0").rstrip(".") if "." in text else text

    def valueFromText(self, text):
        return super().valueFromText(text.replace(",", "."))

    def validate(self, text, pos):
        return super().validate(text.replace(",", "."), pos)
