from __future__ import annotations

import subprocess
from pathlib import Path

from .config import resolve_path


class ExternalProgram:
    def __init__(self, root: Path, config: dict):
        self.root = root
        self.config = config
        self.process: subprocess.Popen | None = None

    def reconfigure(self, config: dict) -> None:
        self.config = config

    def enabled(self) -> bool:
        return bool(self.config.get("Enabled", False))

    def configuration_error(self) -> str | None:
        if not self.enabled():
            return None
        path = resolve_path(str(self.config.get("ExecutablePath", "")), self.root)
        if not str(self.config.get("ExecutablePath", "")).strip():
            return "Не указан путь к сторонней программе."
        if not path.is_file():
            return f"Сторонняя программа не найдена: {path}"
        return None

    def start(self) -> bool:
        if not self.enabled():
            return False
        error = self.configuration_error()
        if error:
            return False
        path = resolve_path(str(self.config.get("ExecutablePath", "")), self.root)
        try:
            self.process = subprocess.Popen([str(path)], cwd=str(path.parent))
            return True
        except Exception:
            self.process = None
            return False

    def poll(self) -> int | None:
        return None if self.process is None else self.process.poll()

    def stop(self) -> None:
        p = self.process
        if not p:
            return
        try:
            if p.poll() is None:
                p.terminate()
                try:
                    p.wait(timeout=0.5)
                except subprocess.TimeoutExpired:
                    p.kill()
        except Exception:
            pass
        self.process = None
