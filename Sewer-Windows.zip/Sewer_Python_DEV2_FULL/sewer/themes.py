"""Application colour themes and native Qt decorations. No hardware operations."""
from __future__ import annotations
import json
import re
from pathlib import Path
from PySide6 import QtCore, QtGui, QtWidgets

THEMES = json.loads(Path(__file__).with_name('theme_palettes.json').read_text(encoding='utf-8'))
DEFAULT_THEME = 'graphite'
_current = DEFAULT_THEME


def normalize_theme(value):
    return value if isinstance(value, str) and value in THEMES else DEFAULT_THEME


def theme_from_config(config):
    return normalize_theme(config.get('Application', {}).get('Theme', DEFAULT_THEME))


def current_theme():
    return _current


def set_current_theme(key):
    global _current
    _current = normalize_theme(key)


def mapped_color(value):
    return THEMES[_current]['colors'].get(value, value)


def theme_color(value):
    return QtGui.QColor(mapped_color(value))


def action_text(start, enabled, shortcut=False):
    if not enabled:
        return theme_color('#81909f')
    if start and _current in ('polar', 'hellokitty'):
        return QtGui.QColor('#ffffff' if not shortcut else '#fcebf3' if _current == 'hellokitty' else '#e0edfa')
    return theme_color('#c0d0e0' if shortcut else '#eef4f7')


def theme_css(css):
    css = re.sub(r'#[0-9a-fA-F]{6}', lambda m: mapped_color(m.group()), css)
    if _current == 'hellokitty':
        css = css.replace('border-radius:5px', 'border-radius:12px').replace('border-radius:4px', 'border-radius:9px')
    elif _current == 'warhammer':
        css = css.replace('border-radius:5px', 'border-radius:1px').replace('border-radius:4px', 'border-radius:1px')
    return css


def set_theme_style(widget, css):
    widget._theme_base_style = css
    rendered = theme_css(css)
    if getattr(widget, '_theme_heading', False) and _current == 'warhammer':
        rendered = 'font-family:"DejaVu Serif";font-size:17px;font-weight:700;color:#e0c89b;'
    widget.setStyleSheet(rendered)


def apply_widget_theme(root):
    for widget in [root, *root.findChildren(QtWidgets.QWidget)]:
        if hasattr(widget, '_theme_base_style'):
            set_theme_style(widget, widget._theme_base_style)
        if isinstance(widget, ThemeHeader):
            widget.refresh_theme()
        widget.update()


def draw_bow(painter, center, scale=1):
    p = painter
    p.save(); p.translate(center); p.scale(scale, scale)
    p.setPen(QtGui.QPen(QtGui.QColor('#a83265'), 1)); p.setBrush(QtGui.QColor('#e870a5'))
    p.drawRoundedRect(QtCore.QRectF(-11,-6,10,12),3,3)
    p.drawRoundedRect(QtCore.QRectF(1,-6,10,12),3,3)
    p.setBrush(QtGui.QColor('#f99bc3')); p.drawEllipse(QtCore.QRectF(-4,-4,8,8)); p.restore()


def draw_card_decoration(widget):
    if _current not in ('hellokitty', 'warhammer'):
        return
    p = QtGui.QPainter(widget); p.setRenderHint(QtGui.QPainter.Antialiasing)
    if _current == 'hellokitty':
        draw_bow(p, QtCore.QPointF(widget.width()-25,24),.85)
    else:
        p.setPen(QtGui.QPen(QtGui.QColor('#685b44'),1))
        for x,y in ((5,5),(widget.width()-6,5),(5,widget.height()-6),(widget.width()-6,widget.height()-6)):
            p.setBrush(QtGui.QColor('#b5a489')); p.drawEllipse(QtCore.QRectF(x-1.5,y-1.5,3,3))
        for x,d in ((8,1),(widget.width()-9,-1)):
            p.drawLine(x,9,x+d*16,9); p.drawLine(x,9,x,23)
    p.end()


class ThemeEmblem(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(46,46)
        self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents)
        set_theme_style(self, 'background:transparent;')

    def paintEvent(self, event):
        p=QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.Antialiasing)
        if _current == 'hellokitty':
            p.setPen(QtGui.QPen(QtGui.QColor('#6d4053'),1.4)); p.setBrush(QtGui.QColor('#ffffff'))
            path=QtGui.QPainterPath(QtCore.QPointF(8,20))
            path.cubicTo(7,15,7,7,12,8); path.lineTo(20,13)
            path.cubicTo(23,12,26,12,29,13); path.lineTo(36,8)
            path.cubicTo(40,8,39,15,38,20); path.cubicTo(46,39,1,42,8,20); p.drawPath(path)
            p.setPen(QtCore.Qt.NoPen); p.setBrush(QtGui.QColor('#482b37'))
            p.drawEllipse(QtCore.QRectF(16,23,3,4)); p.drawEllipse(QtCore.QRectF(29,23,3,4))
            p.setBrush(QtGui.QColor('#ecc04a')); p.drawEllipse(QtCore.QRectF(22,29,5,3))
            p.setPen(QtGui.QPen(QtGui.QColor('#6d4053'),1.3))
            for y in (24,29,33):
                p.drawLine(4,y,11,y+1); p.drawLine(36,y+1,43,y)
            draw_bow(p,QtCore.QPointF(34,14),.8)
        elif _current == 'warhammer':
            p.setPen(QtGui.QPen(QtGui.QColor('#bfa570'),1.5)); p.setBrush(QtCore.Qt.NoBrush)
            p.drawEllipse(QtCore.QRectF(7,7,32,32)); p.save(); p.translate(23,23)
            for i in range(12):
                p.drawLine(0,-16,0,-21); p.rotate(30)
            p.restore(); p.setBrush(QtGui.QColor('#d6c4a0')); p.setPen(QtCore.Qt.NoPen)
            p.drawEllipse(QtCore.QRectF(13,11,20,23)); p.drawRect(QtCore.QRectF(18,29,10,7))
            p.setBrush(QtGui.QColor('#18191c'))
            p.drawEllipse(QtCore.QRectF(16,21,5,5)); p.drawEllipse(QtCore.QRectF(26,21,5,5))
            p.drawPolygon(QtGui.QPolygonF([QtCore.QPointF(23,25),QtCore.QPointF(21,29),QtCore.QPointF(25,29)]))
            p.setPen(QtGui.QPen(QtGui.QColor('#18191c'),1))
            for x in (21,24,27): p.drawLine(x,32,x,35)
        p.end()


class ThemeHeader(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        set_theme_style(self, 'background:transparent;')
        row=QtWidgets.QHBoxLayout(self); row.setContentsMargins(14,0,0,0); row.setSpacing(5)
        row.addWidget(ThemeEmblem(self)); self.label=QtWidgets.QLabel(); row.addWidget(self.label)
        self.refresh_theme()

    def refresh_theme(self):
        visible = _current in ('hellokitty', 'warhammer')
        self.setVisible(visible)
        if visible:
            self.label.setText(THEMES[_current]['name'])
            self.label.setStyleSheet('font-size:16px;font-weight:600;color:#ae3b70;' if _current == 'hellokitty' else 'font-family:"DejaVu Serif";font-size:14px;font-weight:700;color:#c4ad80;')
