from __future__ import annotations

from pathlib import Path
from .runtime import application_dir, asset_path
from .rigol_screenshot import DEFAULT_FOLDER, filename_base

from PySide6 import QtCore, QtGui, QtWidgets
from .themes import THEMES, theme_from_config, normalize_theme, set_theme_style, apply_widget_theme
from serial.tools import list_ports


class BaudRateComboBox(QtWidgets.QComboBox):
    """Ascending baud rates: wheel up selects a larger value."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self._wheel_delta = 0

    def wheelEvent(self, event):
        delta = event.angleDelta().y()
        if delta:
            if self._wheel_delta * delta < 0:
                self._wheel_delta = 0
            self._wheel_delta += delta
            steps = int(self._wheel_delta / 120)
            self._wheel_delta -= steps * 120
            if steps and self.count():
                index = self.currentIndex()
                if index < 0:
                    index = 0 if steps > 0 else self.count() - 1
                else:
                    index = max(0, min(self.count() - 1, index + steps))
                self.setCurrentIndex(index)
        event.accept()


class SettingsDialog(QtWidgets.QDialog):
    theme_preview = QtCore.Signal(str)
    SCREENSHOT_CONTROLS = frozenset({"rig.shot_folder", "rig.shot_name", "rig.shot_numbering"})

    def __init__(self, config: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Настройки Sewer")
        self.resize(800, 620)
        self.config = config
        self.tabs = QtWidgets.QTabWidget()
        root = QtWidgets.QVBoxLayout(self)
        root.addWidget(self.tabs)
        self.controls: dict[str, QtWidgets.QWidget] = {}
        self._power_tab()
        self._programmer_tab()
        self._rigol_tab()
        controller=getattr(parent,"c",None)
        if controller is not None:
            page=QtWidgets.QWidget(); layout=QtWidgets.QVBoxLayout(page)
            label=QtWidgets.QLabel("Таблица конфигураций Rigol. Выбор по названию — в главном окне.")
            label.setWordWrap(True); layout.addWidget(label)
            self.preset_editor_button=QtWidgets.QPushButton("Редактировать таблицу пресетов…")
            def edit_presets():
                from .rigol_preset_editor import PresetEditor
                editor=PresetEditor(controller,self); editor.exec(); editor.deleteLater()
            self.preset_editor_button.clicked.connect(edit_presets)
            layout.addWidget(self.preset_editor_button); layout.addStretch()
            self.tabs.addTab(page,"Пресеты Rigol")
        self._screenshot_tab()
        self._other_tab()
        self._theme_tab()
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel)
        buttons.button(QtWidgets.QDialogButtonBox.Save).setText("Сохранить")
        buttons.button(QtWidgets.QDialogButtonBox.Cancel).setText("Отмена")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)
        apply_widget_theme(self)

    def _form(self, title: str):
        page = QtWidgets.QWidget(); form = QtWidgets.QFormLayout(page); self.tabs.addTab(page, title); return form

    def _line(self, form, key, label, value):
        w = QtWidgets.QLineEdit(str(value)); form.addRow(label, w); self.controls[key] = w; return w

    def _spin(self, form, key, label, value, lo, hi, decimals=0, step=1):
        w = QtWidgets.QDoubleSpinBox(); w.setRange(lo, hi); w.setDecimals(decimals); w.setSingleStep(step); w.setValue(float(value)); w.setButtonSymbols(QtWidgets.QAbstractSpinBox.NoButtons); form.addRow(label, w); self.controls[key] = w; return w

    def _file(self, form, key, label, value, file_filter):
        row = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout(row)
        layout.setContentsMargins(0, 0, 0, 0)
        edit = QtWidgets.QLineEdit(str(value))
        button = QtWidgets.QPushButton("Обзор…")
        layout.addWidget(edit, 1)
        layout.addWidget(button)
        def browse():
            initial = Path(edit.text().strip())
            if not initial.is_absolute():
                initial = getattr(getattr(self.parent(),"c",None),"root",application_dir()) / initial
            selected, _ = QtWidgets.QFileDialog.getOpenFileName(self, label, str(initial), file_filter)
            if selected:
                edit.setText(selected)
        button.clicked.connect(browse)
        form.addRow(label, row)
        self.controls[key] = edit
        return edit

    def _rigol_resource(self):
        if self._v("rig.connection") == "USB":
            return self._v("rig.usb")
        address = self._v("rig.eth")
        if address.upper().startswith("TCPIP"):
            return address
        return f"TCPIP0::{address}::inst0::INSTR"

    def accept(self):
        if not self._v("ps.port"):
            QtWidgets.QMessageBox.warning(self, "COM-порт", "Выберите или введите COM-порт источника.")
            return
        if not self._v("ps.baud"):
            QtWidgets.QMessageBox.warning(self, "Скорость COM", "Выберите стандартную скорость COM-порта.")
            return
        usb = self._v("rig.connection") == "USB"
        address = self._v("rig.usb" if usb else "rig.eth")
        if not address or (usb and not address.upper().startswith("USB")) or (not usb and (any(ch.isspace() for ch in address) or (":" in address and not address.upper().startswith("TCPIP")))):
            QtWidgets.QMessageBox.warning(self, "Rigol", "Укажите USB VISA Resource или IP / имя прибора / TCPIP VISA Resource для ETH.")
            return
        super().accept()

    def _check(self, form, key, label, value):
        w = QtWidgets.QCheckBox(); w.setChecked(bool(value)); form.addRow(label, w); self.controls[key] = w; return w

    def _port_selector(self, form, configured):
        row = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout(row)
        layout.setContentsMargins(0, 0, 0, 0)
        port = QtWidgets.QComboBox()
        port.setEditable(True)
        port.setInsertPolicy(QtWidgets.QComboBox.NoInsert)
        port.setEditText(str(configured))
        port.setToolTip("Выберите COM-порт источника или введите его вручную.")
        self.controls["ps.port"] = port
        refresh = QtWidgets.QPushButton("Обновить")
        refresh.setToolTip("Обновить список подключённых COM-портов")
        refresh.clicked.connect(self._refresh_ports)
        layout.addWidget(port, 1)
        layout.addWidget(refresh)
        form.addRow("COM-порт", row)
        self.port_status = QtWidgets.QLabel()
        self.port_status.setWordWrap(True)
        form.addRow(self.port_status)
        self._refresh_ports()

    def _refresh_ports(self):
        port = self.controls["ps.port"]
        selected = port.currentText().strip()
        try:
            available = sorted(list_ports.comports())
        except Exception as exc:
            self.port_status.setText("Не удалось обновить список. Введите COM-порт вручную.")
            self.port_status.setToolTip(str(exc))
            return
        port.blockSignals(True)
        try:
            port.clear()
            for info in available:
                if port.findText(info.device) < 0:
                    port.addItem(info.device)
                    port.setItemData(port.count() - 1, info.description or info.device, QtCore.Qt.ToolTipRole)
            if selected and port.findText(selected) < 0:
                port.addItem(selected)
                port.setItemData(port.count() - 1, "Сохранённый порт сейчас не обнаружен", QtCore.Qt.ToolTipRole)
            port.setEditText(selected)
        finally:
            port.blockSignals(False)
        self.port_status.setToolTip("")
        if not available:
            self.port_status.setText("COM-порты не найдены. Подключите источник и нажмите «Обновить».")
        else:
            self.port_status.setText(f"Найдено портов: {len(available)}. Выберите порт источника.")

    def _power_tab(self):
        c = self.config.get("PowerSupply", {}); f = self._form("Источник и защита")
        self._port_selector(f, c.get("Port", "COM3"))
        baud = BaudRateComboBox()
        baud.addItems([str(v) for v in (1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600)])
        configured = str(c.get("BaudRate", 115200))
        baud.setCurrentIndex(baud.findText(configured))
        if baud.currentIndex() < 0:
            baud.setPlaceholderText("Выберите стандартную скорость")
        f.addRow("Скорость, бод", baud)
        self.controls["ps.baud"] = baud
        self._spin(f,"ps.voltage","Ограничение напряжения, В",c.get("Voltage",24),0,60,3,.1)
        self._spin(f,"ps.current","Ограничение тока, А",c.get("CurrentLimit",.3),0,10,3,.01)
        self._spin(f,"ps.delay","Пауза после включения, мс",c.get("PowerOnDelayMs",1000),0,10000,0,100)
        self._spin(f,"ps.samples","Измерений тока",c.get("CurrentSamples",5),1,20,0,1)
        self._spin(f,"ps.no_board","Нет платы, А",c.get("NoBoardCurrent",.001),0,1,3,.001)
        self._spin(f,"ps.low","Низкий ток, А",c.get("LowCurrent",.03),0,1,3,.005)
        self._spin(f,"ps.high","Высокий ток, А",c.get("HighCurrent",.06),0,1,3,.005)
        self._spin(f,"ps.trip","Аварийный ток, А",c.get("TripCurrent",.1),0,2,3,.01)
        self._check(f,"ps.autooff","Автоматическое отключение после успеха",c.get("AutoPowerOffAfterSuccess",True))

    def _programmer_tab(self):
        c = self.config.get("Programmer", {}); f = self._form("Programmer и прошивка")
        self._file(f,"prg.exe","Programmer EXE",c.get("ExecutablePath",""),"Программы (*.exe);;Все файлы (*)")
        self._file(f,"prg.fw","Файл прошивки",c.get("FirmwarePath","Firmware\\Main.fs"),"Прошивки (*.fs *.bin *.bit);;Все файлы (*)")
        self._line(f,"prg.args","Аргументы",c.get("Arguments",'--fs "{FW}"'))
        info = QtWidgets.QLabel("Подстановка Sewer: {FW} → полный путь к прошивке."); info.setWordWrap(True); f.addRow(info)

    def _rigol_tab(self):
        c = self.config.get("Rigol", {}); f = self._form("Rigol")
        resource = c.get("Resource", "USB::0x1AB1::0x0968::RSA5F274300290::INSTR")
        is_eth = resource.upper().startswith("TCPIP")
        connection = QtWidgets.QComboBox()
        connection.addItems(["USB", "ETH"])
        connection.setCurrentText("ETH" if is_eth else "USB")
        self.controls["rig.connection"] = connection
        f.addRow("Подключение", connection)
        usb = self._line(f, "rig.usb", "USB VISA Resource", resource if not is_eth else c.get("USBResource", "USB::0x1AB1::0x0968::RSA5F274300290::INSTR"))
        eth = self._line(f, "rig.eth", "ETH: IP / имя / VISA Resource", resource if is_eth else c.get("ETHResource", ""))
        eth.setPlaceholderText("192.168.1.100 или TCPIP0::192.168.1.100::inst0::INSTR")
        def update_connection():
            usb.setEnabled(connection.currentText() == "USB")
            eth.setEnabled(connection.currentText() == "ETH")
        connection.currentTextChanged.connect(update_connection)
        update_connection()
        self._spin(f,"rig.timeout","Timeout, мс",c.get("TimeoutMs",2500),100,10000,0,100)
        self._spin(f,"rig.monitor","Монитор, мс",c.get("MonitorIntervalMs",2500),500,30000,0,100)
        self._spin(f,"rig.live","Live, мс",c.get("LiveIntervalMs",300),100,5000,0,50)

    def _screenshot_tab(self):
        form = self._form("Скриншоты")
        config = self.config.get("RigolScreenshot", {})
        row = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout(row)
        layout.setContentsMargins(0, 0, 0, 0)
        folder = QtWidgets.QLineEdit(str(config.get("Folder") or DEFAULT_FOLDER))
        browse = QtWidgets.QPushButton("Обзор…")
        layout.addWidget(folder, 1)
        layout.addWidget(browse)
        self.controls["rig.shot_folder"] = folder
        form.addRow("Папка скриншотов", row)

        def choose_folder():
            initial = Path(folder.text().strip() or DEFAULT_FOLDER).expanduser()
            if not initial.is_absolute():
                initial = getattr(getattr(self.parent(), "c", None), "root", application_dir()) / initial
            selected = QtWidgets.QFileDialog.getExistingDirectory(self, "Папка скриншотов Rigol", str(initial))
            if selected:
                folder.setText(selected)

        browse.clicked.connect(choose_folder)
        name = self._line(form, "rig.shot_name", "Имя файла", config.get("BaseName", "Rigol"))
        numbering = QtWidgets.QComboBox()
        numbering.addItem("Следующий после последнего", False)
        numbering.addItem("Первый свободный номер", True)
        numbering.setCurrentIndex(int(bool(config.get("FillGaps", False))))
        self.controls["rig.shot_numbering"] = numbering
        form.addRow("Нумерация скриншотов", numbering)
        example = QtWidgets.QLabel()
        example.setTextFormat(QtCore.Qt.PlainText)
        example.setWordWrap(True)
        def show_example():
            example.setText(f"Пример: {filename_base(name.text())}_001.png")
        name.textChanged.connect(show_example)
        show_example()
        form.addRow(example)

    def _other_tab(self):
        l = self.config.get("Logging", {}); e = self.config.get("ExternalProgram", {}); p = self.config.get("Pulse", {})
        f = self._form("Прочее")
        self._check(f,"log.enabled","Журналирование",l.get("Enabled",True))
        self._check(f,"log.app","Лог Sewer",l.get("ApplicationLog",True))
        self._check(f,"log.prg","Лог Programmer",l.get("ProgrammerLog",True))
        self._line(f,"log.dir","Папка логов",l.get("Directory","Logs"))
        self._check(f,"ext.enabled","Сторонняя программа",e.get("Enabled",False))
        self._file(f,"ext.exe","Путь к программе",e.get("ExecutablePath",""),"Программы (*.exe);;Все файлы (*)")
        self._check(f,"pulse.enabled","Импульс после программы",p.get("Enabled",False))
        self._spin(f,"pulse.pause","Пауза, с",p.get("PauseSeconds",1),0,60,1,.1)
        self._spin(f,"pulse.on","Время импульса, с",p.get("OnSeconds",3),0.1,60,1,.1)

    def _theme_tab(self):
        self.selected_theme=theme_from_config(self.config)
        page=QtWidgets.QWidget(); layout=QtWidgets.QVBoxLayout(page); layout.setSpacing(10)
        tip=QtWidgets.QLabel("Выберите тему для предпросмотра. «Сохранить» оставит её для следующего запуска, «Отмена» вернёт прежнюю.")
        tip.setWordWrap(True); layout.addWidget(tip)
        grid=QtWidgets.QGridLayout(); grid.setSpacing(8); layout.addLayout(grid)
        self.theme_buttons={}; self.theme_group=QtWidgets.QButtonGroup(self); self.theme_group.setExclusive(True)
        for index,(key,theme) in enumerate(THEMES.items()):
            button=QtWidgets.QToolButton(); button.setObjectName("ThemeChoice")
            button.setText(theme["name"]); button.setToolTip(theme["description"])
            button.setAccessibleName(theme["name"]); button.setCheckable(True); button.setChecked(key==self.selected_theme)
            button.setCursor(QtCore.Qt.PointingHandCursor)
            button.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
            button.setIcon(QtGui.QIcon(str(asset_path("Resources","Themes",key+".png"))))
            button.setIconSize(QtCore.QSize(180,111)); button.setMinimumSize(200,154)
            button.setSizePolicy(QtWidgets.QSizePolicy.Expanding,QtWidgets.QSizePolicy.Fixed)
            set_theme_style(button, "QToolButton{background:#222a35;color:#e5ebef;border:2px solid #343d46;border-radius:5px;padding:6px;} QToolButton:hover{border-color:#657b89;} QToolButton:checked{border-color:#399ce8;background:#243b54;} QToolButton:focus{border-color:#399ce8;}")
            self.theme_group.addButton(button); self.theme_buttons[key]=button
            button.clicked.connect(lambda checked=False, key=key:self._select_theme(key))
            grid.addWidget(button,index//3,index%3)
        self.theme_description=QtWidgets.QLabel(THEMES[self.selected_theme]["description"])
        self.theme_description.setWordWrap(True); layout.addWidget(self.theme_description); layout.addStretch(1)
        self.tabs.addTab(page,"Оформление")

    def _select_theme(self,key):
        self.selected_theme=normalize_theme(key)
        self.theme_buttons[self.selected_theme].setChecked(True)
        self.theme_description.setText(THEMES[self.selected_theme]["description"])
        self.theme_preview.emit(self.selected_theme)

    def controls_snapshot(self):
        return {key:self._v(key) for key in self.controls}

    def _v(self, key):
        w = self.controls[key]
        if isinstance(w, QtWidgets.QComboBox): return w.currentText().strip()
        if isinstance(w, QtWidgets.QLineEdit): return w.text().strip()
        if isinstance(w, QtWidgets.QCheckBox): return w.isChecked()
        if isinstance(w, QtWidgets.QDoubleSpinBox): return w.value()
        raise TypeError(key)

    def result_config(self) -> dict:
        c = self.config
        ps = c.setdefault("PowerSupply", {})
        ps.update({
            "Port":self._v("ps.port"),"BaudRate":int(self._v("ps.baud")),"Voltage":self._v("ps.voltage"),
            "CurrentLimit":self._v("ps.current"),"PowerOnDelayMs":int(self._v("ps.delay")),"CurrentSamples":int(self._v("ps.samples")),
            "NoBoardCurrent":self._v("ps.no_board"),"LowCurrent":self._v("ps.low"),"HighCurrent":self._v("ps.high"),"TripCurrent":self._v("ps.trip"),
            "AutoPowerOffAfterSuccess":self._v("ps.autooff"),
        })
        prg=c.setdefault("Programmer",{}); prg.update({"ExecutablePath":self._v("prg.exe"),"FirmwarePath":self._v("prg.fw"),"Arguments":self._v("prg.args")})
        rig=c.setdefault("Rigol",{}); rig.update({"Resource":self._rigol_resource(),"Connection":self._v("rig.connection"),"USBResource":self._v("rig.usb"),"ETHResource":self._v("rig.eth"),"TimeoutMs":int(self._v("rig.timeout")),"MonitorIntervalMs":int(self._v("rig.monitor")),"LiveIntervalMs":int(self._v("rig.live"))})
        c.setdefault("RigolScreenshot", {}).update({
            "Folder": self._v("rig.shot_folder"),
            "BaseName": filename_base(self._v("rig.shot_name")),
            "FillGaps": self.controls["rig.shot_numbering"].currentData(),
        })
        log=c.setdefault("Logging",{}); log.update({"Enabled":self._v("log.enabled"),"ApplicationLog":self._v("log.app"),"ProgrammerLog":self._v("log.prg"),"Directory":self._v("log.dir")})
        ext=c.setdefault("ExternalProgram",{}); ext.update({"Enabled":self._v("ext.enabled"),"ExecutablePath":self._v("ext.exe")})
        pulse=c.setdefault("Pulse",{}); pulse.update({"Enabled":self._v("pulse.enabled"),"PauseSeconds":self._v("pulse.pause"),"OnSeconds":self._v("pulse.on")})
        c.setdefault("Application",{})["Theme"]=self.selected_theme
        return c
