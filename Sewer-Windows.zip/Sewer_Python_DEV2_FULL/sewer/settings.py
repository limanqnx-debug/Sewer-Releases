from __future__ import annotations

from pathlib import Path

from PySide6 import QtWidgets


class SettingsDialog(QtWidgets.QDialog):
    def __init__(self, config: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Настройки Sewer")
        self.resize(720, 620)
        self.config = config
        self.tabs = QtWidgets.QTabWidget()
        root = QtWidgets.QVBoxLayout(self)
        root.addWidget(self.tabs)
        self.controls: dict[str, QtWidgets.QWidget] = {}
        self._power_tab()
        self._programmer_tab()
        self._rigol_tab()
        self._other_tab()
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel)
        buttons.button(QtWidgets.QDialogButtonBox.Save).setText("Сохранить")
        buttons.button(QtWidgets.QDialogButtonBox.Cancel).setText("Отмена")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

    def _form(self, title: str):
        page = QtWidgets.QWidget(); form = QtWidgets.QFormLayout(page); self.tabs.addTab(page, title); return form

    def _line(self, form, key, label, value):
        w = QtWidgets.QLineEdit(str(value)); form.addRow(label, w); self.controls[key] = w; return w

    def _spin(self, form, key, label, value, lo, hi, decimals=0, step=1):
        w = QtWidgets.QDoubleSpinBox(); w.setRange(lo, hi); w.setDecimals(decimals); w.setSingleStep(step); w.setValue(float(value)); w.setButtonSymbols(QtWidgets.QAbstractSpinBox.NoButtons); form.addRow(label, w); self.controls[key] = w; return w

    def _file(self, form, key, label, value, file_filter):
        row = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout(row)
        layout.setContentsMargins(0, 0, 0, 0)
        edit = QtWidgets.QLineEdit(str(value))
        button = QtWidgets.QPushButton("Обзор…")
        layout.addWidget(edit, 1)
        layout.addWidget(button)
        def browse():
            initial = Path(edit.text().strip())
            if not initial.is_absolute():
                initial = Path(__file__).resolve().parent.parent / initial
            selected, _ = QtWidgets.QFileDialog.getOpenFileName(self, label, str(initial), file_filter)
            if selected:
                edit.setText(selected)
        button.clicked.connect(browse)
        form.addRow(label, row)
        self.controls[key] = edit
        return edit

    def _rigol_resource(self):
        if self._v("rig.connection") == "USB":
            return self._v("rig.usb")
        address = self._v("rig.eth")
        if address.upper().startswith("TCPIP"):
            return address
        return f"TCPIP0::{address}::inst0::INSTR"

    def accept(self):
        if not self._v("ps.baud"):
            QtWidgets.QMessageBox.warning(self, "Скорость COM", "Выберите стандартную скорость COM-порта.")
            return
        usb = self._v("rig.connection") == "USB"
        address = self._v("rig.usb" if usb else "rig.eth")
        if not address or (usb and not address.upper().startswith("USB")) or (not usb and (any(ch.isspace() for ch in address) or (":" in address and not address.upper().startswith("TCPIP")))):
            QtWidgets.QMessageBox.warning(self, "Rigol", "Укажите USB VISA Resource или IP / имя прибора / TCPIP VISA Resource для ETH.")
            return
        super().accept()

    def _check(self, form, key, label, value):
        w = QtWidgets.QCheckBox(); w.setChecked(bool(value)); form.addRow(label, w); self.controls[key] = w; return w

    def _power_tab(self):
        c = self.config.get("PowerSupply", {}); f = self._form("Источник и защита")
        self._line(f,"ps.port","COM-порт",c.get("Port","COM3"))
        baud = QtWidgets.QComboBox()
        baud.addItems([str(v) for v in (1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600)])
        configured = str(c.get("BaudRate", 115200))
        baud.setCurrentIndex(baud.findText(configured))
        if baud.currentIndex() < 0:
            baud.setPlaceholderText("Выберите стандартную скорость")
        f.addRow("Скорость, бод", baud)
        self.controls["ps.baud"] = baud
        self._spin(f,"ps.voltage","Ограничение напряжения, В",c.get("Voltage",24),0,60,3,.1)
        self._spin(f,"ps.current","Ограничение тока, А",c.get("CurrentLimit",.3),0,10,3,.01)
        self._spin(f,"ps.delay","Пауза после включения, мс",c.get("PowerOnDelayMs",1000),0,10000,0,100)
        self._spin(f,"ps.samples","Измерений тока",c.get("CurrentSamples",5),1,20,0,1)
        self._spin(f,"ps.no_board","Нет платы, А",c.get("NoBoardCurrent",.001),0,1,3,.001)
        self._spin(f,"ps.low","Низкий ток, А",c.get("LowCurrent",.03),0,1,3,.005)
        self._spin(f,"ps.high","Высокий ток, А",c.get("HighCurrent",.06),0,1,3,.005)
        self._spin(f,"ps.trip","Аварийный ток, А",c.get("TripCurrent",.1),0,2,3,.01)
        self._check(f,"ps.autooff","Автоматическое отключение после успеха",c.get("AutoPowerOffAfterSuccess",True))

    def _programmer_tab(self):
        c = self.config.get("Programmer", {}); f = self._form("Programmer и прошивка")
        self._file(f,"prg.exe","Programmer EXE",c.get("ExecutablePath",""),"Программы (*.exe);;Все файлы (*)")
        self._file(f,"prg.fw","Файл прошивки",c.get("FirmwarePath","Firmware\\Main.fs"),"Прошивки (*.fs *.bin *.bit);;Все файлы (*)")
        self._line(f,"prg.args","Аргументы",c.get("Arguments",'--fs "{FW}"'))
        info = QtWidgets.QLabel("Подстановка Sewer: {FW} → полный путь к прошивке."); info.setWordWrap(True); f.addRow(info)

    def _rigol_tab(self):
        c = self.config.get("Rigol", {}); f = self._form("Rigol")
        resource = c.get("Resource", "USB::0x1AB1::0x0968::RSA5F274300290::INSTR")
        is_eth = resource.upper().startswith("TCPIP")
        connection = QtWidgets.QComboBox()
        connection.addItems(["USB", "ETH"])
        connection.setCurrentText("ETH" if is_eth else "USB")
        self.controls["rig.connection"] = connection
        f.addRow("Подключение", connection)
        usb = self._line(f, "rig.usb", "USB VISA Resource", resource if not is_eth else c.get("USBResource", "USB::0x1AB1::0x0968::RSA5F274300290::INSTR"))
        eth = self._line(f, "rig.eth", "ETH: IP / имя / VISA Resource", resource if is_eth else c.get("ETHResource", ""))
        eth.setPlaceholderText("192.168.1.100 или TCPIP0::192.168.1.100::inst0::INSTR")
        def update_connection():
            usb.setEnabled(connection.currentText() == "USB")
            eth.setEnabled(connection.currentText() == "ETH")
        connection.currentTextChanged.connect(update_connection)
        update_connection()
        self._spin(f,"rig.timeout","Timeout, мс",c.get("TimeoutMs",2500),100,10000,0,100)
        self._spin(f,"rig.monitor","Монитор, мс",c.get("MonitorIntervalMs",2500),500,30000,0,100)
        self._spin(f,"rig.live","Live, мс",c.get("LiveIntervalMs",300),100,5000,0,50)

    def _other_tab(self):
        l = self.config.get("Logging", {}); e = self.config.get("ExternalProgram", {}); p = self.config.get("Pulse", {})
        f = self._form("Прочее")
        self._check(f,"log.enabled","Журналирование",l.get("Enabled",True))
        self._check(f,"log.app","Лог Sewer",l.get("ApplicationLog",True))
        self._check(f,"log.prg","Лог Programmer",l.get("ProgrammerLog",True))
        self._line(f,"log.dir","Папка логов",l.get("Directory","Logs"))
        self._check(f,"ext.enabled","Сторонняя программа",e.get("Enabled",False))
        self._file(f,"ext.exe","Путь к программе",e.get("ExecutablePath",""),"Программы (*.exe);;Все файлы (*)")
        self._check(f,"pulse.enabled","Импульс после программы",p.get("Enabled",False))
        self._spin(f,"pulse.pause","Пауза, с",p.get("PauseSeconds",1),0,60,1,.1)
        self._spin(f,"pulse.on","Время импульса, с",p.get("OnSeconds",3),0.1,60,1,.1)

    def _v(self, key):
        w = self.controls[key]
        if isinstance(w, QtWidgets.QComboBox): return w.currentText()
        if isinstance(w, QtWidgets.QLineEdit): return w.text().strip()
        if isinstance(w, QtWidgets.QCheckBox): return w.isChecked()
        if isinstance(w, QtWidgets.QDoubleSpinBox): return w.value()
        raise TypeError(key)

    def result_config(self) -> dict:
        c = self.config
        ps = c.setdefault("PowerSupply", {})
        ps.update({
            "Port":self._v("ps.port"),"BaudRate":int(self._v("ps.baud")),"Voltage":self._v("ps.voltage"),
            "CurrentLimit":self._v("ps.current"),"PowerOnDelayMs":int(self._v("ps.delay")),"CurrentSamples":int(self._v("ps.samples")),
            "NoBoardCurrent":self._v("ps.no_board"),"LowCurrent":self._v("ps.low"),"HighCurrent":self._v("ps.high"),"TripCurrent":self._v("ps.trip"),
            "AutoPowerOffAfterSuccess":self._v("ps.autooff"),
        })
        prg=c.setdefault("Programmer",{}); prg.update({"ExecutablePath":self._v("prg.exe"),"FirmwarePath":self._v("prg.fw"),"Arguments":self._v("prg.args")})
        rig=c.setdefault("Rigol",{}); rig.update({"Resource":self._rigol_resource(),"Connection":self._v("rig.connection"),"USBResource":self._v("rig.usb"),"ETHResource":self._v("rig.eth"),"TimeoutMs":int(self._v("rig.timeout")),"MonitorIntervalMs":int(self._v("rig.monitor")),"LiveIntervalMs":int(self._v("rig.live"))})
        log=c.setdefault("Logging",{}); log.update({"Enabled":self._v("log.enabled"),"ApplicationLog":self._v("log.app"),"ProgrammerLog":self._v("log.prg"),"Directory":self._v("log.dir")})
        ext=c.setdefault("ExternalProgram",{}); ext.update({"Enabled":self._v("ext.enabled"),"ExecutablePath":self._v("ext.exe")})
        pulse=c.setdefault("Pulse",{}); pulse.update({"Enabled":self._v("pulse.enabled"),"PauseSeconds":self._v("pulse.pause"),"OnSeconds":self._v("pulse.on")})
        return c
