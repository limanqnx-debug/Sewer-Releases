"""Preset editor reachable only through hedgehog Settings."""
from __future__ import annotations
import copy
from PySide6 import QtCore, QtWidgets
from .rigol_presets import COLUMNS, new_preset, validate_row
from .themes import apply_widget_theme


class ChoiceDelegate(QtWidgets.QStyledItemDelegate):
    def createEditor(self,parent,option,index):
        choices=COLUMNS[index.column()][3]
        if choices:
            box=QtWidgets.QComboBox(parent);box.addItem('');box.addItems(choices);return box
        return super().createEditor(parent,option,index)

    def setEditorData(self,editor,index):
        if isinstance(editor,QtWidgets.QComboBox): editor.setCurrentText(str(index.data() or ''))
        else: super().setEditorData(editor,index)

    def setModelData(self,editor,model,index):
        if isinstance(editor,QtWidgets.QComboBox): model.setData(index,editor.currentText())
        else: super().setModelData(editor,model,index)


class PresetEditor(QtWidgets.QDialog):
    def __init__(self,controller,parent=None):
        super().__init__(parent);self.c=controller;self.store=controller.presets
        self.rows=copy.deepcopy(self.store.rows);self.busy=False
        self.setWindowTitle('Пресеты Rigol — редактор');self.resize(1120,520)
        root=QtWidgets.QVBoxLayout(self);bar=QtWidgets.QHBoxLayout();root.addLayout(bar)
        self.actions=[]
        for label,fn in (('+ Добавить',self.add_row),('Копировать',self.copy_row),('Удалить',self.delete_row),('Считать с Rigol',self.capture)):
            b=QtWidgets.QPushButton(label);b.clicked.connect(fn);bar.addWidget(b);self.actions.append(b)
        bar.addStretch()
        self.table=QtWidgets.QTableWidget(0,len(COLUMNS));root.addWidget(self.table,1)
        self.table.setHorizontalHeaderLabels([caption+('\n'+unit if unit else '') for _,caption,unit,_ in COLUMNS])
        self.table.setItemDelegate(ChoiceDelegate(self.table))
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Interactive)
        self.table.setColumnWidth(0,180)
        for col in range(1,len(COLUMNS)):self.table.setColumnWidth(col,135)
        helptext=QtWidgets.QLabel('Пусто — не менять. Частота маркера включает Normal на выбранной Trace (по умолчанию 1).\nFunc: OFF / NOIS / BPOW / BDEN. Band Function: BPOW / BDEN. Для Auto ON оставьте число пустым.\nДвойной щелчок — редактирование. Остальные столбцы доступны прокруткой вправо.')
        helptext.setWordWrap(True);root.addWidget(helptext)
        self.status=QtWidgets.QLabel(self.store.error or str(self.store.path));self.status.setWordWrap(True);root.addWidget(self.status)
        self.buttons=QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Save|QtWidgets.QDialogButtonBox.Cancel)
        self.buttons.button(QtWidgets.QDialogButtonBox.Save).setText('Сохранить таблицу')
        self.buttons.button(QtWidgets.QDialogButtonBox.Cancel).setText('Отмена')
        self.buttons.accepted.connect(self.accept);self.buttons.rejected.connect(self.reject);root.addWidget(self.buttons)
        self.render();apply_widget_theme(self)
        if self.store.error:
            self.table.setEnabled(False);self.buttons.button(QtWidgets.QDialogButtonBox.Save).setEnabled(False)
            for b in self.actions:b.setEnabled(False)

    def render(self,selected=0):
        self.table.setRowCount(len(self.rows))
        for i,row in enumerate(self.rows):
            for j,(key,_,_,_) in enumerate(COLUMNS):
                v=row.get(key,'');v=f'{v:g}' if isinstance(v,(int,float)) else str(v)
                self.table.setItem(i,j,QtWidgets.QTableWidgetItem(v))
        if self.rows:self.table.selectRow(min(selected,len(self.rows)-1))

    def collect(self):
        result=[]
        for i,original in enumerate(self.rows):
            row=copy.deepcopy(original)
            for j,(key,_,_,_) in enumerate(COLUMNS):row[key]=self.table.item(i,j).text().strip()
            result.append(row)
        return result

    def next_name(self):
        names={r.get('name') for r in self.rows};n=1
        while f'Пресет {n}' in names:n+=1
        return f'Пресет {n}'

    def add_row(self):
        self.rows=self.collect();self.rows.append(new_preset(self.next_name()));self.render(len(self.rows)-1)

    def copy_row(self):
        i=self.table.currentRow()
        if i<0:return
        self.rows=self.collect();row=copy.deepcopy(self.rows[i]);row.update(new_preset(self.next_name()))
        self.rows.append(row);self.render(len(self.rows)-1)

    def delete_row(self):
        i=self.table.currentRow()
        if i<0:return
        self.rows=self.collect();self.rows.pop(i);self.render(i)

    def capture(self):
        i=self.table.currentRow()
        if i<0:self.add_row();i=self.table.currentRow()
        self.rows=self.collect();original=copy.deepcopy(self.rows[i]);token=original['id']
        try:
            trace=int(original.get('trace') or 1)
            if trace not in range(1,7): raise ValueError('Trace: допустимо 1…6')
        except ValueError as exc:
            self.status.setText(str(exc));return
        self.set_busy(True);self.status.setText('Чтение параметров с Rigol…')
        def done(result,error):
            self.set_busy(False)
            if error:self.status.setText('Не удалось прочитать: '+str(error));return
            result['id']=token
            self.rows[i]={k:v for k,v in self.rows[i].items() if k not in {c[0] for c in COLUMNS}}
            self.rows[i].update(result);self.render(i)
            self.status.setText('Параметры прочитаны. Сохраните таблицу.')
        from .rigol_presets import capture_preset
        if not self.c.preset_task(lambda:capture_preset(self.c.rigol,original['name'],trace),done):
            self.set_busy(False);self.status.setText('Сначала подключите Rigol; дождитесь окончания текущей операции.')

    def set_busy(self,busy):
        self.busy=busy;self.table.setEnabled(not busy);self.buttons.setEnabled(not busy)
        for b in self.actions:b.setEnabled(not busy)

    def accept(self):
        if self.busy:return
        try:self.store.save(self.collect())
        except Exception as exc:self.status.setText(str(exc));return
        self.c.presets_changed.emit();super().accept()

    def reject(self):
        if not self.busy:super().reject()

    def closeEvent(self,event):
        if self.busy:event.ignore()
        else:super().closeEvent(event)
