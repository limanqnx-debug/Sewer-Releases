from __future__ import annotations

import threading
import time
from dataclasses import dataclass

import serial
from serial.tools import list_ports


@dataclass
class PowerSnapshot:
    com_available: bool = False
    responding: bool = False
    output_on: bool = False
    voltage: float = 0.0
    current: float = 0.0


class OwonSPE3102:
    def __init__(self, config: dict):
        self.config = config
        self.port: serial.Serial | None = None
        self.lock = threading.RLock()
        self.snapshot = PowerSnapshot()

    def reconfigure(self, config: dict) -> None:
        with self.lock:
            self.close()
            self.config = config

    @property
    def is_open(self) -> bool:
        return self.port is not None and self.port.is_open

    def com_available(self) -> bool:
        target = str(self.config.get("Port", ""))
        try:
            return any(p.device.upper() == target.upper() for p in list_ports.comports())
        except Exception:
            return False

    def connect(self) -> bool:
        with self.lock:
            self.close()
            cfg = self.config
            parity = {
                "None": serial.PARITY_NONE,
                "Even": serial.PARITY_EVEN,
                "Odd": serial.PARITY_ODD,
                "Mark": serial.PARITY_MARK,
                "Space": serial.PARITY_SPACE,
            }.get(str(cfg.get("Parity", "None")), serial.PARITY_NONE)
            stopbits = {"One": serial.STOPBITS_ONE, "OnePointFive": serial.STOPBITS_ONE_POINT_FIVE, "Two": serial.STOPBITS_TWO}.get(
                str(cfg.get("StopBits", "One")), serial.STOPBITS_ONE
            )
            try:
                self.port = serial.Serial(
                    port=str(cfg.get("Port", "COM3")),
                    baudrate=int(cfg.get("BaudRate", 115200)),
                    bytesize=int(cfg.get("DataBits", 8)),
                    parity=parity,
                    stopbits=stopbits,
                    timeout=max(0.05, int(cfg.get("ReadTimeout", 1000)) / 1000),
                    write_timeout=max(0.05, int(cfg.get("WriteTimeout", 1000)) / 1000),
                )
                self.snapshot.com_available = True
                return True
            except Exception:
                self.port = None
                self.snapshot.responding = False
                self.snapshot.output_on = False
                return False

    def close(self) -> None:
        with self.lock:
            if self.port:
                try:
                    self.port.close()
                except Exception:
                    pass
            self.port = None
            self.snapshot.responding = False
            self.snapshot.output_on = False
            self.snapshot.voltage = 0.0
            self.snapshot.current = 0.0

    def _write(self, command: str) -> None:
        if not self.is_open:
            raise RuntimeError("Источник не подключен")
        assert self.port is not None
        self.port.write((command + "\n").encode("ascii"))
        self.port.flush()

    def command(self, command: str) -> bool:
        with self.lock:
            try:
                self._write(command)
                return True
            except Exception:
                self.snapshot.responding = False
                return False

    def query(self, command: str) -> str:
        with self.lock:
            if not self.is_open:
                raise RuntimeError("Источник не подключен")
            assert self.port is not None
            self.port.reset_input_buffer()
            self._write(command)
            raw = self.port.readline().decode("ascii", errors="ignore").strip()
            if not raw:
                self.snapshot.responding = False
                raise TimeoutError(f"Нет ответа на {command}")
            self.snapshot.responding = True
            return raw

    def query_float(self, command: str) -> float:
        return float(self.query(command).replace(",", "."))

    def initialize(self) -> bool:
        with self.lock:
            if not self.is_open and not self.connect():
                return False
            if not self.command("OUTPut OFF"):
                return False
            self.snapshot.output_on = False
            if not self.set_voltage(float(self.config.get("Voltage", 24.0))):
                return False
            if not self.set_current_limit(float(self.config.get("CurrentLimit", 0.3))):
                return False
            try:
                self.measure_voltage()
                return True
            except Exception:
                return False

    def set_voltage(self, value: float) -> bool:
        return self.command(f"VOLTage {value:.3f}")

    def set_current_limit(self, value: float) -> bool:
        return self.command(f"CURRent {value:.3f}")

    def voltage_limit(self) -> float:
        return self.query_float("VOLTage?")

    def current_limit(self) -> float:
        return self.query_float("CURRent?")

    def confirm_limits(self) -> tuple[bool, list[str]]:
        messages: list[str] = []
        desired_v = round(float(self.config.get("Voltage", 24.0)), 3)
        desired_i = round(float(self.config.get("CurrentLimit", 0.3)), 3)
        try:
            actual_v = round(self.voltage_limit(), 3)
            actual_i = round(self.current_limit(), 3)
            if actual_v != desired_v:
                messages.append(f"Огр. напряжения {actual_v:.3f} В -> {desired_v:.3f} В")
                if not self.set_voltage(desired_v) or round(self.voltage_limit(), 3) != desired_v:
                    return False, messages
            if actual_i != desired_i:
                messages.append(f"Огр. тока {actual_i:.3f} А -> {desired_i:.3f} А")
                if not self.set_current_limit(desired_i) or round(self.current_limit(), 3) != desired_i:
                    return False, messages
            self.snapshot.responding = True
            return True, messages
        except Exception:
            self.snapshot.responding = False
            return False, messages

    def output(self, on: bool) -> bool:
        ok = self.command("OUTPut ON" if on else "OUTPut OFF")
        if ok:
            self.snapshot.output_on = bool(on)
            if not on:
                self.snapshot.voltage = 0.0
                self.snapshot.current = 0.0
        return ok

    def measure_voltage(self) -> float:
        value = self.query_float("MEASure:VOLTage?")
        self.snapshot.voltage = value
        return value

    def measure_current(self) -> float:
        value = self.query_float("MEASure:CURRent?")
        self.snapshot.current = value
        return value

    def average_current(self, samples: int, delay_ms: int, stop_check=lambda: False) -> float | None:
        values: list[float] = []
        for i in range(max(1, samples)):
            if stop_check():
                return None
            try:
                values.append(self.measure_current())
            except Exception:
                pass
            if i + 1 < samples:
                time.sleep(max(0, delay_ms) / 1000)
        if not values:
            return None
        avg = sum(values) / len(values)
        self.snapshot.current = avg
        return avg

    def probe(self) -> PowerSnapshot:
        self.snapshot.com_available = self.com_available()
        if not self.snapshot.com_available:
            self.close()
            return self.snapshot
        if not self.is_open and not self.connect():
            return self.snapshot
        try:
            self.measure_voltage()
            if self.snapshot.output_on:
                try:
                    self.measure_current()
                except Exception:
                    pass
        except Exception:
            self.snapshot.responding = False
        return self.snapshot
