from __future__ import annotations

import threading
import numpy as np
import pyvisa


class RigolRSA:
    def __init__(self, resource: str, timeout_ms: int = 2500):
        self.resource = resource
        self.timeout_ms = timeout_ms
        self.rm = None
        self.dev = None
        self.lock = threading.RLock()
        self.idn = ""

    def reconfigure(self, resource: str, timeout_ms: int | None = None) -> None:
        with self.lock:
            changed = resource != self.resource or (timeout_ms is not None and timeout_ms != self.timeout_ms)
            self.resource = resource
            if timeout_ms is not None:
                self.timeout_ms = int(timeout_ms)
            if changed:
                self.close()

    def connect(self) -> str:
        with self.lock:
            self.close()
            self.rm = pyvisa.ResourceManager()
            self.dev = self.rm.open_resource(self.resource)
            self.dev.timeout = self.timeout_ms
            self.dev.read_termination = "\n"
            self.dev.write_termination = "\n"
            self.idn = self.query("*IDN?")
            return self.idn

    def close(self) -> None:
        with self.lock:
            try:
                if self.dev:
                    self.dev.close()
            except Exception:
                pass
            finally:
                self.dev = None
            try:
                if self.rm:
                    self.rm.close()
            except Exception:
                pass
            finally:
                self.rm = None
            self.idn = ""

    @property
    def connected(self) -> bool:
        return self.dev is not None

    def write(self, cmd: str) -> None:
        with self.lock:
            if not self.dev:
                raise RuntimeError("Rigol не подключен")
            self.dev.write(cmd)

    def query(self, cmd: str) -> str:
        with self.lock:
            if not self.dev:
                raise RuntimeError("Rigol не подключен")
            return self.dev.query(cmd).strip()

    def query_float(self, cmd: str) -> float:
        return float(self.query(cmd))

    def identity_ok(self, manufacturer="RIGOL", model="RSA5065N") -> bool:
        try:
            if not self.connected:
                self.connect()
            self.idn = self.query("*IDN?")
            up = self.idn.upper()
            return manufacturer.upper() in up and model.upper() in up
        except Exception:
            self.close()
            return False

    def mode(self) -> str:
        raw = self.query(":INSTrument:SELect?").upper()
        return "RTSA" if "RTSA" in raw else "GPSA"

    def set_mode(self, mode: str) -> None:
        self.write(":INSTrument:SELect " + ("RTSA" if mode.upper() == "RTSA" else "SA"))

    def center_hz(self): return self.query_float(":SENSe:FREQuency:CENTer?")
    def span_hz(self): return self.query_float(":SENSe:FREQuency:SPAN?")
    def set_center_hz(self, v): self.write(f":SENSe:FREQuency:CENTer {float(v)}")
    def set_span_hz(self, v): self.write(f":SENSe:FREQuency:SPAN {float(v)}")

    def ref_level(self): return self.query_float(":DISPlay:WINDow:TRACe:Y:SCALe:RLEVel?")
    def ref_offset(self): return self.query_float(":DISPlay:WINDow:TRACe:Y:SCALe:RLEVel:OFFSet?")
    def scale_div(self): return self.query_float(":DISPlay:WINDow:TRACe:Y:SCALe:PDIVision?")
    def attenuation(self): return self.query_float(":SENSe:POWer:RF:ATTenuation?")
    def set_ref_level(self, v): self.write(f":DISPlay:WINDow:TRACe:Y:SCALe:RLEVel {float(v)}")
    def set_ref_offset(self, v): self.write(f":DISPlay:WINDow:TRACe:Y:SCALe:RLEVel:OFFSet {float(v)}")
    def set_scale_div(self, v): self.write(f":DISPlay:WINDow:TRACe:Y:SCALe:PDIVision {int(round(float(v)))}")
    def set_attenuation(self, v): self.write(f":SENSe:POWer:RF:ATTenuation {float(v)}")

    def rbw(self): return self.query_float(":SENSe:BANDwidth:RESolution?")
    def vbw(self): return self.query_float(":SENSe:BANDwidth:VIDeo?")
    def set_rbw(self, hz): self.write(f":SENSe:BANDwidth:RESolution {float(hz)}")
    def set_vbw(self, hz): self.write(f":SENSe:BANDwidth:VIDeo {float(hz)}")
    def set_rbw_auto(self, on): self.write(f":SENSe:BANDwidth:RESolution:AUTO {'ON' if on else 'OFF'}")
    def set_vbw_auto(self, on): self.write(f":SENSe:BANDwidth:VIDeo:AUTO {'ON' if on else 'OFF'}")

    def sweep_time(self): return self.query_float(":SENSe:SWEep:TIME?")
    def sweep_points(self): return int(round(self.query_float(":SENSe:SWEep:POINts?")))
    def set_sweep_time(self, sec): self.write(f":SENSe:SWEep:TIME {float(sec)}")
    def set_sweep_time_auto(self, on): self.write(f":SENSe:SWEep:TIME:AUTO {'ON' if on else 'OFF'}")
    def set_sweep_points(self, pts): self.write(f":SENSe:SWEep:POINts {int(pts)}")
    def continuous(self, on=True): self.write(f":INITiate:CONTinuous {'ON' if on else 'OFF'}")
    def single(self):
        self.continuous(False)
        self.write(":INITiate:IMMediate")

    def trace_type(self, n): return self.query(f":TRACe{n}:TYPE?")
    def set_trace_type(self, n, typ): self.write(f":TRACe{n}:TYPE {typ}")
    def set_trace_display(self, n, on): self.write(f":TRACe{n}:DISPlay:STATe {'ON' if on else 'OFF'}")
    def set_trace_update(self, n, on): self.write(f":TRACe{n}:UPDate:STATe {'ON' if on else 'OFF'}")

    def trace_ascii(self, n=1) -> np.ndarray:
        self.write(":FORMat:TRACe:DATA ASCii")
        raw = self.query(f":TRACe:DATA? TRACE{int(n)}")
        return np.fromstring(raw, sep=",", dtype=float)
