from __future__ import annotations

import threading
from dataclasses import dataclass
import numpy as np
import pyvisa


@dataclass(frozen=True)
class SpectrumFrame:
    trace: int
    mode: str
    x: np.ndarray
    y: np.ndarray
    x_label: str
    x_unit: str
    y_unit: str


def parse_trace_ascii(raw: str) -> np.ndarray:
    """Reject empty or partial replies instead of silently plotting truncated data."""
    payload = raw.lstrip()
    if payload.startswith("#"):
        if len(payload) < 2 or payload[1] not in "123456789":
            raise ValueError("Некорректный заголовок данных Trace")
        digits = int(payload[1])
        size_text = payload[2:2 + digits]
        if len(size_text) != digits or not size_text.isdecimal():
            raise ValueError("Некорректная длина данных Trace")
        size = int(size_text)
        start = 2 + digits
        if len(payload) < start + size or payload[start + size:].strip():
            raise ValueError("Неполный ответ Trace")
        payload = payload[start:start + size].strip()
    else:
        payload = payload.strip()
    parts = payload.split(",")
    if parts and not parts[-1].strip():
        parts.pop()
    if len(parts) < 2:
        raise ValueError("Rigol не вернул точки Trace; проверьте выбранную трассу и развёртку")
    try:
        values = np.array([float(part) for part in parts], dtype=float)
    except ValueError as exc:
        raise ValueError("Ответ Trace содержит нечисловые данные") from exc
    if not np.isfinite(values).all() or (np.abs(values) >= 1e30).any():
        raise ValueError("Trace содержит недействительные значения измерений")
    return values


class RigolRSA:
    def __init__(self, resource: str, timeout_ms: int = 2500):
        self.resource = resource
        self.timeout_ms = timeout_ms
        self.rm = None
        self.dev = None
        self.lock = threading.RLock()
        self.idn = ""

    def reconfigure(self, resource: str, timeout_ms: int | None = None) -> None:
        with self.lock:
            changed = resource != self.resource or (timeout_ms is not None and timeout_ms != self.timeout_ms)
            self.resource = resource
            if timeout_ms is not None:
                self.timeout_ms = int(timeout_ms)
            if changed:
                self.close()

    def connect(self) -> str:
        with self.lock:
            self.close()
            self.rm = pyvisa.ResourceManager()
            self.dev = self.rm.open_resource(self.resource)
            self.dev.timeout = self.timeout_ms
            self.dev.read_termination = "\n"
            self.dev.write_termination = "\n"
            self.idn = self.query("*IDN?")
            return self.idn

    def close(self) -> None:
        with self.lock:
            try:
                if self.dev:
                    self.dev.close()
            except Exception:
                pass
            finally:
                self.dev = None
            try:
                if self.rm:
                    self.rm.close()
            except Exception:
                pass
            finally:
                self.rm = None
            self.idn = ""

    @property
    def connected(self) -> bool:
        return self.dev is not None

    def write(self, cmd: str) -> None:
        with self.lock:
            if not self.dev:
                raise RuntimeError("Rigol не подключен")
            self.dev.write(cmd)

    def query(self, cmd: str) -> str:
        with self.lock:
            if not self.dev:
                raise RuntimeError("Rigol не подключен")
            return self.dev.query(cmd).strip()

    def query_float(self, cmd: str) -> float:
        return float(self.query(cmd))

    def identity_ok(self, manufacturer="RIGOL", model="RSA5065N") -> bool:
        try:
            if not self.connected:
                self.connect()
            self.idn = self.query("*IDN?")
            up = self.idn.upper()
            return manufacturer.upper() in up and model.upper() in up
        except Exception:
            self.close()
            return False

    def mode(self) -> str:
        raw = self.query(":INSTrument:SELect?").upper()
        return "RTSA" if "RTSA" in raw else "GPSA"

    def set_mode(self, mode: str) -> None:
        self.write(":INSTrument:SELect " + ("RTSA" if mode.upper() == "RTSA" else "SA"))

    def center_hz(self): return self.query_float(":SENSe:FREQuency:CENTer?")
    def span_hz(self): return self.query_float(":SENSe:FREQuency:SPAN?")
    def set_center_hz(self, v): self.write(f":SENSe:FREQuency:CENTer {float(v)}")
    def set_span_hz(self, v): self.write(f":SENSe:FREQuency:SPAN {float(v)}")

    def ref_level(self): return self.query_float(":DISPlay:WINDow:TRACe:Y:SCALe:RLEVel?")
    def ref_offset(self): return self.query_float(":DISPlay:WINDow:TRACe:Y:SCALe:RLEVel:OFFSet?")
    def scale_div(self): return self.query_float(":DISPlay:WINDow:TRACe:Y:SCALe:PDIVision?")
    def attenuation(self): return self.query_float(":SENSe:POWer:RF:ATTenuation?")
    def set_ref_level(self, v): self.write(f":DISPlay:WINDow:TRACe:Y:SCALe:RLEVel {float(v)}")
    def set_ref_offset(self, v): self.write(f":DISPlay:WINDow:TRACe:Y:SCALe:RLEVel:OFFSet {float(v)}")
    def set_scale_div(self, v): self.write(f":DISPlay:WINDow:TRACe:Y:SCALe:PDIVision {int(round(float(v)))}")
    def set_attenuation(self, v): self.write(f":SENSe:POWer:RF:ATTenuation {float(v)}")

    def rbw(self): return self.query_float(":SENSe:BANDwidth:RESolution?")
    def vbw(self): return self.query_float(":SENSe:BANDwidth:VIDeo?")
    def set_rbw(self, hz): self.write(f":SENSe:BANDwidth:RESolution {float(hz)}")
    def set_vbw(self, hz): self.write(f":SENSe:BANDwidth:VIDeo {float(hz)}")
    def set_rbw_auto(self, on): self.write(f":SENSe:BANDwidth:RESolution:AUTO {'ON' if on else 'OFF'}")
    def set_vbw_auto(self, on): self.write(f":SENSe:BANDwidth:VIDeo:AUTO {'ON' if on else 'OFF'}")

    def sweep_time(self): return self.query_float(":SENSe:SWEep:TIME?")
    def sweep_points(self): return int(round(self.query_float(":SENSe:SWEep:POINts?")))
    def set_sweep_time(self, sec): self.write(f":SENSe:SWEep:TIME {float(sec)}")
    def set_sweep_time_auto(self, on): self.write(f":SENSe:SWEep:TIME:AUTO {'ON' if on else 'OFF'}")
    def set_sweep_points(self, pts): self.write(f":SENSe:SWEep:POINts {int(pts)}")
    def continuous(self, on=True): self.write(f":INITiate:CONTinuous {'ON' if on else 'OFF'}")
    def single(self):
        self.continuous(False)
        self.write(":INITiate:IMMediate")

    def trace_type(self, n): return self.query(f":TRACe{n}:TYPE?")
    def set_trace_type(self, n, typ): self.write(f":TRACe{n}:TYPE {typ}")
    def set_trace_display(self, n, on): self.write(f":TRACe{n}:DISPlay:STATe {'ON' if on else 'OFF'}")
    def set_trace_update(self, n, on): self.write(f":TRACe{n}:UPDate:STATe {'ON' if on else 'OFF'}")

    def trace_ascii(self, n=1) -> np.ndarray:
        n = int(n)
        if n not in range(1, 7):
            raise ValueError("Номер Trace должен быть от 1 до 6")
        with self.lock:
            self.write(":FORMat:TRACe:DATA ASCii")
            # Keep the complete reply: stripping a block can change its declared length.
            raw = self.dev.query(f":TRACe:DATA? TRACE{n}")
            return parse_trace_ascii(raw)

    def spectrum(self, n=1) -> SpectrumFrame:
        # Keep trace data and its axes together while other threads monitor/control VISA.
        with self.lock:
            mode = self.mode()
            if mode == "RTSA" and self.query(":CONFigure?").upper() in ("PVT", "PSP", "PSGR"):
                raise ValueError("Для спектра RTSA выберите на Rigol вид Normal или Density")
            center, span = self.center_hz(), self.span_hz()
            if not np.isfinite([center, span]).all() or span < 0:
                raise ValueError("Rigol вернул некорректный частотный диапазон")
            unit = self.query(":UNIT:POWer?").upper()
            units = {"DBM": "dBm", "DBMV": "dBmV", "DBUV": "dBµV", "V": "V", "W": "W"}
            if unit not in units:
                raise ValueError("Неизвестная единица уровня Rigol: " + unit)
            duration = self.sweep_time() if span == 0 else None
            if duration is not None and (not np.isfinite(duration) or duration <= 0):
                raise ValueError("Rigol вернул некорректное время развёртки")
            y = self.trace_ascii(n)
            if span == 0:
                x = np.linspace(0, duration * 1000, y.size)
                label, x_unit = "Время", "ms"
            else:
                x = np.linspace((center - span / 2) / 1e6, (center + span / 2) / 1e6, y.size)
                label, x_unit = "Частота", "MHz"
            return SpectrumFrame(int(n), mode, x, y, label, x_unit, units[unit])
