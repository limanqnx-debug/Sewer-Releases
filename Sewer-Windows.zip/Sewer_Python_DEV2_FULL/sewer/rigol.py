from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
import numpy as np
import pyvisa


class RigolConnectionError(RuntimeError):
    """The VISA session was closed and must be opened again."""


@dataclass(frozen=True)
class SpectrumFrame:
    trace: int
    mode: str
    x: np.ndarray
    y: np.ndarray
    x_label: str
    x_unit: str
    y_unit: str
    center_hz: float
    span_hz: float
    trace_type: str | None
    display_on: bool | None
    update_on: bool | None
    view: str
    ref_level: float | None
    scale_div: float | None
    scale_spacing: str | None
    diagnostic: dict
    warnings: tuple[str, ...] = ()

    @property
    def y_limits(self):
        # The trace is logarithmic. Do not invent a conversion for linear units.
        if self.y_unit == "dBm" and self.scale_spacing == "LOG" and self.ref_level is not None and self.scale_div is not None:
            return self.ref_level - 10 * self.scale_div, self.ref_level
        return None


def parse_trace_ascii(raw: str) -> np.ndarray:
    """Reject empty or partial replies instead of silently plotting truncated data."""
    payload = raw.lstrip()
    if payload.startswith("#"):
        if len(payload) < 2 or payload[1] not in "123456789":
            raise ValueError("Некорректный заголовок данных Trace")
        digits = int(payload[1])
        size_text = payload[2:2 + digits]
        if len(size_text) != digits or not size_text.isdecimal():
            raise ValueError("Некорректная длина данных Trace")
        size = int(size_text)
        start = 2 + digits
        if len(payload) < start + size or payload[start + size:].strip():
            raise ValueError("Неполный ответ Trace")
        payload = payload[start:start + size].strip()
    else:
        payload = payload.strip()
    parts = payload.split(",")
    if parts and not parts[-1].strip():
        parts.pop()
    if len(parts) < 2:
        raise ValueError("Rigol не вернул точки Trace; проверьте выбранную трассу и развёртку")
    try:
        values = np.array([float(part) for part in parts], dtype=float)
    except ValueError as exc:
        raise ValueError("Ответ Trace содержит нечисловые данные") from exc
    if not np.isfinite(values).all() or (np.abs(values) >= 1e30).any():
        raise ValueError("Trace содержит недействительные значения измерений")
    return values


class RigolRSA:
    def __init__(self, resource: str, timeout_ms: int = 2500):
        self.resource = resource
        self.timeout_ms = timeout_ms
        self.rm = None
        self.dev = None
        self.lock = threading.RLock()
        self.idn = ""
        self.last_error = ""
        self.last_capture = None
        self._spectrum_audit = None
        self._readbacks = {}

    def reconfigure(self, resource: str, timeout_ms: int | None = None) -> None:
        with self.lock:
            changed = resource != self.resource or (timeout_ms is not None and timeout_ms != self.timeout_ms)
            self.resource = resource
            if timeout_ms is not None:
                self.timeout_ms = int(timeout_ms)
            if changed:
                self.close()

    def connect(self, manufacturer="RIGOL", model="RSA5065N") -> str:
        with self.lock:
            self.close()
            try:
                self.rm = pyvisa.ResourceManager()
                self.dev = self.rm.open_resource(self.resource)
                self.dev.timeout = self.timeout_ms
                self.dev.read_termination = "\n"
                self.dev.write_termination = "\n"
                self.dev.chunk_size = 1024 * 1024
                self._check_identity(self.query("*IDN?"), manufacturer, model)
                return self.idn
            except RigolConnectionError:
                raise
            except Exception as exc:
                raise self._drop_connection("Подключение Rigol", exc) from exc

    def _check_identity(self, reply, manufacturer, model):
        fields = reply.upper().split(",")
        if len(fields) < 2 or manufacturer.upper() not in fields[0] or model.upper() not in fields[1]:
            raise self._drop_connection("*IDN?", ValueError("Ожидался " + manufacturer + " " + model + "; получено: " + reply[:200]))
        self.idn = reply
        self.last_error = ""

    def _drop_connection(self, command, error):
        self.last_error = f"{command}: {error}"
        # Abort the pending response before closing USB/VXI-11/HiSLIP. No SCPI
        # queries are sent on a session whose input may contain a partial trace.
        if self.dev is not None and self.resource.upper().endswith("::INSTR"):
            try:
                self.dev.clear()
            except Exception:
                pass
        self.close()
        return RigolConnectionError(self.last_error)

    def close(self) -> None:
        with self.lock:
            try:
                if self.dev:
                    self.dev.close()
            except Exception:
                pass
            finally:
                self.dev = None
            try:
                if self.rm:
                    self.rm.close()
            except Exception:
                pass
            finally:
                self.rm = None
            self.idn = ""
            self._readbacks.clear()

    @property
    def connected(self) -> bool:
        return self.dev is not None

    def write(self, cmd: str) -> None:
        with self.lock:
            if not self.dev:
                raise RuntimeError("Rigol не подключен")
            entry = {"write": cmd}
            try:
                self.dev.write(cmd)
            except (pyvisa.errors.VisaIOError, pyvisa.errors.InvalidSession, OSError) as exc:
                entry["error"] = str(exc)
                raise self._drop_connection(cmd, exc) from exc
            finally:
                if self._spectrum_audit is not None:
                    self._spectrum_audit.append(entry)

    def _read_trace_reply(self, cmd, entry):
        # Keep LF termination enabled for every transport. read_raw preserves LF;
        # a definite-length block can therefore be assembled over several reads
        # without requiring a VISA EOM indication from the instrument/driver.
        self.dev.write(cmd)
        data = bytearray()
        target = None
        started = time.monotonic()
        try:
            while True:
                chunk = self.dev.read_raw()
                data.extend(chunk)
                if len(data) > 2 * 1024 * 1024:
                    raise self._drop_connection(cmd, ValueError("Ответ Trace превышает 2 MiB"))
                if target is None:
                    payload = data.lstrip()
                    if not payload.startswith(b"#"):
                        return data.decode("ascii")
                    if len(payload) >= 2:
                        if payload[1:2] not in b"123456789":
                            raise self._drop_connection(cmd, ValueError("Некорректный заголовок данных Trace"))
                        digits = int(payload[1:2])
                        if len(payload) >= 2 + digits:
                            size_text = payload[2:2 + digits]
                            if not size_text.isdigit():
                                raise self._drop_connection(cmd, ValueError("Некорректная длина данных Trace"))
                            size = int(size_text)
                            if size > 2 * 1024 * 1024:
                                raise self._drop_connection(cmd, ValueError("Ответ Trace превышает 2 MiB"))
                            target = len(data) - len(payload) + 2 + digits + size
                if target is not None and len(data) >= target:
                    return data.decode("ascii")
                if not chunk:
                    raise self._drop_connection(cmd, ValueError("Неполный ответ Trace"))
                if time.monotonic() - started >= self.timeout_ms / 1000:
                    raise TimeoutError("Истекло время чтения блока Trace")
        finally:
            entry["response"] = data.decode("ascii", errors="replace")

    def _query_raw(self, cmd: str, *, trace=False) -> str:
        with self.lock:
            if not self.dev:
                raise RuntimeError("Rigol не подключен")
            entry = {"query": cmd}
            started = time.monotonic()
            try:
                raw = self._read_trace_reply(cmd, entry) if trace else self.dev.query(cmd)
                entry["response"] = raw
                return raw
            except Exception as exc:
                entry["error"] = str(exc)
                if isinstance(exc, (pyvisa.errors.VisaIOError, pyvisa.errors.InvalidSession, OSError)):
                    raise self._drop_connection(cmd, exc) from exc
                raise
            finally:
                entry["elapsed_ms"] = round((time.monotonic() - started) * 1000, 3)
                if self._spectrum_audit is not None:
                    self._spectrum_audit.append(entry)

    def query(self, cmd: str) -> str:
        with self.lock:
            raw = self._query_raw(cmd).strip()
            self._readbacks[cmd] = (raw, time.monotonic())
            return raw

    def query_float(self, cmd: str) -> float:
        return float(self.query(cmd))

    def query_bool(self, cmd: str) -> bool:
        value = self.query(cmd).upper()
        if value in ("1", "ON"):
            return True
        if value in ("0", "OFF"):
            return False
        raise ValueError(f"Неожиданный ответ на {cmd}: {value}")

    def identity_ok(self, manufacturer="RIGOL", model="RSA5065N") -> bool:
        with self.lock:
            try:
                if not self.connected:
                    self.connect(manufacturer, model)
                else:
                    self._check_identity(self.query("*IDN?"), manufacturer, model)
                return True
            except Exception as exc:
                if not isinstance(exc, RigolConnectionError):
                    self._drop_connection("Проверка Rigol", exc)
                return False

    def mode(self) -> str:
        raw = self.query(":INSTrument:SELect?").upper().strip('"')
        if raw in ("SA", "GPSA"):
            return "GPSA"
        if raw == "RTSA":
            return "RTSA"
        raise ValueError("Для спектра поддерживаются GPSA и RTSA; ответ Rigol: " + raw)

    def set_mode(self, mode: str) -> None:
        self.write(":INSTrument:SELect " + ("RTSA" if mode.upper() == "RTSA" else "SA"))

    def center_hz(self): return self.query_float(":SENSe:FREQuency:CENTer?")
    def span_hz(self): return self.query_float(":SENSe:FREQuency:SPAN?")
    def set_center_hz(self, v): self.write(f":SENSe:FREQuency:CENTer {float(v)}")
    def set_span_hz(self, v): self.write(f":SENSe:FREQuency:SPAN {float(v)}")

    def ref_level(self): return self.query_float(":DISPlay:WINDow:TRACe:Y:SCALe:RLEVel?")
    def ref_offset(self): return self.query_float(":DISPlay:WINDow:TRACe:Y:SCALe:RLEVel:OFFSet?")
    def scale_div(self): return self.query_float(":DISPlay:WINDow:TRACe:Y:SCALe:PDIVision?")
    def attenuation(self): return self.query_float(":SENSe:POWer:RF:ATTenuation?")
    def set_ref_level(self, v): self.write(f":DISPlay:WINDow:TRACe:Y:SCALe:RLEVel {float(v)}")
    def set_ref_offset(self, v): self.write(f":DISPlay:WINDow:TRACe:Y:SCALe:RLEVel:OFFSet {float(v)}")
    def set_scale_div(self, v): self.write(f":DISPlay:WINDow:TRACe:Y:SCALe:PDIVision {int(round(float(v)))}")
    def set_attenuation(self, v): self.write(f":SENSe:POWer:RF:ATTenuation {float(v)}")

    def rbw(self): return self.query_float(":SENSe:BANDwidth:RESolution?")
    def vbw(self): return self.query_float(":SENSe:BANDwidth:VIDeo?")
    def set_rbw(self, hz): self.write(f":SENSe:BANDwidth:RESolution {float(hz)}")
    def set_vbw(self, hz): self.write(f":SENSe:BANDwidth:VIDeo {float(hz)}")
    def set_rbw_auto(self, on): self.write(f":SENSe:BANDwidth:RESolution:AUTO {'ON' if on else 'OFF'}")
    def set_vbw_auto(self, on): self.write(f":SENSe:BANDwidth:VIDeo:AUTO {'ON' if on else 'OFF'}")

    def sweep_time(self): return self.query_float(":SENSe:SWEep:TIME?")
    def sweep_points(self): return int(round(self.query_float(":SENSe:SWEep:POINts?")))
    def set_sweep_time(self, sec): self.write(f":SENSe:SWEep:TIME {float(sec)}")
    def set_sweep_time_auto(self, on): self.write(f":SENSe:SWEep:TIME:AUTO {'ON' if on else 'OFF'}")
    def set_sweep_points(self, pts): self.write(f":SENSe:SWEep:POINts {int(pts)}")
    def continuous(self, on=True): self.write(f":INITiate:CONTinuous {'ON' if on else 'OFF'}")
    def single(self):
        self.continuous(False)
        self.write(":INITiate:IMMediate")

    def trace_type(self, n): return self.query(f":TRACe{n}:TYPE?")
    def trace_display(self, n): return self.query_bool(f":TRACe{n}:DISPlay:STATe?")
    def trace_update(self, n): return self.query_bool(f":TRACe{n}:UPDate:STATe?")

    def visible_traces(self):
        with self.lock:
            traces = range(1, 7)
            if self.mode() == "RTSA" and self.query(":CONFigure?").upper() in ("DENS", "DSPE", "PVT", "PSP", "PSGR"):
                traces = (1,)
            return [n for n in traces if self.trace_display(n)]
    def set_trace_type(self, n, typ): self.write(f":TRACe{n}:TYPE {typ}")
    def set_trace_display(self, n, on): self.write(f":TRACe{n}:DISPlay:STATe {'ON' if on else 'OFF'}")
    def set_trace_update(self, n, on): self.write(f":TRACe{n}:UPDate:STATe {'ON' if on else 'OFF'}")

    def trace_ascii(self, n=1) -> np.ndarray:
        n = int(n)
        if n not in range(1, 7):
            raise ValueError("Номер Trace должен быть от 1 до 6")
        with self.lock:
            self.write(":FORMat:TRACe:DATA ASCii")
            raw = self._query_raw(f":TRACe:DATA? TRACE{n}", trace=True)
            return parse_trace_ascii(raw)

    def _cached_metadata(self, command, convert, capture):
        cached = self._readbacks.get(command)
        if cached is None:
            return None
        raw, when = cached
        capture.setdefault("cached_metadata", {})[command] = {
            "response": raw, "age_seconds": round(time.monotonic() - when, 3),
        }
        try:
            value = convert(raw)
            if isinstance(value, float) and not np.isfinite(value):
                return None
            return value
        except (ValueError, TypeError):
            return None

    def spectrum(self, n=1) -> SpectrumFrame:
        with self.lock:
            capture = {
                "schema": 1, "captured_at_utc": datetime.now(timezone.utc).isoformat(),
                "resource": self.resource, "idn": self.idn, "trace": int(n), "commands": [],
            }
            self._spectrum_audit = capture["commands"]
            try:
                return self._spectrum(n, capture)
            except Exception as exc:
                capture["error"] = str(exc)
                raise
            finally:
                self._spectrum_audit = None
                # Publish only a completed capture; GUI export never waits on VISA.
                self.last_capture = capture

    def _spectrum(self, n, capture) -> SpectrumFrame:
        # Keep trace data and its axes together while other threads monitor/control VISA.
        with self.lock:
            mode = self.mode()
            view = "SA"
            if mode == "RTSA":
                view = self.query(":CONFigure?").upper()
                if view in ("PVT", "PSP", "PSGR"):
                    raise ValueError("Для спектра RTSA выберите на Rigol вид Normal или Density")
                if view in ("DENS", "DSPE") and int(n) != 1:
                    raise ValueError("В виде Density доступна только Trace 1")
            center, span = self.center_hz(), self.span_hz()
            if not np.isfinite([center, span]).all() or span < 0:
                raise ValueError("Rigol вернул некорректный частотный диапазон")
            unit = self.query(":UNIT:POWer?").upper()
            units = {"DBM": "dBm", "DBMV": "dBmV", "DBUV": "dBµV", "V": "V", "W": "W"}
            if unit not in units:
                raise ValueError("Неизвестная единица уровня Rigol: " + unit)
            duration = self.sweep_time() if span == 0 else None
            if duration is not None and (not np.isfinite(duration) or duration <= 0):
                raise ValueError("Rigol вернул некорректное время развёртки")
            y = self.trace_ascii(n)
            capture["samples"] = y.tolist()
            capture["received_points"] = int(y.size)
            # Displaying a valid trace must not depend on ancillary queries. Reuse
            # readbacks from control fields, with their age recorded in diagnostics.
            ref = self._cached_metadata(":DISPlay:WINDow:TRACe:Y:SCALe:RLEVel?", float, capture)
            scale = self._cached_metadata(":DISPlay:WINDow:TRACe:Y:SCALe:PDIVision?", float, capture)
            if scale is not None and scale <= 0:
                scale = None
            spacing = self._cached_metadata(":DISPlay:WINDow:TRACe:Y:SCALe:SPACing?", str.upper, capture)
            typ = self._cached_metadata(f":TRACe{n}:TYPE?", str.strip, capture)
            def boolean(raw):
                if raw.upper() in ("ON", "1"): return True
                if raw.upper() in ("OFF", "0"): return False
                raise ValueError("Unknown trace state")
            displayed = self._cached_metadata(f":TRACe{n}:DISPlay:STATe?", boolean, capture)
            updating = self._cached_metadata(f":TRACe{n}:UPDate:STATe?", boolean, capture)
            expected_points = self._cached_metadata(":SENSe:SWEep:POINts?", lambda raw: int(float(raw)), capture) if mode == "GPSA" else None
            notes = []
            mismatch = expected_points is not None and expected_points != y.size
            if mismatch:
                # A front-panel change can invalidate the previous field readback.
                try:
                    expected_points = self.sweep_points()
                    mismatch = expected_points != y.size
                except RigolConnectionError:
                    raise
                except Exception as exc:
                    notes.append("Sweep Points не прочитаны: " + str(exc))
            capture["expected_points"] = expected_points
            if mismatch:
                x = np.arange(y.size, dtype=float)
                label, x_unit = "Номер точки", ""
                notes.append(f"Получено {y.size} точек; Sweep Points = {expected_points}. Показаны все точки, X — номер точки.")
            elif span == 0:
                x = np.linspace(0, duration * 1000, y.size)
                label, x_unit = "Время", "ms"
            else:
                x = np.linspace((center - span / 2) / 1e6, (center + span / 2) / 1e6, y.size)
                label, x_unit = "Частота", "MHz"
            capture["frame"] = {
                "mode": mode, "view": view, "x_label": label, "x_unit": x_unit,
                "y_unit": units[unit], "center_hz": center, "span_hz": span,
                "ref_level": ref, "scale_div": scale, "scale_spacing": spacing,
                "trace_type": typ, "display_on": displayed, "update_on": updating,
                "x": x.tolist(),
            }
            capture["warnings"] = notes
            return SpectrumFrame(int(n), mode, x, y, label, x_unit, units[unit], center, span, typ, displayed, updating,
                                 view, ref, scale, spacing, capture, tuple(notes))
