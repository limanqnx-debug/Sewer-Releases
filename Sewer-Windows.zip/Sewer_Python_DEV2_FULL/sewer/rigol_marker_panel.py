from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
import time

from PySide6 import QtCore, QtGui, QtWidgets
import pyqtgraph as pg

from .number_input import NumberInput
from .rigol import RigolConnectionError
from .rigol_markers import RigolMarkerControl


COLORS = ("#ffcf5a", "#f58cae", "#6edacb", "#b69cff", "#ffad68", "#91ceff", "#b4dc69", "#ec9de5")
LIGHT_COLORS = ("#835300", "#a32057", "#08736d", "#6438b4", "#9a4100", "#075c9c", "#4c7212", "#942780")


class MarkerReader(QtCore.QObject):
    updated = QtCore.Signal(object)
    status = QtCore.Signal(str, bool)
    action_done = QtCore.Signal(object)
    _finished = QtCore.Signal(object, object, str, object, object, object)

    def __init__(self, rigol, parent=None):
        super().__init__(parent)
        self.rigol = rigol
        self.control = RigolMarkerControl(rigol)
        self.frame = None
        self.snapshot = None
        self.enabled = True
        self.live = True
        self.active = False
        self.closed = False
        self._poll_pending = False
        self._action_pending = False
        self._generation = 0
        self._key = None
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="RigolMarkers")
        self._finished.connect(self._complete)
        self.timer = QtCore.QTimer(self)
        self.timer.setInterval(1500)
        self.timer.timeout.connect(self.refresh)

    def set_active(self, active):
        self.active = bool(active)
        if self.closed:
            return
        if active:
            self.timer.start()
        else:
            self.timer.stop()
            self._generation += 1

    def set_frame(self, frame):
        self.frame = frame
        key = None if frame is None else (frame.mode, frame.view, frame.center_hz, frame.span_hz,
                                         frame.y_unit, float(frame.x[-1]))
        if key != self._key:
            self._key = key
            self.invalidate()
            # Wait for the regular timer: do not add queries to every Live frame.

    def invalidate(self):
        self._generation += 1
        self.snapshot = None
        self.updated.emit(None)

    def set_enabled(self, enabled):
        self.enabled = bool(enabled)
        self.invalidate()
        if enabled:
            self.refresh(force=True)

    def refresh(self, force=False):
        if (self.closed or not self.active or not self.enabled or not self.rigol.connected
                or self.frame is None or self._poll_pending or self._action_pending or (not force and not self.live)):
            return
        self._poll_pending = True
        self._submit("poll", None)

    def command(self, function):
        if self.closed or not self.active or self._action_pending:
            return False
        if not self.rigol.connected:
            self.status.emit("Нет связи с Rigol", True)
            return False
        self.invalidate()
        self._action_pending = True
        self.status.emit("Выполняется команда маркера…", False)
        self._submit("action", function)
        return True

    def _submit(self, kind, function):
        generation, device = self._generation, self.rigol.dev
        def run():
            with self.rigol.lock:
                if self.closed or not self.active or self.rigol.dev is not device:
                    return None, None
                result = function() if function is not None else None
                # State and actual X/Y values are read back after every command.
                return self.control.read(), result
        future = self._executor.submit(run)
        def finished(f):
            try:
                snapshot, result = f.result()
                error = None
            except Exception as exc:
                snapshot, result, error = None, None, exc
            if not self.closed:
                self._finished.emit(generation, device, kind, snapshot, result, error)
        future.add_done_callback(finished)

    @QtCore.Slot(object, object, str, object, object, object)
    def _complete(self, generation, device, kind, snapshot, result, error):
        if kind == "action":
            self._action_pending = False
        else:
            self._poll_pending = False
        if self.closed:
            return
        if isinstance(error, RigolConnectionError):
            self.enabled = False
            self.invalidate()
            self.status.emit("Опрос маркеров остановлен: " + str(error), True)
            if kind == "action":
                self.action_done.emit(None)
            return
        if device is not self.rigol.dev or not self.active:
            if kind == "action":
                self.action_done.emit(None)
            return
        if kind == "poll" and generation != self._generation:
            return
        if error is not None:
            self.invalidate()
            self.status.emit("Маркеры: " + str(error), True)
        elif snapshot is not None:
            self.snapshot = snapshot
            self.updated.emit(snapshot)
            errors = [f"M{m.number}: {m.error}" for m in snapshot.markers if m.error]
            self.status.emit("; ".join(errors) if errors else "Маркеры прочитаны с Rigol · опрос 1,5 с", bool(errors))
        if kind == "action":
            self.action_done.emit(result)

    def close(self):
        self.closed = True
        self.active = False
        self.timer.stop()
        self._executor.shutdown(wait=False, cancel_futures=True)


class MarkerPanel(QtWidgets.QWidget):
    def __init__(self, dialog):
        super().__init__(dialog)
        self.dialog = dialog
        self.reader = MarkerReader(dialog.rigol, self)
        self.frame = None
        self._editor_dirty = False
        self._editor_context = None
        self._build()
        self.reader.updated.connect(self.show_snapshot)
        self.reader.status.connect(self.show_status)
        self.reader.action_done.connect(self.action_done)
        self._refresh_timer = QtCore.QTimer(self)
        self._refresh_timer.setInterval(30)
        self._refresh_timer.timeout.connect(self._refresh_after_action)

    def _build(self):
        layout = QtWidgets.QVBoxLayout(self)
        form = QtWidgets.QFormLayout()
        layout.addLayout(form)
        self.number = QtWidgets.QComboBox()
        self.number.addItems([f"M{i}" for i in range(1, 9)])
        self.number.currentIndexChanged.connect(self.select_marker)
        form.addRow("Маркер", self.number)
        self.mode = QtWidgets.QComboBox()
        for label, value in (("Выключен", "OFF"), ("Normal", "POS"), ("Delta", "DELT"), ("Fixed", "FIX")):
            self.mode.addItem(label, value)
        form.addRow("Режим", self.mode)
        self.trace = QtWidgets.QComboBox()
        self.trace.addItems([str(i) for i in range(1, 7)])
        form.addRow("Trace", self.trace)
        self.reference = QtWidgets.QComboBox()
        self.reference.addItems([f"M{i}" for i in range(1, 9)])
        self.reference.setCurrentIndex(1)
        form.addRow("Опорный для Δ", self.reference)
        for combo in (self.mode, self.trace, self.reference):
            combo.activated.connect(lambda _: setattr(self, "_editor_dirty", True))
        self.mode.currentIndexChanged.connect(lambda: self.reference.setEnabled(self.mode.currentData() == "DELT"))
        self.reference.setEnabled(False)
        self.apply = QtWidgets.QPushButton("Применить режим / Trace")
        self.apply.clicked.connect(self.configure)
        layout.addWidget(self.apply)
        self.x = NumberInput()
        self.x.setDecimals(6)
        self.x.setRange(-6500, 6500)
        self.x.setSingleStep(1)
        self.x.unit = "MHz"
        self.x._dirty = False
        self.x.valueChanged.connect(lambda: setattr(self.x, "_dirty", True))
        self.x.lineEdit().textEdited.connect(lambda: setattr(self.x, "_dirty", True))
        self.x.editingFinished.connect(self.apply_x_if_edited)
        coordinate = QtWidgets.QHBoxLayout()
        self.x_title = QtWidgets.QLabel("Частота")
        coordinate.addWidget(self.x_title)
        coordinate.addWidget(self.dialog._with_unit(self.x), 1)
        self.set_x_button = QtWidgets.QPushButton("Set")
        self.set_x_button.clicked.connect(self.set_x)
        coordinate.addWidget(self.set_x_button)
        layout.addLayout(coordinate)
        self.readout = QtWidgets.QLabel("Выберите Normal и нажмите «Применить».")
        self.readout.setWordWrap(True)
        self.readout.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        layout.addWidget(self.readout)
        self.continuous = QtWidgets.QCheckBox("Непрерывный Peak Search")
        self.continuous.clicked.connect(self.set_continuous)
        layout.addWidget(self.continuous)
        actions = QtWidgets.QGridLayout()
        layout.addLayout(actions)
        self.action_buttons = {}
        for index, (label, action) in enumerate((
                ("Peak Search", "peak"), ("Next Peak", "next"),
                ("Peak ←", "left"), ("Peak →", "right"),
                ("Minimum", "minimum"), ("Marker → Center", "center"),
                ("Marker → Ref Level", "reference_level"), ("Δ → Span", "delta_span"))):
            button = QtWidgets.QPushButton(label)
            button.clicked.connect(lambda checked=False, a=action: self.run_action(a))
            actions.addWidget(button, index // 2, index % 2)
            self.action_buttons[action] = button
        self.all_off = QtWidgets.QPushButton("Выключить все маркеры")
        self.all_off.clicked.connect(lambda: self.run(self.reader.control.all_off))
        layout.addWidget(self.all_off)
        hint = QtWidgets.QLabel("Delta: сначала включите опорный маркер Normal или Fixed. X и уровень Δ показывают разность относительно него.\n\nНа графике видны маркеры выбранной Trace. Все включённые маркеры перечислены под графиком.")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        layout.addStretch()

        self.table = QtWidgets.QTableWidget(0, 4, self.dialog)
        self.table.setHorizontalHeaderLabels(["Маркер", "Trace", "Частота / время", "Уровень"])
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.table.verticalHeader().hide()
        self.table.verticalHeader().setDefaultSectionSize(23)
        self.table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        self.table.setFixedHeight(28)
        self.table.cellClicked.connect(lambda row, col: self.number.setCurrentIndex(self.table.item(row, 0).data(QtCore.Qt.UserRole) - 1))
        self.status = QtWidgets.QLabel("Ожидание спектра для чтения маркеров")
        self.status.setWordWrap(True)
        self.status.setMaximumHeight(42)
        self.overlay = pg.ScatterPlotItem(size=11, symbol="t", pen=pg.mkPen("#182128", width=1))
        self.dialog.plot.addItem(self.overlay, ignoreBounds=True)
        self.labels = []
        for n, color in enumerate(COLORS, 1):
            label = pg.TextItem(f"M{n}", color=color, anchor=(.5, -.3))
            label.setZValue(20)
            label.hide()
            self.dialog.plot.addItem(label, ignoreBounds=True)
            self.labels.append(label)
        self.update_controls(None)

    def select_marker(self):
        self._editor_dirty = False
        self.x._dirty = False
        self._editor_context = None
        self.update_controls(self.reader.snapshot)

    @staticmethod
    def values(marker, unit):
        if marker.error:
            return "—", marker.error
        factor, xunit = {"FREQ": (1e-6, "MHz"), "TIME": (1000, "ms"), "ITIM": (1, "Hz"), "PER": (1, "s")}.get(marker.readout, (1, marker.readout))
        prefix = "Δ " if marker.mode == "DELT" else ""
        yunit = ("dB" if unit.startswith("dB") else "Δ (Rigol)") if marker.mode == "DELT" else unit
        if marker.function != "OFF":
            yunit = f"[{marker.function}]"
        return f"{prefix}{marker.x * factor:.9g} {xunit}", f"{prefix}{marker.y:.3f} {yunit}"

    def update_controls(self, snapshot, force_readback=False):
        marker = snapshot.markers[self.number.currentIndex()] if snapshot else None
        active = marker is not None and not marker.error and marker.mode != "OFF"
        busy = self.reader._action_pending
        if marker is not None and not marker.error and not self._editor_dirty:
            with QtCore.QSignalBlocker(self.mode):
                self.mode.setCurrentIndex(self.mode.findData(marker.mode))
            if marker.trace:
                self.trace.setCurrentIndex(marker.trace - 1)
            if marker.reference:
                self.reference.setCurrentIndex(marker.reference - 1)
        self.reference.setEnabled(self.mode.currentData() == "DELT" and not busy)
        xenabled = active and marker.readout in ("FREQ", "TIME")
        self.x.setEnabled(xenabled and not busy)
        self.set_x_button.setEnabled(xenabled and not busy)
        self.continuous.setEnabled(active and not busy)
        self.apply.setEnabled(not busy)
        self.all_off.setEnabled(not busy)
        if active:
            text_x, text_y = self.values(marker, snapshot.y_unit)
            self.readout.setText(f"M{marker.number} · {text_x}\n{text_y}")
            with QtCore.QSignalBlocker(self.continuous):
                self.continuous.setChecked(marker.continuous)
            if xenabled:
                context = (marker.number, marker.mode, marker.readout)
                if context != self._editor_context:
                    self.x._dirty = False
                    self._editor_context = context
                if not self.x._dirty and (force_readback or not self.x.hasFocus()):
                    with QtCore.QSignalBlocker(self.x):
                        is_time = marker.readout == "TIME"
                        self.x.setRange(-4000000 if is_time else -6500, 4000000 if is_time else 6500)
                        self.x.setValue(marker.x * (1000 if is_time else 1e-6))
                    self.x.unit = "ms" if is_time else "MHz"
                    self.x.unit_label.setText(self.x.unit)
                    self.x_title.setText(("Δ " if marker.mode == "DELT" else "") + ("Время" if is_time else "Частота"))
        else:
            self.readout.setText(marker.error if marker and marker.error else "Маркер выключен" if marker else "Нет свежих данных маркера")
        for action, button in self.action_buttons.items():
            enabled = active and not busy
            if action in ("center", "delta_span"):
                enabled = enabled and snapshot.span_hz != 0
            if action == "delta_span":
                enabled = enabled and marker.mode == "DELT"
            button.setEnabled(enabled)

    def set_frame(self, frame):
        self.frame = frame
        self.reader.set_frame(frame)
        self.draw()

    def show_snapshot(self, snapshot):
        self.table.setRowCount(0)
        if snapshot is not None:
            for marker in snapshot.markers:
                if marker.mode == "OFF":
                    continue
                row = self.table.rowCount()
                self.table.insertRow(row)
                x, y = self.values(marker, snapshot.y_unit)
                name = f"M{marker.number}" + (f" ΔM{marker.reference}" if marker.mode == "DELT" else " Fixed" if marker.mode == "FIX" else "")
                for col, text in enumerate((name, str(marker.trace) if marker.trace else "—", x, y)):
                    item = QtWidgets.QTableWidgetItem(text)
                    item.setData(QtCore.Qt.UserRole, marker.number)
                    item.setToolTip(text)
                    self.table.setItem(row, col, item)
                self.table.item(row, 0).setForeground(QtGui.QColor(self.marker_color(marker.number)))
        self.table.setFixedHeight(min(126, 28 + self.table.rowCount() * 23))
        self.update_controls(snapshot)
        self.draw()

    def marker_color(self, number):
        colors = LIGHT_COLORS if self.dialog.plot.backgroundBrush().color().lightness() > 160 else COLORS
        return colors[number - 1]

    def draw(self):
        for label in self.labels:
            label.hide()
        spots = []
        snapshot = self.reader.snapshot
        if snapshot and snapshot.matches(self.frame) and self.reader.enabled:
            for marker in snapshot.markers:
                position = snapshot.position(marker.number, self.frame)
                if position is None:
                    continue
                color = self.marker_color(marker.number)
                spots.append({"pos": position, "brush": pg.mkBrush(color)})
                label = self.labels[marker.number - 1]
                label.setColor(color)
                lo, hi = self.frame.x[0], self.frame.x[-1]
                fraction = (position[0] - lo) / (hi - lo) if hi != lo else .5
                label.setAnchor((0 if fraction < .1 else 1 if fraction > .9 else .5, -.3))
                label.setText(f"M{marker.number}" + (" Δ" if marker.mode == "DELT" else ""))
                label.setPos(*position)
                label.show()
        self.overlay.setData(spots)

    def show_status(self, text, error):
        self.status.setText(text)
        self.status.setToolTip(text)
        if not self.reader.enabled:
            with QtCore.QSignalBlocker(self.dialog.show_markers):
                self.dialog.show_markers.setChecked(False)
        if error and not self.dialog.rigol.connected:
            self.dialog.live_reader.set_enabled(False)
            self.dialog.live_reader.invalidate()
            self.dialog.controller.rigol_connected = False
            self.dialog.controller.rigol_error = self.dialog.rigol.last_error
            self.dialog.controller.updated.emit()

    def run(self, function):
        if self.reader.command(function):
            self.update_controls(None)

    def configure(self):
        n, mode = self.number.currentIndex() + 1, self.mode.currentData()
        trace, reference = self.trace.currentIndex() + 1, self.reference.currentIndex() + 1
        self._editor_dirty = False
        self.run(lambda: self.reader.control.configure(n, mode, trace, reference))

    def set_x(self):
        snapshot = self.reader.snapshot
        if snapshot is None:
            return
        n = self.number.currentIndex() + 1
        readout = snapshot.markers[n - 1].readout
        self.x.interpretText()
        value = self.x.value() * (1e-3 if readout == "TIME" else 1e6)
        self.x._dirty = False
        self.run(lambda: self.reader.control.set_x(n, value, readout))

    def apply_x_if_edited(self):
        if self.x._dirty and self.x.hasAcceptableInput():
            self.set_x()

    def set_continuous(self, enabled):
        n = self.number.currentIndex() + 1
        self.run(lambda: self.reader.control.set_continuous(n, enabled))

    def run_action(self, action):
        n = self.number.currentIndex() + 1
        self.run(lambda: self.reader.control.action(n, action))

    def action_done(self, result):
        self.update_controls(self.reader.snapshot, force_readback=True)
        if result:
            d = self.dialog
            d._load_numeric(d.center, result["center"] / 1e6)
            d._load_numeric(d.span, result["span"] / 1e6)
            d._load_numeric(d.ref, result["ref"])
            self.dialog.live_reader.invalidate()
        self._refresh_device = self.dialog.rigol.dev
        self._refresh_timer.start()

    def _refresh_after_action(self):
        live = self.dialog.live_reader
        if (live._closed or not self.dialog.isVisible() or not self.dialog.rigol.connected
                or self.dialog.rigol.dev is not self._refresh_device):
            self._refresh_timer.stop()
            return
        if not live._pending:
            self._refresh_timer.stop()
            live.refresh(force=True)

    def diagnostic(self):
        snapshot = self.reader.snapshot
        return {"status": self.status.text(), "selected": self.number.currentIndex() + 1,
                "age_seconds": time.monotonic() - snapshot.captured_at if snapshot else None,
                "snapshot": asdict(snapshot) if snapshot else None}
