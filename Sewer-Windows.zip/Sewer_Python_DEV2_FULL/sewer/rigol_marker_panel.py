from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
import time

from PySide6 import QtCore, QtGui, QtWidgets
import pyqtgraph as pg

from .number_input import NumberInput
from .rigol import RigolConnectionError
from .rigol_markers import RigolMarkerControl


COLORS = ("#ffcf5a", "#f58cae", "#6edacb", "#b69cff", "#ffad68", "#91ceff", "#b4dc69", "#ec9de5")
LIGHT_COLORS = ("#835300", "#a32057", "#08736d", "#6438b4", "#9a4100", "#075c9c", "#4c7212", "#942780")


class MarkerReader(QtCore.QObject):
    updated = QtCore.Signal(object)
    status = QtCore.Signal(str, bool)
    action_done = QtCore.Signal(object)
    _finished = QtCore.Signal(object, object, str, object, object, object)

    def __init__(self, rigol, parent=None):
        super().__init__(parent)
        self.rigol = rigol
        self.control = RigolMarkerControl(rigol)
        self.frame = None
        self.snapshot = None
        self.enabled = True
        self.live = True
        self.active = False
        self.closed = False
        self._poll_pending = False
        self._action_pending = False
        self._generation = 0
        self._key = None
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="RigolMarkers")
        self._finished.connect(self._complete)
        self.timer = QtCore.QTimer(self)
        self.timer.setInterval(1500)
        self.timer.timeout.connect(self.refresh)

    def set_active(self, active):
        active = bool(active) and not self.rigol.suspended
        self.active = bool(active)
        if self.closed:
            return
        if active:
            self.timer.start()
        else:
            self.timer.stop()
            self._generation += 1

    def set_frame(self, frame):
        self.frame = frame
        key = None if frame is None else (frame.mode, frame.view, frame.center_hz, frame.span_hz,
                                         frame.y_unit, float(frame.x[-1]))
        if key != self._key:
            self._key = key
            # The command worker can return a snapshot for the new axes before
            # the corresponding trace frame arrives. Keep it for that frame.
            self._generation += 1

    def invalidate(self):
        self._generation += 1
        self.snapshot = None
        self.updated.emit(None)

    def set_enabled(self, enabled):
        self.enabled = bool(enabled)
        self.invalidate()
        if enabled:
            self.refresh(force=True)

    def refresh(self, force=False):
        if (self.closed or not self.active or not self.enabled or not self.rigol.connected
                or self._poll_pending or self._action_pending
                or (not force and (not self.live or self.frame is None))):
            return
        self._poll_pending = True
        self._submit("poll", None)

    def command(self, function):
        if self.closed or not self.active or self._action_pending:
            return False
        if not self.rigol.connected:
            self.status.emit("Нет связи с Rigol", True)
            return False
        self.invalidate()
        self._action_pending = True
        self.status.emit("Выполняется команда маркера…", False)
        self._submit("action", function)
        return True

    def _submit(self, kind, function):
        generation, device = self._generation, self.rigol.dev
        def run():
            with self.rigol.lock:
                if self.closed or self.rigol.suspended or not self.active or self.rigol.dev is not device:
                    return None, None
                result = function() if function is not None else None
                # State and actual X/Y values are read back after every command.
                return self.control.read(), result
        future = self._executor.submit(run)
        def finished(f):
            try:
                snapshot, result = f.result()
                error = None
            except Exception as exc:
                snapshot, result, error = None, None, exc
            if not self.closed:
                self._finished.emit(generation, device, kind, snapshot, result, error)
        future.add_done_callback(finished)

    @QtCore.Slot(object, object, str, object, object, object)
    def _complete(self, generation, device, kind, snapshot, result, error):
        if kind == "action":
            self._action_pending = False
        else:
            self._poll_pending = False
        if self.closed or self.rigol.suspended:
            return
        if isinstance(error, RigolConnectionError):
            self.enabled = False
            self.invalidate()
            self.status.emit("Опрос маркеров остановлен: " + str(error), True)
            if kind == "action":
                self.action_done.emit(None)
            return
        if device is not self.rigol.dev or not self.active:
            if kind == "action":
                self.action_done.emit(None)
            return
        if kind == "poll" and generation != self._generation:
            return
        if error is not None:
            self.invalidate()
            self.status.emit("Маркеры: " + str(error), True)
        elif snapshot is not None:
            self.snapshot = snapshot
            self.updated.emit(snapshot)
            errors = [f"M{m.number}: {m.error}" for m in snapshot.markers if m.error]
            self.status.emit("; ".join(errors) if errors else "Маркеры прочитаны с Rigol · опрос 1,5 с", bool(errors))
        if kind == "action":
            self.action_done.emit(result)

    def close(self):
        self.closed = True
        self.active = False
        self.timer.stop()
        self._executor.shutdown(wait=False, cancel_futures=True)


class MarkerPanel(QtWidgets.QWidget):
    def __init__(self, dialog):
        super().__init__(dialog)
        self.dialog = dialog
        self.reader = MarkerReader(dialog.rigol, self)
        self.frame = None
        self._editor_dirty = False
        self._editor_context = None
        self._reference_items = None
        self._build()
        self.reader.updated.connect(self.show_snapshot)
        self.reader.status.connect(self.show_status)
        self.reader.action_done.connect(self.action_done)
        self._refresh_timer = QtCore.QTimer(self)
        self._refresh_timer.setInterval(30)
        self._refresh_timer.timeout.connect(self._refresh_after_action)

    def _build(self):
        layout = QtWidgets.QVBoxLayout(self)
        form = QtWidgets.QFormLayout()
        layout.addLayout(form)
        self.number = QtWidgets.QComboBox()
        self.number.addItems([f"M{i}" for i in range(1, 9)])
        self.number.currentIndexChanged.connect(self.select_marker)
        form.addRow("Маркер", self.number)
        self.mode = QtWidgets.QComboBox()
        for label, value in (("Выключен", "OFF"), ("Normal", "POS"), ("Delta", "DELT"), ("Fixed", "FIX")):
            self.mode.addItem(label, value)
        form.addRow("Режим", self.mode)
        self.trace = QtWidgets.QComboBox()
        self.trace.addItems([str(i) for i in range(1, 7)])
        form.addRow("Trace", self.trace)
        self.reference = QtWidgets.QComboBox()
        form.addRow("Опорный для Δ", self.reference)
        for combo in (self.trace, self.reference):
            combo.currentIndexChanged.connect(lambda _: setattr(self, "_editor_dirty", True))
        self.mode.currentIndexChanged.connect(self.edit_mode)
        self.reference.setEnabled(False)
        self.apply = QtWidgets.QPushButton("Применить")
        self.apply.clicked.connect(self.configure)
        layout.addWidget(self.apply)
        self.select_reference = QtWidgets.QPushButton("Перейти к опорному маркеру")
        self.select_reference.setToolTip("Чтобы выключить опору, перейдите к ней и выберите режим «Выключен».")
        self.select_reference.clicked.connect(self.go_to_reference)
        layout.addWidget(self.select_reference)
        self.x = NumberInput()
        self.x.setDecimals(6)
        self.x.setRange(-6500, 6500)
        self.x.setSingleStep(1)
        self.x.unit = "MHz"
        self.x._dirty = False
        self.x.valueChanged.connect(lambda: setattr(self.x, "_dirty", True))
        self.x.lineEdit().textEdited.connect(lambda: setattr(self.x, "_dirty", True))
        self.x.editingFinished.connect(self.apply_x_if_edited)
        coordinate = QtWidgets.QHBoxLayout()
        self.x_title = QtWidgets.QLabel("Частота")
        coordinate.addWidget(self.x_title)
        coordinate.addWidget(self.dialog._with_unit(self.x), 1)
        self.set_x_button = QtWidgets.QPushButton("Set")
        self.set_x_button.clicked.connect(self.set_x)
        coordinate.addWidget(self.set_x_button)
        layout.addLayout(coordinate)
        self.readout = QtWidgets.QLabel("Выберите Normal и нажмите «Применить».")
        self.readout.setWordWrap(True)
        self.readout.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        layout.addWidget(self.readout)
        self.continuous = QtWidgets.QCheckBox("Непрерывный Peak Search")
        self.continuous.clicked.connect(self.set_continuous)
        layout.addWidget(self.continuous)
        actions = QtWidgets.QGridLayout()
        layout.addLayout(actions)
        self.action_buttons = {}
        for index, (label, action) in enumerate((
                ("Peak Search", "peak"), ("Next Peak", "next"),
                ("Peak ←", "left"), ("Peak →", "right"),
                ("Minimum", "minimum"), ("Marker → Center", "center"),
                ("Marker → Ref Level", "reference_level"), ("Δ → Span", "delta_span"))):
            button = QtWidgets.QPushButton(label)
            button.clicked.connect(lambda checked=False, a=action: self.run_action(a))
            actions.addWidget(button, index // 2, index % 2)
            self.action_buttons[action] = button
        self.all_off = QtWidgets.QPushButton("Выключить все маркеры")
        self.all_off.clicked.connect(lambda: self.run(self.reader.control.all_off))
        layout.addWidget(self.all_off)
        hint = QtWidgets.QLabel("Delta показывает разность относительно опорного маркера. "
                               "Если опора выключена, Sewer включит её в режиме Normal. "
                               "Чтобы убрать привязку, выберите «Без опоры» и нажмите «Применить».")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        layout.addStretch()

        self.table = QtWidgets.QTableWidget(0, 4, self.dialog)
        self.table.setHorizontalHeaderLabels(["Маркер", "Trace", "Частота / время", "Уровень"])
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.table.verticalHeader().hide()
        self.table.verticalHeader().setDefaultSectionSize(23)
        self.table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        self.table.setFixedHeight(28)
        self.table.cellClicked.connect(lambda row, col: self.number.setCurrentIndex(self.table.item(row, 0).data(QtCore.Qt.UserRole) - 1))
        self.status = QtWidgets.QLabel("Ожидание данных маркеров")
        self.status.setWordWrap(True)
        self.status.setMaximumHeight(42)
        self.overlay = pg.ScatterPlotItem(size=11, symbol="t", pen=pg.mkPen("#182128", width=1))
        self.dialog.plot.addItem(self.overlay, ignoreBounds=True)
        self.labels = []
        for n, color in enumerate(COLORS, 1):
            label = pg.TextItem(f"M{n}", color=color, anchor=(.5, -.3))
            label.setZValue(20)
            label.hide()
            self.dialog.plot.addItem(label, ignoreBounds=True)
            self.labels.append(label)
        self.dialog.plot.getViewBox().sigRangeChanged.connect(self.draw)
        self.update_controls(None)

    def select_marker(self):
        self._editor_dirty = False
        self.x._dirty = False
        self._editor_context = None
        if self.reader.snapshot is None:
            with QtCore.QSignalBlocker(self.mode):
                self.mode.setCurrentIndex(self.mode.findData("OFF"))
            with QtCore.QSignalBlocker(self.trace):
                self.trace.setCurrentIndex(self.dialog.tr.currentIndex())
            self.populate_references(None, None)
        self.update_controls(self.reader.snapshot)

    def populate_references(self, snapshot, selected):
        n = self.number.currentIndex() + 1
        items = []
        for number in range(1, 9):
            if number == n:
                continue
            mode = snapshot.markers[number - 1].mode if snapshot else ""
            if mode == "DELT" and number != selected:
                continue
            label = f"M{number}" + {"OFF": " · выключен", "FIX": " · Fixed",
                                    "DELT": " · Delta", "POS": " · Normal"}.get(mode, "")
            items.append((label, number))
        with QtCore.QSignalBlocker(self.reference):
            if items != self._reference_items:
                if self.reference.view().isVisible():
                    return
                self.reference.clear()
                self.reference.addItem("Без опоры → Normal", None)
                for label, number in items:
                    self.reference.addItem(label, number)
                self._reference_items = items
            self.reference.setCurrentIndex(max(0, self.reference.findData(selected)))

    def edit_mode(self):
        self._editor_dirty = True
        if self.mode.currentData() == "DELT" and self.reference.currentData() is None:
            snapshot = self.reader.snapshot
            n = self.number.currentIndex() + 1
            default = next((m.number for m in snapshot.markers
                            if m.number != n and m.mode in ("POS", "FIX")), None) if snapshot else None
            self.reference.setCurrentIndex(max(1, self.reference.findData(default or n % 8 + 1)))
        self.update_reference_actions()

    def update_reference_actions(self):
        snapshot = self.reader.snapshot
        marker = snapshot.markers[self.number.currentIndex()] if snapshot else None
        busy = self.reader._action_pending
        self.reference.setEnabled(self.mode.currentData() == "DELT" and not busy)
        self.select_reference.setEnabled(bool(marker and marker.mode == "DELT"
                                        and marker.reference in range(1, 9)
                                        and marker.reference != marker.number and not busy))

    def go_to_reference(self):
        snapshot = self.reader.snapshot
        if snapshot:
            marker = snapshot.markers[self.number.currentIndex()]
            if marker.mode == "DELT" and marker.reference in range(1, 9):
                self.number.setCurrentIndex(marker.reference - 1)

    @staticmethod
    def values(marker, unit):
        factor, xunit = {"FREQ": (1e-6, "MHz"), "TIME": (1000, "ms"), "ITIM": (1, "Hz"), "PER": (1, "s")}.get(marker.readout, (1, marker.readout))
        prefix = "Δ " if marker.mode == "DELT" else ""
        yunit = ("dB" if unit.startswith("dB") else "Δ (Rigol)") if marker.mode == "DELT" else unit
        if marker.function != "OFF":
            yunit = f"[{marker.function}]"
        return (f"{prefix}{marker.x * factor:.9g} {xunit}" if marker.x is not None else "—",
                f"{prefix}{marker.y:.3f} {yunit}" if marker.y is not None else (marker.error or "—"))

    def update_controls(self, snapshot, force_readback=False):
        marker = snapshot.markers[self.number.currentIndex()] if snapshot else None
        active = marker is not None and marker.mode in ("POS", "DELT", "FIX")
        busy = self.reader._action_pending
        if marker is not None and not self._editor_dirty:
            with QtCore.QSignalBlocker(self.mode):
                self.mode.setCurrentIndex(max(0, self.mode.findData(marker.mode)))
            with QtCore.QSignalBlocker(self.trace):
                self.trace.setCurrentIndex(marker.trace - 1 if marker.trace in range(1, 7) else self.dialog.tr.currentIndex())
        if not self._editor_dirty and (snapshot or not self.reference.count()):
            reference = marker.reference if marker and marker.mode == "DELT" else None
            self.populate_references(snapshot, reference)
        self.update_reference_actions()
        xenabled = active and marker.x is not None and marker.readout in ("FREQ", "TIME")
        self.x.setEnabled(xenabled and not busy)
        self.set_x_button.setEnabled(xenabled and not busy)
        self.continuous.setEnabled(active and not busy)
        self.apply.setEnabled(not busy)
        self.all_off.setEnabled(not busy)
        self.number.setEnabled(not busy)
        self.mode.setEnabled(not busy)
        self.trace.setEnabled(not busy)
        if active:
            text_x, text_y = self.values(marker, snapshot.y_unit)
            self.readout.setText(f"M{marker.number} · {text_x}\n{text_y}")
            with QtCore.QSignalBlocker(self.continuous):
                self.continuous.setChecked(marker.continuous)
            if xenabled:
                context = (marker.number, marker.mode, marker.readout)
                if context != self._editor_context:
                    self.x._dirty = False
                    self._editor_context = context
                if not self.x._dirty and (force_readback or not self.x.hasFocus()):
                    with QtCore.QSignalBlocker(self.x):
                        is_time = marker.readout == "TIME"
                        self.x.setRange(-4000000 if is_time else -6500, 4000000 if is_time else 6500)
                        self.x.setValue(marker.x * (1000 if is_time else 1e-6))
                    self.x.unit = "ms" if is_time else "MHz"
                    self.x.unit_label.setText(self.x.unit)
                    self.x_title.setText(("Δ " if marker.mode == "DELT" else "") + ("Время" if is_time else "Частота"))
        else:
            self.readout.setText(marker.error if marker and marker.error else "Маркер выключен" if marker else "Нет свежих данных маркера")
        for action, button in self.action_buttons.items():
            enabled = active and not busy
            if action in ("center", "delta_span"):
                enabled = enabled and snapshot.span_hz != 0
            if action == "delta_span":
                enabled = enabled and marker.mode == "DELT"
            button.setEnabled(enabled)

    def set_frame(self, frame):
        self.frame = frame
        self.reader.set_frame(frame)
        self.draw()

    def show_snapshot(self, snapshot):
        self.table.setRowCount(0)
        if snapshot is not None:
            references = self.reference_numbers(snapshot)
            for marker in snapshot.markers:
                if marker.mode == "OFF":
                    continue
                row = self.table.rowCount()
                self.table.insertRow(row)
                x, y = self.values(marker, snapshot.y_unit)
                name = self.marker_name(marker, references)
                if marker.mode == "FIX":
                    name += " · Fixed"
                for col, text in enumerate((name, str(marker.trace) if marker.trace else "—", x, y)):
                    item = QtWidgets.QTableWidgetItem(text)
                    item.setData(QtCore.Qt.UserRole, marker.number)
                    item.setToolTip(text)
                    self.table.setItem(row, col, item)
                self.table.item(row, 0).setForeground(QtGui.QColor(self.marker_color(marker.number)))
        self.table.setFixedHeight(min(126, 28 + self.table.rowCount() * 23))
        self.update_controls(snapshot)
        self.draw()

    def marker_color(self, number):
        colors = LIGHT_COLORS if self.dialog.plot.backgroundBrush().color().lightness() > 160 else COLORS
        return colors[number - 1]

    @staticmethod
    def reference_numbers(snapshot):
        return {m.reference for m in snapshot.markers if m.mode == "DELT"
                and m.reference in range(1, 9) and m.reference != m.number
                and snapshot.markers[m.reference - 1].mode in ("POS", "FIX")}

    @staticmethod
    def marker_name(marker, references):
        if marker.mode == "DELT":
            ref = marker.reference
            return f"M{marker.number} Δ" + (f"M{ref}" if ref in range(1, 9) and ref != marker.number else "")
        return f"M{marker.number}" + (" · опора" if marker.number in references else "")

    def draw(self):
        spots = []
        visible = set()
        placed = []
        snapshot = self.reader.snapshot
        if snapshot and snapshot.matches(self.frame) and self.reader.enabled:
            references = self.reference_numbers(snapshot)
            view = self.dialog.plot.getViewBox()
            (x0, x1), (y0, y1) = view.viewRange()
            dx, dy = view.viewPixelSize()
            for marker in snapshot.markers:
                position = snapshot.position(marker.number, self.frame, on_trace=True)
                if position is None:
                    continue
                x, y = position
                color = self.marker_color(marker.number)
                is_ref = marker.number in references
                spots.append({"pos": position, "brush": pg.mkBrush(color), "symbol": "o" if is_ref else "t"})
                visible.add(marker.number)
                label = self.labels[marker.number - 1]
                label.setColor(color)
                label.setText(self.marker_name(marker, references))
                w, h = label.boundingRect().width(), label.boundingRect().height()
                if dx > 0 and dy > 0 and h > 0:
                    ax = min(1, max(0, .5 + max(0, x + w * dx / 2 - x1) / max(w * dx, dx)
                                       - max(0, x0 - x + w * dx / 2) / max(w * dx, dx)))
                    below = -.25
                    above = 1.25
                    for ay in (below, above, below - 1, above + 1, below - 2, above + 2, below - 3, above + 3):
                        box = QtCore.QRectF(x - ax * w * dx, y + (ay - 1) * h * dy, w * dx, h * dy)
                        if box.top() >= y0 and box.bottom() <= y1 and not any(box.intersects(item) for item in placed):
                            break
                    else:
                        ay = above if y < (y1 + y0) / 2 else below
                        box = QtCore.QRectF(x - ax * w * dx, y + (ay - 1) * h * dy, w * dx, h * dy)
                    placed.append(box)
                    label.setAnchor((ax, ay))
                label.setPos(*position)
                label.show()
        for number, label in enumerate(self.labels, 1):
            if number not in visible:
                label.hide()
        self.overlay.setData(spots)

    def show_status(self, text, error):
        self.status.setText(text)
        self.status.setToolTip(text)
        if not self.reader.enabled:
            with QtCore.QSignalBlocker(self.dialog.show_markers):
                self.dialog.show_markers.setChecked(False)
        if error and not self.dialog.rigol.connected:
            self.dialog.live_reader.set_enabled(False)
            self.dialog.live_reader.invalidate()
            self.dialog.controller.rigol_connected = False
            self.dialog.controller.rigol_error = self.dialog.rigol.last_error
            self.dialog.controller.updated.emit()

    def run(self, function):
        if self.reader.command(function):
            self.update_controls(None)

    def configure(self):
        n, mode = self.number.currentIndex() + 1, self.mode.currentData()
        trace, reference = self.trace.currentIndex() + 1, self.reference.currentData()
        self._editor_dirty = False
        self.run(lambda: self.reader.control.configure(n, mode, trace, reference))

    def set_x(self):
        snapshot = self.reader.snapshot
        if snapshot is None:
            return
        n = self.number.currentIndex() + 1
        readout = snapshot.markers[n - 1].readout
        self.x.interpretText()
        value = self.x.value() * (1e-3 if readout == "TIME" else 1e6)
        self.x._dirty = False
        self.run(lambda: self.reader.control.set_x(n, value, readout))

    def apply_x_if_edited(self):
        if self.x._dirty and self.x.hasAcceptableInput():
            self.set_x()

    def set_continuous(self, enabled):
        n = self.number.currentIndex() + 1
        self.run(lambda: self.reader.control.set_continuous(n, enabled))

    def run_action(self, action):
        n = self.number.currentIndex() + 1
        self.run(lambda: self.reader.control.action(n, action))

    def action_done(self, result):
        self.update_controls(self.reader.snapshot, force_readback=True)
        if result:
            d = self.dialog
            d._load_numeric(d.center, result["center"] / 1e6)
            d._load_numeric(d.span, result["span"] / 1e6)
            d._load_numeric(d.ref, result["ref"])
            self.dialog.live_reader.invalidate()
        self._refresh_device = self.dialog.rigol.dev
        self._refresh_timer.start()

    def _refresh_after_action(self):
        live = self.dialog.live_reader
        if (live._closed or not self.dialog.isVisible() or not self.dialog.rigol.connected
                or self.dialog.rigol.dev is not self._refresh_device):
            self._refresh_timer.stop()
            return
        if not live._pending:
            self._refresh_timer.stop()
            live.refresh(force=True)

    def diagnostic(self):
        snapshot = self.reader.snapshot
        return {"status": self.status.text(), "selected": self.number.currentIndex() + 1,
                "age_seconds": time.monotonic() - snapshot.captured_at if snapshot else None,
                "snapshot": asdict(snapshot) if snapshot else None}
