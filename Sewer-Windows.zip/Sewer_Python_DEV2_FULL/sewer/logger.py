from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Callable

from .config import resolve_path


class SewerLogger:
    def __init__(self, root: Path, config: dict, ui_sink: Callable[[str], None] | None = None):
        self.root = root
        self.config = config
        self.ui_sink = ui_sink
        self.directory: Path | None = None
        self.application_log_path: Path | None = None
        self.reconfigure(config)

    def reconfigure(self, config: dict) -> None:
        self.config = config
        log_cfg = config.get("Logging", {})
        self.directory = resolve_path(str(log_cfg.get("Directory", "Logs")), self.root)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.application_log_path = self.directory / f"Sewer_{datetime.now():%Y%m%d}.log"

    def write(self, message: str) -> None:
        line = f"[{datetime.now():%H:%M:%S}] {message}"
        if self.ui_sink:
            self.ui_sink(line)
        cfg = self.config.get("Logging", {})
        if cfg.get("Enabled", True) and cfg.get("ApplicationLog", True):
            try:
                assert self.application_log_path is not None
                with self.application_log_path.open("a", encoding="utf-8-sig") as f:
                    f.write(line + "\n")
            except OSError:
                pass

    def programmer_paths(self, temp_dir: Path) -> tuple[Path, Path, Path]:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
        assert self.directory is not None
        temp_dir.mkdir(parents=True, exist_ok=True)
        return (
            self.directory / f"Programmer_{stamp}.log",
            temp_dir / f"Programmer_{stamp}.stdout.tmp",
            temp_dir / f"Programmer_{stamp}.stderr.tmp",
        )
