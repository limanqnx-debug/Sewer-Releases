"""Capture the analyzer display using the Sewer Widget Web Control flow."""
from __future__ import annotations

from pathlib import Path
import re
from threading import Event
import time

from .rigol_local import find_screen, open_web_control, release_browser, web_host


DEFAULT_FOLDER = Path.home() / "Pictures" / "Sewer Screenshots"
PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"


def filename_base(value: str) -> str:
    name = str(value or "").strip()
    if name.lower().endswith(".png"):
        name = name[:-4]
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name)[:100].rstrip(" .")
    if re.fullmatch(r"CON|PRN|AUX|NUL|COM[1-9¹²³]|LPT[1-9¹²³]",
                    name.split(".", 1)[0], re.IGNORECASE):
        name = "_" + name
    return name or "Rigol"


def save_numbered_png(folder: Path, base: str, fill_gaps: bool, png: bytes) -> Path:
    if not png.startswith(PNG_SIGNATURE):
        raise ValueError("Web Control не вернул изображение PNG.")
    folder.mkdir(parents=True, exist_ok=True)
    base = filename_base(base)
    pattern = re.compile(rf"{re.escape(base)}_([0-9]+)\.png", re.IGNORECASE)
    used = {int(m[1]) for file in folder.iterdir() if (m := pattern.fullmatch(file.name))}
    number = 1 if fill_gaps else max(used, default=0) + 1
    while True:
        if number in used:
            number += 1
            continue
        path = folder / f"{base}_{number:03d}.png"
        try:
            stream = path.open("xb")
        except FileExistsError:
            number += 1
            continue
        try:
            with stream:
                stream.write(png)
        except OSError:
            path.unlink(missing_ok=True)
            raise
        return path


def check_cancel(cancel: Event) -> None:
    if cancel.is_set():
        raise RuntimeError("Скриншот Rigol отменён.")


def capture_page(page, url: str, cancel: Event, *, wait_screen: float, wait_live: float) -> bytes:
    from playwright.sync_api import Error, TimeoutError

    check_cancel(cancel)
    page.set_default_timeout(1500)
    try:
        page.goto(url, wait_until="domcontentloaded", timeout=1800)
    except TimeoutError:
        # Some firmware keeps loading resources after the display is ready.
        pass
    deadline = time.monotonic() + wait_screen
    retry_at = 0.0
    screen = None
    while time.monotonic() < deadline:
        check_cancel(cancel)
        try:
            screen = find_screen(page)
            if screen is not None:
                break
            if time.monotonic() >= retry_at:
                retry_at = time.monotonic() + .7
                open_web_control(page)
        except Error:
            # Web Control may replace its frame during navigation.
            pass
        page.wait_for_timeout(150)
    if screen is None:
        raise RuntimeError("Экран Web Control не найден. Включите Display → Web Control на Rigol.")

    # Let the live screen replace its first frame. A stationary screen is valid.
    first = screen.screenshot(type="png", timeout=2500)
    deadline = time.monotonic() + wait_live
    png = first
    while time.monotonic() < deadline:
        check_cancel(cancel)
        page.wait_for_timeout(350)
        png = screen.screenshot(type="png", timeout=2500)
        if png != first:
            page.wait_for_timeout(350)
            check_cancel(cancel)
            png = screen.screenshot(type="png", timeout=2500)
            break
    check_cancel(cancel)
    return png


def capture_rigol_screenshot(resource: str, folder: Path, base: str, fill_gaps: bool,
                             cancel: Event) -> Path:
    url = f"http://{web_host(resource)}/"
    # As in the widget, keep the full width and retry once on a slow Web Control.
    # Don't click Rmt: the Sewer analyzer session can still be in use.
    with release_browser(viewport_width=1250, timeout_ms=5000) as context:
        last_error = None
        for wait_screen, wait_live in ((.8, .7), (3.0, 2.0)):
            check_cancel(cancel)
            page = context.new_page()
            try:
                png = capture_page(page, url, cancel, wait_screen=wait_screen, wait_live=wait_live)
            except Exception as exc:
                last_error = exc
                continue
            finally:
                page.close()
            check_cancel(cancel)
            return save_numbered_png(folder, base, fill_gaps, png)
    raise RuntimeError(f"Скриншот Rigol не получен: {last_error}") from last_error
