from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor

from PySide6 import QtCore


class RigolLive(QtCore.QObject):
    """One background reader shared by the main window and the control dialog."""

    frame_ready = QtCore.Signal(object)
    changed = QtCore.Signal()
    _finished = QtCore.Signal(object, object, object, object)

    def __init__(self, rigol, interval_ms=300, parent=None):
        super().__init__(parent)
        self.rigol = rigol
        self.enabled = True
        self.trace = 1
        self.frame = None
        self.status = "Нет связи с Rigol"
        self.error = False
        self._pending = False
        self._closed = False
        self._generation = 0
        self._retry_at = 0.0
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="RigolLive")
        self._finished.connect(self._complete)
        self.timer = QtCore.QTimer(self)
        self.set_interval(interval_ms)
        self.timer.timeout.connect(self.refresh)
        self.timer.start()

    def set_interval(self, value):
        self.timer.setInterval(max(100, int(value)))

    def _state(self, message, error=False, clear=False):
        changed = self.status != message or self.error != error or (clear and self.frame is not None)
        self.status, self.error = message, error
        if clear:
            self.frame = None
        if changed:
            self.changed.emit()

    def invalidate(self):
        self._generation += 1
        self._retry_at = 0.0
        message = "Ожидание данных Rigol" if self.enabled else "Пауза Live"
        self._state(message if self.rigol.connected else "Нет связи с Rigol", clear=True)

    @QtCore.Slot(bool)
    def set_enabled(self, enabled):
        self.enabled = bool(enabled)
        if self.enabled:
            self.timer.start()
            self._retry_at = 0.0
            self._state("Ожидание данных Rigol")
            self.refresh()
        else:
            self.timer.stop()
            self._generation += 1
            self._state("Пауза Live")
        self.changed.emit()

    @QtCore.Slot(int)
    def set_trace(self, trace):
        trace = int(trace)
        if trace not in range(1, 7) or trace == self.trace:
            return
        self.trace = trace
        self.invalidate()
        self.changed.emit()
        self.refresh()

    def _read(self, device, trace):
        with self.rigol.lock:
            if self._closed or self.rigol.dev is not device:
                return None
            return self.rigol.spectrum(trace)

    @QtCore.Slot()
    def refresh(self, force=False):
        if self._closed:
            return
        if not self.rigol.connected:
            self._retry_at = 0.0
            self._state("Нет связи с Rigol", clear=True)
            return
        if self._pending or (not force and (not self.enabled or time.monotonic() < self._retry_at)):
            return
        self._pending = True
        generation, device = self._generation, self.rigol.dev
        future = self._executor.submit(self._read, device, self.trace)

        def finished(f):
            try:
                result, error = f.result(), None
            except Exception as exc:
                result, error = None, exc
            if not self._closed:
                self._finished.emit(generation, device, result, error)

        future.add_done_callback(finished)

    @QtCore.Slot(object, object, object, object)
    def _complete(self, generation, device, frame, error):
        self._pending = False
        if self._closed or generation != self._generation or device is not self.rigol.dev:
            return
        if error is not None:
            self._retry_at = time.monotonic() + 2.0
            self._state("Нет данных: " + str(error), error=True, clear=True)
        elif frame is not None:
            self._retry_at = 0.0
            self.frame = frame
            self._state(f"{frame.mode} · {frame.y.size} точек")
            self.frame_ready.emit(frame)

    def close(self):
        self._closed = True
        self.timer.stop()
        self._executor.shutdown(wait=False, cancel_futures=True)
