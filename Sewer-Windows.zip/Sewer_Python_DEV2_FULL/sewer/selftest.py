"""Packaging check used by the Windows build, without opening instrument sessions."""
from __future__ import annotations

import json
import os
from pathlib import Path
import struct
import sys
import threading

from PySide6 import QtCore, QtGui, QtWidgets

from .config import clone_config, load_config, save_config
from .controller import SewerController
from .gui import MainWindow
from .process_launch import launch_external
from .runtime import asset_path, application_dir
from .settings import SettingsDialog
from .themes import THEMES, theme_from_config


def check_release_browser():
    """Exercise the bundled driver and installed browser on an intercepted fixture."""
    from .rigol_local import release_browser, run_release_page
    home = '''<!doctype html><button onclick="document.querySelector('iframe').style.display='block'">Web Control</button>
              <iframe src="/panel" style="display:none;width:900px;height:600px"></iframe>'''
    panel = '''<!doctype html><div id="screen" style="width:800px;height:480px;background:#ddd"></div>
               <script>document.querySelector('#screen').onclick = function(e) {
                 const r = this.getBoundingClientRect(); window.hit = [e.clientX-r.left, e.clientY-r.top];
               };</script>'''
    with release_browser() as context:
        # All requests are fulfilled locally: this check never contacts a Rigol.
        context.route("**/*", lambda route: route.fulfill(
            status=200, content_type="text/html",
            body=panel if route.request.url.endswith("/panel") else home))
        page = context.new_page()
        run_release_page(page, "http://127.0.0.1/", threading.Event())
        frame = next(f for f in page.frames if f.url.endswith("/panel"))
        assert frame.evaluate("window.hit") == [181, 18], "Web Control Rmt click missed"


def run_self_test(app, root: Path, config_path: Path, report_path: Path) -> int:
    import pyvisa.ctwrapper.highlevel
    import serial.tools.list_ports
    config = load_config(config_path)
    loaded_theme = theme_from_config(config)
    original_tick = SewerController.tick
    SewerController.tick = lambda self: None
    window = settings = None
    try:
        controller = SewerController(root, config_path, config)
        controller.timer.stop()
        window = MainWindow(controller)
        window.show()
        window.apply_theme("hellokitty")
        # Let queued layout changes settle after showing a previously hidden theme heading.
        loop = QtCore.QEventLoop()
        QtCore.QTimer.singleShot(100, loop.quit)
        loop.exec()
        assert QtGui.QFontDatabase.families(), "No fonts available in the packaged application"
        assert QtGui.QRawFont.fromFont(window.font()).isValid(), "Invalid UI font"
        assert not window.windowIcon().isNull(), "Missing window icon"
        assert not window.settings_btn.icon().isNull(), "Missing hedgehog"
        assert window.theme_header.label.text() == "Hello Tanya", "Wrong theme heading"
        assert window.theme_header.label.width() >= window.theme_header.label.fontMetrics().horizontalAdvance("Hello Tanya")
        assert THEMES["hellokitty"]["name"] == "Hello Tanya"
        assert all(not QtGui.QImage(str(asset_path("Resources", "Themes", key + ".png"))).isNull() for key in THEMES)
        version = asset_path("version.txt").read_text(encoding="utf-8-sig").strip()
        assert version.startswith("v")
        report_path.parent.mkdir(parents=True, exist_ok=True)
        window.grab().save(str(report_path.with_suffix(".main.png")))
        settings = SettingsDialog(clone_config(config), window)
        settings.tabs.setCurrentIndex(settings.tabs.count() - 1)
        settings.show()
        app.processEvents()
        assert settings.theme_buttons["hellokitty"].text() == "Hello Tanya"
        assert not settings.theme_buttons["hellokitty"].icon().isNull()
        settings.grab().save(str(report_path.with_suffix(".settings.png")))
        settings.reject()
        from .rigol_preset_editor import PresetEditor
        from .rigol_presets import PresetStore
        editor = PresetEditor(controller, settings)
        editor.show(); app.processEvents()
        assert editor.table.columnCount() >= 21
        editor.table.item(0,0).setText("Пресет проверки EXE")
        editor.table.item(0,3).setText("2400,5")
        editor.accept(); app.processEvents()
        assert PresetStore(root / "rigol_presets.json").rows[0]['center'] == 2400.5
        assert window.preset_combo.itemText(0) == "Пресет проверки EXE"
        editor.deleteLater()
        window.open_rigol()
        app.processEvents()
        assert window.rigol_dialog.markers is not None
        window.rigol_dialog.close()
        app.processEvents()
        if sys.platform == "win32":
            command = Path(os.environ["SystemRoot"]) / "System32" / "cmd.exe"
            process = launch_external([str(command), "/d", "/c", "exit", "0"], creationflags=0x08000000)
            assert process.wait(timeout=10) == 0, "External process failed"
            check_release_browser()
        config.setdefault("Application", {})["Theme"] = "hellokitty"
        save_config(config, config_path)
        assert theme_from_config(load_config(config_path)) == "hellokitty"
        result = {
            "ok": True, "frozen": bool(getattr(sys, "frozen", False)),
            "bits": struct.calcsize("P") * 8, "version": version,
            "application_dir": str(application_dir()), "data_dir": str(root),
            "config": str(config_path), "asset_root": str(asset_path()),
            "loaded_theme": loaded_theme, "theme_label": "Hello Tanya",
            "font_families": len(QtGui.QFontDatabase.families()), "platform": app.platformName(),
            "checks": ["main_window", "hedgehog", "theme_previews", "settings", "rigol_markers",
                       "persistent_config", "preset_editor", "persistent_presets", "visa_ctwrapper_import", "serial_ports_import", "external_process"]
                      + (["web_control_browser_fixture"] if sys.platform == "win32" else []),
        }
        report_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        return 0
    finally:
        if settings is not None:
            settings.close()
        if window is not None:
            window.close()
        app.processEvents()
        SewerController.tick = original_tick
