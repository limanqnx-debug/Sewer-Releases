"""Versioned preset rows and serialized SCPI application for RSA5000.

Reference: RIGOL RSA5000 Programming Guide, pp. 2-22..25, 2-134, 2-198.
"""
from __future__ import annotations
import copy
import json
import math
import os
from pathlib import Path
import shutil
import tempfile
import uuid

# key, caption, unit, choices (numeric if None). Empty always means unchanged.
COLUMNS = [
    ('name', 'Название пресета', '', ()),
    ('mode', 'Режим', '', ('GPSA','RTSA')),
    ('trace', 'Trace', '', tuple(str(i) for i in range(1,7))),
    ('center', 'Center Freq', 'МГц', None), ('span', 'Span', 'МГц', None),
    ('ref', 'Ref Level', 'дБм', None), ('att', 'Attenuation', 'дБ', None),
    ('offset', 'Ref Offset', 'дБ', None), ('points', 'Sweep Points', '', None),
    ('time', 'Sweep Time', 'мс', None),
    ('trace_type', 'Trace Type', '', ('WRIT','AVER','MAXH','MINH')),
    ('det', 'Trace Det', '', ('AUTO','AVER','NEG','NORM','POS','SAMP','QPE','RAV')),
    ('rbw', 'RBW', 'кГц', None), ('vbw', 'VBW', 'кГц', None),
]
COLUMNS += [(f'm{n}_freq', f'Marker {n} Freq', 'МГц', None) for n in range(1,4)]
COLUMNS += [(f'm{n}_func', f'Marker {n} Func', '', ('OFF','NOIS','BPOW','BDEN')) for n in range(1,4)]
COLUMNS += [(f'm{n}_band', f'Marker {n} Band Function', '', ('OFF','BPOW','BDEN')) for n in range(1,4)]
COLUMNS += [(f'm{n}_band_span', f'Marker {n} Band Span', 'МГц', None) for n in range(1,4)]
COLUMNS += [(f'm{n}_mode', f'Marker {n} Mode', '', ('OFF','POS','FIX')) for n in range(1,4)]
COLUMNS += [(f'm{n}_band_auto', f'Marker {n} Band Auto', '', ('ON','OFF')) for n in range(1,4)]
COLUMNS += [('rbw_auto','RBW Auto','',('ON','OFF')), ('vbw_auto','VBW Auto','',('ON','OFF')),
            ('time_auto','Sweep Time Auto','',('ON','OFF'))]

LIMITS = {'center':(0,6500),'span':(0,6500),'ref':(-200,200),'att':(0,70),'offset':(-300,300),
          'points':(101,10001),'time':(0.001,4e6),'rbw':(.001,10000),'vbw':(.001,10000)}
COMMANDS = {
 'center':(':SENSe:FREQuency:CENTer',1e6), 'span':(':SENSe:FREQuency:SPAN',1e6),
 'ref':(':DISPlay:WINDow:TRACe:Y:SCALe:RLEVel',1),
 'att':(':SENSe:POWer:RF:ATTenuation',1),
 'offset':(':DISPlay:WINDow:TRACe:Y:SCALe:RLEVel:OFFSet',1),
 'points':(':SENSe:SWEep:POINts',1), 'time':(':SENSe:SWEep:TIME',.001),
 'rbw':(':SENSe:BANDwidth:RESolution',1000), 'vbw':(':SENSe:BANDwidth:VIDeo',1000),
 'rbw_auto':(':SENSe:BANDwidth:RESolution:AUTO',1),
 'vbw_auto':(':SENSe:BANDwidth:VIDeo:AUTO',1), 'time_auto':(':SENSe:SWEep:TIME:AUTO',1),
}
ALIASES = {'WRITE':'WRIT','AVERAGE':'AVER','MAXHOLD':'MAXH','MINHOLD':'MINH',
           'NOISE':'NOIS','BPOWER':'BPOW','BDENSITY':'BDEN','POSITIVE':'POS',
           'NEGATIVE':'NEG','NORMAL':'NORM','SAMPLE':'SAMP','QPEAK':'QPE','RMS':'RAV',
           'RAVERAGE':'RAV','VAVERAGE':'AVER'}


def blank(value):
    return value is None or (isinstance(value,str) and not value.strip())


def new_preset(name):
    return {'id':uuid.uuid4().hex,'name':name}


def validate_row(row):
    out = copy.deepcopy(row)
    if not str(row.get('name','')).strip():
        raise ValueError('Укажите название пресета')
    out['name'] = str(row['name']).strip()
    for key, caption, unit, choices in COLUMNS[1:]:
        v = row.get(key)
        if blank(v):
            out.pop(key,None)
            continue
        if choices is not None:
            v = str(v).strip().upper()
            v = ALIASES.get(v,v)
            if v not in choices:
                raise ValueError(f'{caption}: выберите '+', '.join(choices))
        else:
            try:
                if isinstance(v,bool): raise ValueError()
                v = float(str(v).strip().replace(',','.'))
            except ValueError:
                raise ValueError(f'{caption}: требуется число ({unit})') from None
            lo,hi=LIMITS.get(key,(0,6500))
            if not math.isfinite(v) or not lo <= v <= hi or (key=='points' and v!=int(v)):
                raise ValueError(f'{caption}: допустимо {lo:g}…{hi:g} {unit}')
            if key=='points': v=int(v)
        out[key]=v
    for key,auto in (('rbw','rbw_auto'),('vbw','vbw_auto'),('time','time_auto')):
        if key in out and out.get(auto)=='ON':
            raise ValueError(f'{key.upper()}: оставьте число пустым для Auto ON')
    for n in range(1,4):
        func,band=out.get(f'm{n}_func'),out.get(f'm{n}_band')
        if out.get(f'm{n}_mode')=='OFF' and f'm{n}_freq' in out:
            raise ValueError(f'M{n}: для частоты включите POS или FIX')
        if out.get(f'm{n}_band_auto')=='ON' and f'm{n}_band_span' in out:
            raise ValueError(f'M{n}: оставьте Band Span пустым для Band Auto ON')
        if func and band and func!=band:
            raise ValueError(f'M{n}: Func и Band Function задают одну функцию; выберите одинаковую или оставьте одну пустой')
        if (f'm{n}_band_span' in out or f'm{n}_band_auto' in out) and (band or func) not in ('BPOW','BDEN'):
            raise ValueError(f'M{n}: для Band Span выберите BPOW или BDEN')
    return out


class PresetStore:
    def __init__(self,path):
        self.path=Path(path)
        self.data={'schema':1,'presets':[new_preset(f'Пресет {i}') for i in range(1,4)]}
        self.error=''
        self.reload()

    @property
    def rows(self): return self.data['presets']

    def reload(self):
        if not self.path.exists(): return
        try:
            data=json.loads(self.path.read_text(encoding='utf-8-sig'))
            if not isinstance(data,dict) or data.get('schema')!=1 or not isinstance(data.get('presets'),list):
                raise ValueError('Неподдерживаемый формат таблицы пресетов')
            ids=set()
            for row in data['presets']:
                if not isinstance(row,dict) or not row.get('id') or row['id'] in ids:
                    raise ValueError('Отсутствует или повторяется ID пресета')
                validate_row(row); ids.add(row['id'])
            self.data=data; self.error=''
        except (OSError,ValueError,TypeError) as exc:
            self.error=str(exc)

    def save(self,rows):
        if self.error: raise ValueError('Исходный файл не прочитан: '+self.error)
        normalized=[validate_row(r) for r in rows]
        names=[r['name'].casefold() for r in normalized]
        ids=[r.get('id') for r in normalized]
        if len(names)!=len(set(names)): raise ValueError('Названия пресетов должны различаться')
        if not all(ids) or len(ids)!=len(set(ids)): raise ValueError('Повторяется ID пресета')
        data=copy.deepcopy(self.data);data['presets']=normalized
        self.path.parent.mkdir(parents=True,exist_ok=True)
        fd,name=tempfile.mkstemp(dir=self.path.parent,prefix='presets-',suffix='.tmp')
        try:
            with os.fdopen(fd,'w',encoding='utf-8') as f:
                json.dump(data,f,ensure_ascii=False,indent=2,allow_nan=False)
                f.flush();os.fsync(f.fileno())
            if self.path.exists(): shutil.copy2(self.path,self.path.with_suffix('.backup.json'))
            os.replace(name,self.path)
            self.data=data
        finally:
            Path(name).unlink(missing_ok=True)


def commands_for(row, mode):
    r=validate_row(row); trace=int(r.get('trace','1'));commands=[];queries={}
    def add(key,cmd,value):
        commands.append(f'{cmd} {value}');queries[key]=cmd+'?'
    if 'mode' in r:
        add('mode',':INSTrument:SELect','SA' if r['mode']=='GPSA' else 'RTSA')
        mode=r['mode']
    if mode=='RTSA' and any(k in r for k in ('points','time','time_auto','vbw','vbw_auto')):
        raise ValueError('Sweep Points / Sweep Time / VBW доступны в GPSA. Выберите GPSA или очистите эти ячейки.')
    if mode=='RTSA' and r.get('det') in ('NORM','QPE','RAV'):
        raise ValueError('Этот детектор недоступен в RTSA')
    for key in ('center','span','ref','att','offset','points','time','trace_type','det','rbw','vbw','rbw_auto','vbw_auto','time_auto'):
        if key not in r: continue
        v=r[key]
        if key=='trace_type': cmd=f':TRACe{trace}:TYPE'
        elif key=='det':
            cmd=f':SENSe:DETector:TRACe{trace}'
            if v=='AUTO':
                add(key,cmd+':AUTO','ON');continue
            commands.append(cmd+':AUTO OFF')
        else:
            cmd,factor=COMMANDS[key]
            if isinstance(v,(float,int)): v=f'{v*factor:.12g}'
            if key in ('time','rbw','vbw'):
                commands.append(COMMANDS[key if key!='time' else 'time'][0]+':AUTO OFF')
            if key=='att': commands.append(cmd+':AUTO OFF')
        add(key,cmd,v)
    for n in range(1,4):
        p=f':CALCulate:MARKer{n}'
        freq=f'm{n}_freq';func=f'm{n}_func';band=f'm{n}_band';width=f'm{n}_band_span'
        if f'm{n}_mode' in r:
            add(f'm{n}_mode',p+':MODE',r[f'm{n}_mode'])
        if freq in r:
            if r.get('span')==0: raise ValueError('Частотные маркеры недоступны при Span = 0')
            commands.extend(([p+':MODE POS'] if f'm{n}_mode' not in r else [])+[p+':TRACe:AUTO OFF',p+f':TRACe {trace}'])
            add(freq,p+':X',f'{r[freq]*1e6:.12g}HZ')
        if func in r or band in r: add(band if band in r else func,p+':FUNCtion',r.get(band,r.get(func)))
        if width in r:
            commands.append(p+':FUNCtion:BAND:SPAN:AUTO OFF')
            add(width,p+':FUNCtion:BAND:SPAN',f'{r[width]*1e6:.12g}')
        if f'm{n}_band_auto' in r:
            add(f'm{n}_band_auto',p+':FUNCtion:BAND:SPAN:AUTO',r[f'm{n}_band_auto'])
    return r,commands,queries


def apply_preset(rigol,row):
    # Entire plan validates before the first instrument write; one lock prevents
    # interleaved Live/marker/probe reads throughout application and readback.
    with rigol.lock:
        rigol._require_control()
        if not rigol.connected: raise ValueError('Сначала подключите Rigol')
        r,commands,queries=commands_for(row,rigol.mode())
        if not commands: raise ValueError('Пресет пуст. Заполните параметры в настройках ежа.')
        if any(f'm{n}_freq' in r for n in range(1,4)):
            span=r.get('span',rigol.span_hz()/1e6)
            if span==0: raise ValueError('Частотные маркеры недоступны при Span = 0')
        for cmd in commands:
            rigol.write(cmd)
            if cmd.startswith(':INSTrument:SELect '):
                if rigol.query('*OPC?')!='1': raise ValueError('Rigol не завершил переключение режима')
        # *OPC? synchronizes mode/setting changes before readback.
        if rigol.query('*OPC?')!='1': raise ValueError('Rigol не подтвердил завершение команд')
        actual={k:rigol.query(cmd) for k,cmd in queries.items()}
        errors=[]
        for _ in range(16):
            error=rigol.query(':SYSTem:ERRor?')
            if error.split(',')[0].strip() in ('0','+0'): break
            errors.append(error)
        else: errors.append('Очередь ошибок не опустела')
        rigol._readbacks.clear()
        if errors: raise ValueError('Пресет применён частично; Rigol: '+'; '.join(errors))
        differences=[]
        for key,reply in actual.items():
            wanted=r[key]
            if key in COMMANDS and isinstance(wanted,(float,int)):
                value=float(reply)/COMMANDS[key][1]
                if not math.isfinite(value): raise ValueError('Недействительное значение '+key+': '+reply)
                if not math.isclose(value,wanted,rel_tol=1e-6,abs_tol=1e-9): differences.append(key+': '+str(value))
            elif key.endswith('_freq') or key.endswith('_band_span'):
                value=float(reply)/1e6
                if not math.isfinite(value): raise ValueError('Недействительное значение '+key+': '+reply)
                if not math.isclose(value,wanted,rel_tol=1e-6,abs_tol=1e-9): differences.append(key+': '+str(value))
        return {'name':r['name'],'actual':actual,'differences':differences,'mode':rigol.mode(),'span':rigol.span_hz()}


def capture_preset(rigol, name, trace=1):
    row=new_preset(name);row['trace']=str(trace)
    with rigol.lock:
        row['mode']=rigol.mode()
        for key,(cmd,factor) in COMMANDS.items():
            if row['mode']=='RTSA' and key in ('points','time','time_auto','vbw','vbw_auto'): continue
            value=rigol.query(cmd+'?')
            row[key]=('ON' if value in ('1','ON') else 'OFF') if key.endswith('_auto') else float(value)/factor
        for key,auto in (('rbw','rbw_auto'),('vbw','vbw_auto'),('time','time_auto')):
            if row.get(auto)=='ON': row.pop(key,None)
        row['trace_type']=rigol.trace_type(trace)
        row['det']='AUTO' if rigol.query_bool(f':SENSe:DETector:TRACe{trace}:AUTO?') else rigol.query(f':SENSe:DETector:TRACe{trace}?')
        if rigol.span_hz()!=0:
            for n in range(1,4):
                p=f':CALCulate:MARKer{n}'
                marker_mode=rigol.query(p+':MODE?')
                if marker_mode=='OFF':
                    row[f'm{n}_mode']='OFF';continue
                if marker_mode=='DELT':
                    raise ValueError(f'M{n}: для сохранения частоты переключите Delta в Normal или Fixed')
                if marker_mode not in ('POS','FIX'): raise ValueError(f'M{n}: неизвестный режим '+marker_mode)
                if int(rigol.query(p+':TRACe?'))!=trace: continue
                row[f'm{n}_mode']=marker_mode
                row[f'm{n}_freq']=rigol.query_float(p+':X?')/1e6
                func=rigol.query(p+':FUNCtion?')
                row[f'm{n}_func']=func
                if func in ('BPOW','BDEN'):
                    row[f'm{n}_band']=func
                    auto=rigol.query_bool(p+':FUNCtion:BAND:SPAN:AUTO?')
                    row[f'm{n}_band_auto']='ON' if auto else 'OFF'
                    if not auto: row[f'm{n}_band_span']=rigol.query_float(p+':FUNCtion:BAND:SPAN?')/1e6
    return validate_row(row)
