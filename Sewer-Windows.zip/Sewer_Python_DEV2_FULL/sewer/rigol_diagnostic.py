"""Export an already captured frame; never issue instrument commands while saving."""
from __future__ import annotations

import csv
import io
import json
import os
import tempfile
import zipfile
from pathlib import Path


def save_diagnostic(path: Path, capture: dict, window_png: bytes, display: dict, version: str) -> None:
    report = dict(capture, application_version=version, display=display)
    csv_buffer = io.StringIO(newline="")
    writer = csv.writer(csv_buffer)
    frame = capture.get("frame", {})
    samples = capture.get("samples", [])
    xs = frame.get("x", [])
    writer.writerow(["index", f"x_{frame.get('x_unit', 'unknown')}", f"y_{frame.get('y_unit', 'raw')}"])
    for i, value in enumerate(samples):
        writer.writerow([i, xs[i] if i < len(xs) else "", value])
    fd, temp_name = tempfile.mkstemp(prefix=".sewer-diagnostic-", suffix=".zip", dir=path.parent)
    try:
        os.close(fd)
        with zipfile.ZipFile(temp_name, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("report.json", json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False))
            archive.writestr("trace.csv", csv_buffer.getvalue())
            for entry in capture.get("commands", []):
                if entry.get("query", "").startswith(":TRACe:DATA?") and "response" in entry:
                    archive.writestr("trace-response.txt", entry["response"].encode("utf-8"))
            if window_png:
                archive.writestr("sewer-rigol-window.png", window_png)
            archive.writestr("README.txt", (
                "Sewer-P: диагностика отображения Rigol\n\n"
                "report.json — параметры кадра, команды и точные ответы VISA до разбора; время UTC.\n"
                "trace-response.txt — ответ на запрос выбранной трассы, если он получен.\n"
                "trace.csv — все разобранные точки; координата X только для принятого кадра.\n"
                "sewer-rigol-window.png — окно Sewer-P в момент нажатия сохранения.\n\n"
                "При ошибке отчёт содержит последнюю попытку чтения; проверьте время и номер Trace.\n"
                "Данные получены при работающей развёртке, не одновременно с фотографией прибора.\n"
                "Это трасса SCPI, а не снимок экрана Rigol или карта Density.\n"
                "Сохранение не опрашивает и не перенастраивает прибор. Архив никуда не отправляется.\n"
                "Для сравнения приложите фотографию экрана Rigol с тем же сигналом.\n"
            ).encode("utf-8"))
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)
