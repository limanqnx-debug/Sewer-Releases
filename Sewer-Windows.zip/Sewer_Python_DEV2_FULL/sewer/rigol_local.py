"""Front-panel release adapted from the user's working Sewer Widget v0.3.10."""
from __future__ import annotations

from contextlib import contextmanager
import os
from pathlib import Path
import re
import threading
import time

from .process_launch import external_dll_search, external_environment


def web_host(resource: str) -> str:
    parts = resource.split("::")
    if len(parts) < 2 or not parts[0].upper().startswith("TCPIP"):
        raise ValueError("Web Control требует подключения Rigol по Ethernet.")
    host = parts[1].strip().strip("[]")
    if not host or not re.fullmatch(r"[A-Za-z0-9_.:-]+", host):
        raise ValueError("Некорректный адрес Rigol для Web Control.")
    return f"[{host}]" if ":" in host else host


def find_browser() -> Path:
    locations = [Path(os.environ[key]) for key in ("LOCALAPPDATA", "PROGRAMFILES", "PROGRAMFILES(X86)") if os.environ.get(key)]
    # Use the same browser as the widget first; Edge/Chrome are compatible
    # alternatives on PCs where Yandex is not installed.
    for relative in ("Yandex/YandexBrowser/Application/browser.exe",
                     "Microsoft/Edge/Application/msedge.exe",
                     "Google/Chrome/Application/chrome.exe"):
        for root in locations:
            candidate = root / relative
            if candidate.is_file():
                return candidate
    raise RuntimeError("Для освобождения Rigol установите Яндекс Браузер, Edge или Chrome.")


def find_screen(page):
    for frame in page.frames:
        target = frame.locator("#screen")
        if target.count() and target.first.is_visible():
            return target.first
    return None


def open_web_control(page):
    for frame in page.frames:
        for title in ("Web Control", "WebControl", "WEB CONTROL", "Web control"):
            candidates = frame.get_by_text(title, exact=False)
            for index in range(candidates.count()):
                item = candidates.nth(index)
                if item.is_visible():
                    item.click(force=True, timeout=1500)
                    return


def run_release_page(page, url: str, cancel: threading.Event):
    """No SCPI queries may follow the confirmed Rmt click."""
    def check_cancel():
        if cancel.is_set():
            raise RuntimeError("Освобождение Rigol отменено.")

    check_cancel()
    page.goto(url, wait_until="domcontentloaded", timeout=15000)
    page.wait_for_timeout(1500)
    deadline = time.monotonic() + 45
    retry_at = 0.0
    screen = None
    while time.monotonic() < deadline:
        check_cancel()
        try:
            screen = find_screen(page)
            if screen is not None:
                break
            if time.monotonic() >= retry_at:
                open_web_control(page)
                retry_at = time.monotonic() + 1
        except Exception:
            # The instrument may replace a frame while opening Web Control.
            pass
        page.wait_for_timeout(250)
    if screen is None:
        raise RuntimeError("Экран Web Control не найден. Включите Display → Web Control на Rigol.")
    page.wait_for_timeout(500)
    check_cancel()
    screen.click(position={"x": 181, "y": 18}, force=True, timeout=5000)
    page.wait_for_timeout(700)


@contextmanager
def release_browser():
    from playwright.sync_api import sync_playwright

    executable = find_browser()
    # The driver and external browser must not inherit bundled Qt DLL paths.
    with external_dll_search():
        playwright = sync_playwright().start()
    try:
        browser = playwright.chromium.launch(
            executable_path=str(executable), headless=True, timeout=15000,
            env=external_environment(),
            args=["--disable-gpu", "--no-first-run", "--disable-default-apps"],
        )
        try:
            context = browser.new_context(viewport={"width": 1100, "height": 800}, ignore_https_errors=True)
            yield context
        finally:
            browser.close()
    finally:
        playwright.stop()


def release_via_web(resource: str, cancel: threading.Event) -> None:
    url = f"http://{web_host(resource)}/"
    with release_browser() as context:
        run_release_page(context.new_page(), url, cancel)
